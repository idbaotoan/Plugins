[Learn more about the FacetWP color add-on](https://facetwp.com/add-ons/color/)
