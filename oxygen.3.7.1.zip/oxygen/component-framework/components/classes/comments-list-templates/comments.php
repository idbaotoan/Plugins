<?php

eval(" ?>".$GLOBALS['Oxygen_VSB_Current_Comments_Class']->param_array['code_php']."<?php ");

?>