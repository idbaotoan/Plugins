## FacetWP - Elementor integration

FacetWP's Elementor add-on lets you display facets alongside Elementor Pro listings, and it supports the following widgets:

* Posts
* Posts (Ultimate Addons for Elementor)
* Posts (PowerPack for Elementor)
* Archive Posts
* WooCommerce Products
* WooCommerce Products (Ultimate Addons for Elementor)
* WooCommerce Products (PowerPack for Elementor)
* WooCommerce Archive Products
* Listing Grid (JetEngine)

[Read the setup instructions](https://facetwp.com/documentation/integrations/elementor-pro/)
