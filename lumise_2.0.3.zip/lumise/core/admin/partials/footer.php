<?php
	global $lumise;
	$lumise->do_action( 'editor-footer' );
