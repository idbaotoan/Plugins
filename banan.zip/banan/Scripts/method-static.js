
function ajaxQuick(_url, _data, _callback_respone, _beforeSend, _complete, method) {
    $.ajax({
        url: _url,
        type: method === undefined ? 'POST' : method,
        data: _data,
        beforeSend: _beforeSend,
        complete: _complete
    }).done(function (data) {
        _callback_respone(data);
    });
}