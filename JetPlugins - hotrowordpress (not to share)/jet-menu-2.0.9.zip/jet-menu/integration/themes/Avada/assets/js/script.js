( function( $ ) {
	jQuery( '.jet-menu' ).on( 'jetMenuCreated', function() {
		//$( this ).closest( '.fusion-main-menu' ).removeClass( 'fusion-main-menu' ).addClass( 'jet-fusion-main-menu' );
	} );
}( jQuery ) );