<div id="sbi-about" class="sbi-about">
    <?php
        InstagramFeed\SBI_View::render( 'sections.header' );
        InstagramFeed\SBI_View::render( 'about.content' );
        InstagramFeed\SBI_View::render( 'sections.sticky_widget' );
    ?>
</div>