<div id="sbi-support" class="sbi-support">
    <?php
        InstagramFeed\SBI_View::render( 'sections.header' );
        InstagramFeed\SBI_View::render( 'support.content' );
        InstagramFeed\SBI_View::render( 'sections.sticky_widget' );
    ?>
</div>