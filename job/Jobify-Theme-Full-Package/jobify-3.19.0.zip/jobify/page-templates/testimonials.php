<?php
/**
 * Template Name: Page: Testimonials
 *
 * @package Jobify
 * @since Jobify 1.0
 */

locate_template( array( 'archive-testimonial.php' ), true );
