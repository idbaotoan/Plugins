(function($) {
    $(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/ai-element.default', function($scope) {

			if (__CI_AUDIOIGNITER_MANUAL_INIT__) {
          var node = $scope.find('.audioigniter-root').get(0);
          __CI_AUDIOIGNITER_MANUAL_INIT__(node);
      }

		});
	});
})( jQuery );
