/**
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Customizer preview changes asynchronously.
 *
 * https://developer.wordpress.org/themes/customize-api/tools-for-improved-user-experience/#using-postmessage-for-improved-setting-previewing
 */

(function ( $ ) {
	wp.customize( 'audioigniter_disable_typography', function ( value ) {
		value.bind( function ( to ) {
			if ( to ) {
				$( '.ai-wrap' ).removeClass( 'ai-with-typography' );
			} else {
				$( '.ai-wrap' ).addClass( 'ai-with-typography' );
			}
		} );
	} );

})( jQuery );
