import BackgroundControl from './BackgroundControl';

export default BackgroundControl;
