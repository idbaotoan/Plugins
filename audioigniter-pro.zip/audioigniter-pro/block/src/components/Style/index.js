import Style from './Style';

export default Style;
