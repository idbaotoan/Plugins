import LoadingResponsePlaceholder from './LoadingResponsePlaceholder';

export default LoadingResponsePlaceholder;
