<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ||
     ! WP_UNINSTALL_PLUGIN ||
     dirname( WP_UNINSTALL_PLUGIN ) != dirname( plugin_basename( __FILE__ ) )
) {
		status_header( 404 );
		exit;
}

remove_theme_mod( 'audioigniter_disable_typography' );
remove_theme_mod( 'audioigniter_bg_color' );
remove_theme_mod( 'audioigniter_bg_image' );
remove_theme_mod( 'audioigniter_bg_image_repeat' );
remove_theme_mod( 'audioigniter_bg_image_position' );
remove_theme_mod( 'audioigniter_bg_image_cover' );
remove_theme_mod( 'audioigniter_text_color' );
remove_theme_mod( 'audioigniter_accent_color' );
remove_theme_mod( 'audioigniter_text_on_accent_color' );
remove_theme_mod( 'audioigniter_control_color' );
remove_theme_mod( 'audioigniter_player_text_color' );
remove_theme_mod( 'audioigniter_player_button_background_color' );
remove_theme_mod( 'audioigniter_player_button_text_color' );
remove_theme_mod( 'audioigniter_player_button_active_background_color' );
remove_theme_mod( 'audioigniter_player_button_active_text_color' );
remove_theme_mod( 'audioigniter_track_bar_color' );
remove_theme_mod( 'audioigniter_progress_bar_color' );
remove_theme_mod( 'audioigniter_track_background_color' );
remove_theme_mod( 'audioigniter_track_text_color' );
remove_theme_mod( 'audioigniter_track_active_background_color' );
remove_theme_mod( 'audioigniter_track_active_text_color' );
remove_theme_mod( 'audioigniter_track_button_background_color' );
remove_theme_mod( 'audioigniter_track_button_text_color' );
remove_theme_mod( 'audioigniter_lyrics_modal_background_color' );
remove_theme_mod( 'audioigniter_lyrics_modal_text_color' );
delete_option( 'audioigniter_sc_client_id' );

flush_rewrite_rules();
