<div class="wrap">

    <form action="" method="post">

        <table class="form-table">
            <tbody>
                <tr id="row_nf_export_styles_submit">
                    <th scope="row">
                    </th>
                    <td>
                        <input type="submit" id="nf_export_styles_submit" name="nf_export_styles_submit" class="button-secondary" value="<?php _e( 'Export Default Styles', 'ninja-forms' ) ;?>">
                    </td>
                </tr>
            </tbody>
        </table>

    </form>

</div>