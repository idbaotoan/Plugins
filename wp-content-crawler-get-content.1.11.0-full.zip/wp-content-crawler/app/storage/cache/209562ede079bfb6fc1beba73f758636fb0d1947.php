<div class="quick-save-container">
    <button type="button" class="quick-save animated"
            data-post-id="<?php echo e($postId); ?>" title="<?php echo e("Quick save"); ?>">
        <span class="dashicons dashicons-yes"></span>
    </button>
</div><?php /**PATH /Users/rocketgroup/Sites/PROJECTS - RKW/tgdd2.rkw/wp-content/plugins/wp-content-crawler/app/views/form-items/quick-save-settings.blade.php ENDPATH**/ ?>