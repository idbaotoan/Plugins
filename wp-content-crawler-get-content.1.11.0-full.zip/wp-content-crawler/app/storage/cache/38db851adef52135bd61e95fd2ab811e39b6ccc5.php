<div class="test-results hidden">
    <button class="button hide-test-results"><?php echo e(_wpcc('Hide')); ?></button>
    <div class="content"></div>
    <button class="button hide-test-results"><?php echo e(_wpcc('Hide')); ?></button>
</div><?php /**PATH /Users/rocketgroup/Sites/PROJECTS - RKW/tgdd2.rkw/wp-content/plugins/wp-content-crawler/app/views/partials/test-result-container.blade.php ENDPATH**/ ?>