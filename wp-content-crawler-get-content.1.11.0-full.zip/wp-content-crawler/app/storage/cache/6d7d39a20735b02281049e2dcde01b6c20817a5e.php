

<?php echo $__env->make('form-items.combined.select-with-label', [
    'options' => \WPCCrawler\Utils::getAuthors()
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rocketgroup/Sites/PROJECTS - RKW/tgdd2.rkw/wp-content/plugins/wp-content-crawler/app/views/form-items/combined/select-author-with-label.blade.php ENDPATH**/ ?>