<div id="wcc-alert" class="notice notice-error hidden">
    <p><?php echo e(_wpcc('Please fix the errors.')); ?></p>
</div><?php /**PATH /Users/rocketgroup/Sites/PROJECTS - RKW/tgdd2.rkw/wp-content/plugins/wp-content-crawler/app/views/partials/form-error-alert.blade.php ENDPATH**/ ?>