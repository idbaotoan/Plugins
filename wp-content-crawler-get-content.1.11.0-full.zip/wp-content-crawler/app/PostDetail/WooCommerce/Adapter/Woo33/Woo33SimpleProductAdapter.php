<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 24/12/2018
 * Time: 20:39
 *
 * @since 1.8.0
 */

namespace WPCCrawler\PostDetail\WooCommerce\Adapter\Woo33;


use WPCCrawler\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo33SimpleProductAdapter extends Woo33ProductAdapter implements SimpleProductAdapter {

}