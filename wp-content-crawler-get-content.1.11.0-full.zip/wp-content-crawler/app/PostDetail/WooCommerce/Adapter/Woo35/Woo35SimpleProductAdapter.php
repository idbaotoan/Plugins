<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 24/12/2018
 * Time: 20:39
 *
 * @since 1.8.0
 */

namespace WPCCrawler\PostDetail\WooCommerce\Adapter\Woo35;


use WPCCrawler\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo35SimpleProductAdapter extends Woo35ProductAdapter implements SimpleProductAdapter {

}