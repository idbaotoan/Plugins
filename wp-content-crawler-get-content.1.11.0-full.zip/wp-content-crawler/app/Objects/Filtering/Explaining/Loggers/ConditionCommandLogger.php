<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 10/05/2020
 * Time: 14:28
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Objects\Filtering\Explaining\Loggers;


class ConditionCommandLogger extends AbstractCommandLogger {

}