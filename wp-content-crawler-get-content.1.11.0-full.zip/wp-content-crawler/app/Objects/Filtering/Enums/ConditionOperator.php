<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 02/04/2020
 * Time: 10:37
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Objects\Filtering\Enums;


abstract class ConditionOperator {

    const AND = 'and';
    const OR  = 'or';

}