<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 11/06/2020
 * Time: 09:56
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Objects\ValueType\Interfaces;


/**
 * Base class for interfaces that define casting methods
 *
 * @since 1.11.0
 */
interface Outputs {

}