<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 26/10/2018
 * Time: 18:42
 */

namespace WPCCrawler\Objects\Enums;


class InformationType extends EnumBase {

    const ERROR = 'error';
    const INFO  = 'info';

}