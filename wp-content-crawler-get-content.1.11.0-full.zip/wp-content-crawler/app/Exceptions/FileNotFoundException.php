<?php
/**
 * Created by PhpStorm.
 * User: tsaricam
 * Date: 24/01/2021
 * Time: 11:12
 *
 * @since 1.10.2
 */

namespace WPCCrawler\Exceptions;


use Exception;

class FileNotFoundException extends Exception {

}