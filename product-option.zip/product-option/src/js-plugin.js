(function($) {var combo_1 = 0;
	var combo_2 = 0;
	var price_cb1= [0,($('.choice_cb1').val()),( $('.choice_cb2').val()), ( $('.choice_cb3').val()), ( $('.choice_cb4').val())];
	var price_cb3= $('.choice_cb3').val();
	var length_combo2 = $('.choice_2').length;
	var total_combo =0;
	var arr_combo1 = [$('.pofw-option').attr('name')];
	var price_goc = $(".price-goc").val();
  console.log(price_goc);

	
	$('input[type="checkbox"]').on('change', function() {
		$('input[name="' + this.name + '"]').not(this).prop('checked', false);
	});
	 var n =0;
	 $(".options-list  > .choice_1 ").click(function() {
      	n++;
		 if(($(this).children('.pofw-option').prop('checked')) == true){
			 $(this).css('border','1px solid red');
			 $('.choice_1').not(this).css('border','unset'); 
		 }else{
			 $(this).css('border','unset'); 
		 }
		 
		 
			combo_1 = $(this).children(".choice_cb").val();
		 for(var i = 1; i<= length_combo2 ; i++){
			  total_combo = Number(combo_1) + Number(price_cb1[i]);
			 $('.choice').find('.price_cb'+i).html(new Intl.NumberFormat('VN', { maximumSignificantDigits: 12 }).format(total_combo)+'đ');
		 
		}
       if(n==1){
        	$(".woocommerce-Price-amount").html(new Intl.NumberFormat('VN', { maximumSignificantDigits: 12 }).format(combo_1 )+'đ');
       }else{
        	$(".woocommerce-Price-amount").html(new Intl.NumberFormat('VN', { maximumSignificantDigits: 12 }).format(Number(combo_1)+Number(combo_2))+'đ');
       }
      
       
  
     
       
		 
    }); 
	$(".options-list  > .choice_2 ").click(function() {
		 if(($(this).children('.pofw-option').prop('checked')) == true){
			 $(this).css('border','1px solid red');
			 $('.choice_2').not(this).css('border','unset'); 
		 }else{
			 $(this).css('border','unset'); 
		 }
        combo_2 = $(this).children(".choice_df").val();
		 total_combo = Number(combo_1) + Number(combo_2) ;
		
		$(this).find('.price_t').html(new Intl.NumberFormat('VN', { maximumSignificantDigits: 12 }).format(total_combo)+'đ');
	
      $(".woocommerce-Price-amount").html(new Intl.NumberFormat('VN', { maximumSignificantDigits: 12 }).format(total_combo )+'đ');
       
    }); 

})(jQuery);
