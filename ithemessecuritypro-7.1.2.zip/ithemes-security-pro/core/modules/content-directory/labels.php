<?php

return [
	'title' => __( 'Change Content Directory', 'it-l10n-ithemes-security-pro' ),
];
