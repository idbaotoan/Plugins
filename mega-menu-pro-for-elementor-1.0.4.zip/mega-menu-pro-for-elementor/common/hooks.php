<?php

/**
 * Enqueue preview scripts
 */
function scemm_enqueue_preview_scripts()
{
    wp_enqueue_style('emm-preview', SCEMM_URI . 'assets/css/preview.min.css', ['emm-frontend'], SCEMM_VER);

	wp_enqueue_script('emm-preview', SCEMM_URI . 'assets/js/preview.min.js', ['elementor-frontend'], SCEMM_VER, true);
}
add_action('elementor/preview/enqueue_scripts', 'scemm_enqueue_preview_scripts');

/**
 * Register Elementor widgets
 */
function scemm_register_elementor_widgets($widget_manager)
{
    require SCEMM_DIR . 'common/class-mega-menu-widget.php';

	$widget_manager->register_widget_type(new SC\EMM\MegaMenu());
}
add_action('elementor/widgets/widgets_registered', 'scemm_register_elementor_widgets');

/**
 * Register elementor_menu_item post type
 */
function scemm_register_post_types()
{
    register_post_type('elementor_menu_item', [
        'labels' => [
            'name' => __('Elementor Menu Items', 'mega-menu-pro-for-elementor'),
            'singular_name' => __('Elementor Menu Item', 'mega-menu-pro-for-elementor'),
            'all_items' => __('All Elementor Menu Items', 'mega-menu-pro-for-elementor')
        ],
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => false,
        'show_in_nav_menus' => false,
        'show_in_admin_bar' => false,
        'exclude_from_search' => true,
        'supports' => ['title', 'editor']
    ]);

    // Ensure permalinks for custom post types.
    if (!get_option('sc_emm_flushed_rewrite_rules', false)) {
        flush_rewrite_rules();
        add_option('sc_emm_flushed_rewrite_rules', 1);
    }
}
add_action('init', 'scemm_register_post_types', 10, 0);

/**
 * Add Elementor support
 */
function scemm_add_elementor_support($supports)
{
    if (empty($supports)) $supports = [];

    if (!isset($supports['elementor_menu_item'])) {
        $supports[] = 'elementor_menu_item';
    }

    return $supports;
}
add_filter('option_elementor_cpt_support', 'scemm_add_elementor_support');
add_filter('default_option_elementor_cpt_support', 'scemm_add_elementor_support');
