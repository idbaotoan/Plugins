<?php

use Elementor\Icons_Manager;

/**
 * @return string
 */
function scemm_render_icon(array $icon, $class = 'emm7')
{
    if (!empty($icon['value'])) {
        if ('svg' === $icon['library']) {
            if (!empty($icon['value']['url'])) {
                return '<span role="presentation" class="' . $class . '"><img src="' . $icon['value']['url'] . '"></span>';
            } else {
                return 'SVG';
            }
        } else {
            $types = Icons_Manager::get_icon_manager_tabs();
            if (isset($types[$icon['library']]['render_callback']) && is_callable($types[$icon['library']]['render_callback'])) {
                $atts = ['class' => $class . ' ' . $icon['value']];
                return call_user_func_array($types[$icon['library']]['render_callback'], [$icon, $atts, 'span']);
            }
            return '<span class="' . $class . ' ' . $icon['value'] . '"></span>';
        }
    }

    return '';
}

/**
 * Parse menu items HTML classes
 */
function scemm_parse_menu_item_classes(&$menu_items)
{
	global $wp_query, $wp_rewrite;

    $home_page_id = (int)get_option('page_for_posts');
    $active_object = '';
	$queried_object = $wp_query->get_queried_object();
	$queried_object_id = (int)$wp_query->queried_object_id;
    $active_parent_item_ids = [];
    $possible_object_parents = [];
	$active_ancestor_item_ids = [];
	$active_parent_object_ids = [];
	$possible_taxonomy_ancestors = [];

	if ($wp_query->is_singular && !empty($queried_object->post_type) && !is_post_type_hierarchical($queried_object->post_type)) {
		foreach ((array)get_object_taxonomies($queried_object->post_type) as $taxonomy) {
			if (is_taxonomy_hierarchical($taxonomy)) {
				$term_hierarchy = _get_term_hierarchy($taxonomy);
				$terms = wp_get_object_terms($queried_object_id, $taxonomy, ['fields' => 'ids']);
				if (is_array($terms)) {
                    $term_to_ancestor = [];
					$possible_object_parents = array_merge($possible_object_parents, $terms);
					foreach ((array)$term_hierarchy as $anc => $descs) {
						foreach ((array)$descs as $desc) {
							$term_to_ancestor[$desc] = $anc;
						}
					}
					foreach ($terms as $desc) {
						do {
							$possible_taxonomy_ancestors[$taxonomy][] = $desc;
							if (isset($term_to_ancestor[$desc])) {
								$_desc = $term_to_ancestor[$desc];
								unset($term_to_ancestor[$desc]);
								$desc = $_desc;
							} else {
								$desc = 0;
							}
						} while (!empty($desc));
					}
				}
			}
		}
	} elseif (!empty($queried_object->taxonomy) && is_taxonomy_hierarchical($queried_object->taxonomy)) {
		$term_hierarchy = _get_term_hierarchy($queried_object->taxonomy);
		$term_to_ancestor = [];
		foreach ((array)$term_hierarchy as $anc => $descs) {
			foreach ((array)$descs as $desc) {
				$term_to_ancestor[$desc] = $anc;
			}
		}
		$desc = $queried_object->term_id;
		do {
			$possible_taxonomy_ancestors[$queried_object->taxonomy][] = $desc;
			if (isset($term_to_ancestor[$desc])) {
				$_desc = $term_to_ancestor[$desc];
				unset($term_to_ancestor[$desc]);
				$desc = $_desc;
			} else {
				$desc = 0;
			}
		} while (!empty($desc));
	}

    $front_page_id = (int)get_option('page_on_front');
	$front_page_url = home_url();
	$privacy_policy_page_id = (int)get_option('wp_page_for_privacy_policy');
    $possible_object_parents = array_filter($possible_object_parents);

	foreach ((array)$menu_items as $key => $menu_item) {
		$menu_items[$key]->current = false;
		$menu_items[$key]->_classes = $menu_item->classes;
		$classes = ['menu-item', 'menu-item-type-' . $menu_item->type, 'menu-item-object-' . $menu_item->object];

		// This menu item is set as the 'Front Page'.
		if ('post_type' === $menu_item->type && $front_page_id === (int)$menu_item->object_id) {
			$classes[] = 'menu-item-home';
		}

		// This menu item is set as the 'Privacy Policy Page'.
		if ('post_type' === $menu_item->type && $privacy_policy_page_id === (int)$menu_item->object_id) {
			$classes[] = 'menu-item-privacy-policy';
		}

		// If the menu item corresponds to a taxonomy term for the currently queried non-hierarchical post object.
		if ($wp_query->is_singular && 'taxonomy' === $menu_item->type
			&& in_array((int)$menu_item->object_id, $possible_object_parents, true)
		) {
            $active_object = $queried_object->post_type;
            $active_parent_item_ids[] = (int)$menu_item->db_id;
			$active_parent_object_ids[] = (int)$menu_item->object_id;

			// If the menu item corresponds to the currently queried post or taxonomy object.
		} elseif (
			$menu_item->object_id == $queried_object_id
			&& (
				(!empty($home_page_id) && 'post_type' === $menu_item->type
					&& $wp_query->is_home && $home_page_id == $menu_item->object_id)
				|| ('post_type' === $menu_item->type && $wp_query->is_singular)
				|| ('taxonomy' === $menu_item->type
					&& ($wp_query->is_category || $wp_query->is_tag || $wp_query->is_tax)
					&& $queried_object->taxonomy == $menu_item->object)
			)
		) {
            $_anc_id = (int)$menu_item->db_id;
			$classes[] = 'current-menu-item';
			$menu_items[$key]->current = true;

			while (
				($_anc_id = (int)get_post_meta($_anc_id, '_menu_item_menu_item_parent', true))
				&& !in_array($_anc_id, $active_ancestor_item_ids, true)
			) {
				$active_ancestor_item_ids[] = $_anc_id;
			}

            $active_object = $menu_item->object;
			$active_parent_item_ids[] = (int)$menu_item->menu_item_parent;
			$active_parent_object_ids[] = (int)$menu_item->post_parent;

			// If the menu item corresponds to the currently queried post type archive.
		} elseif (
			'post_type_archive' === $menu_item->type
			&& is_post_type_archive(array($menu_item->object))
		) {
            $_anc_id = (int)$menu_item->db_id;
			$classes[] = 'current-menu-item';
			$menu_items[$key]->current = true;

			while (
				($_anc_id = (int)get_post_meta($_anc_id, '_menu_item_menu_item_parent', true))
				&& !in_array($_anc_id, $active_ancestor_item_ids, true)
			) {
				$active_ancestor_item_ids[] = $_anc_id;
			}

			$active_parent_item_ids[] = (int)$menu_item->menu_item_parent;

			// If the menu item corresponds to the currently requested URL.
		} elseif ('custom' === $menu_item->object && isset($_SERVER['HTTP_HOST'])) {
			$_root_relative_current = untrailingslashit($_SERVER['REQUEST_URI']);

			// If it's the customize page then it will strip the query var off the URL before entering the comparison block.
			if (is_customize_preview()) {
				$_root_relative_current = strtok(untrailingslashit($_SERVER['REQUEST_URI']), '?');
			}

			$current_url = set_url_scheme('http://' . $_SERVER['HTTP_HOST'] . $_root_relative_current);
			$raw_item_url = strpos($menu_item->url, '#') ? substr($menu_item->url, 0, strpos($menu_item->url, '#')) : $menu_item->url;
			$item_url = set_url_scheme(untrailingslashit($raw_item_url));
			$_indexless_current = untrailingslashit(preg_replace('/' . preg_quote($wp_rewrite->index, '/') . '$/', '', $current_url));

			$matches = [
				$current_url,
				urldecode($current_url),
				$_indexless_current,
				urldecode($_indexless_current),
				$_root_relative_current,
				urldecode($_root_relative_current),
			];

			if ($raw_item_url && in_array($item_url, $matches, true)) {
                $_anc_id = (int)$menu_item->db_id;
				$classes[] = 'current-menu-item';
				$menu_items[$key]->current = true;

				while (
					($_anc_id = (int)get_post_meta($_anc_id, '_menu_item_menu_item_parent', true))
					&& !in_array($_anc_id, $active_ancestor_item_ids, true)
				) {
					$active_ancestor_item_ids[] = $_anc_id;
				}

                $active_object = $menu_item->object;
				$active_parent_item_ids[] = (int)$menu_item->menu_item_parent;
				$active_parent_object_ids[] = (int)$menu_item->post_parent;

				// Give front page item the 'current-menu-item' class when extra query arguments are involved.
			} elseif ($item_url == $front_page_url && is_front_page()) {
				$classes[] = 'current-menu-item';
			}

			if (untrailingslashit($item_url) == home_url()) {
				$classes[] = 'menu-item-home';
			}
		}

		$menu_items[$key]->classes = array_unique($classes);
	}
    $active_parent_item_ids = array_filter(array_unique($active_parent_item_ids));
	$active_ancestor_item_ids = array_filter(array_unique($active_ancestor_item_ids));
	$active_parent_object_ids = array_filter(array_unique($active_parent_object_ids));

	// Set parent's class.
	foreach ((array) $menu_items as $key => $parent_item) {
		$classes = (array) $parent_item->classes;
        $menu_items[$key]->current_item_parent = false;
		$menu_items[$key]->current_item_ancestor = false;

		if (
			isset($parent_item->type)
			&& (
				// Ancestral post object.
				(
					'post_type' === $parent_item->type
					&& !empty($queried_object->post_type)
					&& is_post_type_hierarchical($queried_object->post_type)
					&& in_array((int)$parent_item->object_id, $queried_object->ancestors, true)
					&& $parent_item->object != $queried_object->ID
				) ||

				// Ancestral term.
				(
					'taxonomy' === $parent_item->type
					&& isset($possible_taxonomy_ancestors[$parent_item->object])
					&& in_array((int)$parent_item->object_id, $possible_taxonomy_ancestors[$parent_item->object], true)
					&& (
						!isset($queried_object->term_id) ||
						$parent_item->object_id != $queried_object->term_id
					)
				)
			)
		) {
			if (!empty($queried_object->taxonomy)) {
				$classes[] = 'current-' . $queried_object->taxonomy . '-ancestor';
			} else {
				$classes[] = 'current-' . $queried_object->post_type . '-ancestor';
			}
		}

		if (in_array((int)$parent_item->db_id, $active_ancestor_item_ids, true)) {
			$classes[] = 'current-menu-ancestor';

			$menu_items[$key]->current_item_ancestor = true;
		}
		if (in_array((int)$parent_item->db_id, $active_parent_item_ids, true)) {
			$classes[] = 'current-menu-parent';

			$menu_items[$key]->current_item_parent = true;
		}
		if (in_array((int)$parent_item->object_id, $active_parent_object_ids, true)) {
			$classes[] = 'current-' . $active_object . '-parent';
		}

		$menu_items[$key]->classes = array_unique($classes);
	}
}

/**
 * Render a menu
 */
function scemm_render_menu(array $args)
{
    $args = (object)$args;
    $items = wp_get_nav_menu_items($args->menu, [
        'nopaging' => true,
        'no_found_rows' => true,
        'suppress_filters' => true,
        'update_post_term_cache' => false,
        'update_post_meta_cache' => false
    ]);

    scemm_parse_menu_item_classes($items);

    $sorted_items = [];
    $parent_items = [];

    foreach ($items as $item) {
        $sorted_items[$item->menu_order] = $item;
        if ($item->menu_item_parent) {
            $parent_items[$item->menu_item_parent] = true;
        }
    }

    if ($parent_items) {
        foreach ($sorted_items as $item) {
            if (isset($parent_items[$item->ID])) {
                $item->classes[] = 'menu-item-has-children';
            }
        }
    }

    $items = walk_nav_menu_tree($sorted_items, 0, $args);

    echo '<ul class="emm4" data-id="' . $args->menu->term_id . '">' . $items . '</ul>';
}
