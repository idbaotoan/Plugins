<?php namespace SC\EMM;

use Elementor\Plugin;
use Elementor\Widget_Base;
use Elementor\Core\Schemes;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Responsive\Responsive;

/**
 * MegaMenu
 */
final class MegaMenu extends Widget_Base
{
    public function get_name()
    {
        return 'mega-menu';
    }

    public function get_title()
    {
        return __('Mega Menu', 'mega-menu-pro-for-elementor');
    }

    public function get_icon()
    {
        return 'eicon-nav-menu';
    }

    public function get_categories()
    {
        if (defined('ELEMENTOR_PRO_VERSION')) {
            return ['theme-elements'];
        }

        return ['basic'];
    }

    public function get_keywords()
    {
        return ['menu', 'nav', 'button', 'mega', 'popup', 'canvas'];
    }

    public function get_script_depends()
    {
        return ['emm-frontend'];
    }

    protected function _register_controls()
    {
        $menus = $this->list_available_menus();
        $breakpoints = Responsive::get_breakpoints();

        $this->start_controls_section('content__general', [
            'label' => __('General', 'mega-menu-pro-for-elementor'),
        ]);

        if (!empty($menus)) {
            $this->add_control('menu', [
                'label' => __('Menu', 'mega-menu-pro-for-elementor'),
                'type' => Controls_Manager::SELECT,
                'options' => $menus,
                'default' => array_keys($menus)[0],
                'save_default' => true
            ]);
        } else {
            $this->add_control('no_menu', [
                'type' => Controls_Manager::RAW_HTML,
                /* translators: %s: Add new menu link. */
                'raw' => '<strong>' . __('No menu found.', 'mega-menu-pro-for-elementor') . '</strong><br>' . sprintf(__('Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'mega-menu-pro-for-elementor'), admin_url('nav-menus.php?action=edit&menu=0')),
                'separator' => 'after',
                'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
            ]);
        }

        $this->add_control('show_sub_click_target', [
            'label' => __('Submenu Toggle', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'item',
            'options' => [
                'item' => __('Entire Menu Item', 'mega-menu-pro-for-elementor'),
                'indicator' => __('Submenu Indicator', 'mega-menu-pro-for-elementor')
            ],
            'description' => __('Toggle a submenu by clicking on submenu indicator icon only or anywhere inside a menu item.', 'mega-menu-pro-for-elementor'),
            'frontend_available' => true
        ]);

        $this->end_controls_section();

		$this->start_controls_section('content__desktop', [
			'label' => __('Desktop Menu', 'mega-menu-pro-for-elementor')
        ]);

        $this->add_control('layout', [
            'label' => __('Layout', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'horizontal',
            'options' => [
                'horizontal' => __('Horizontal', 'mega-menu-pro-for-elementor'),
                'vertical' => __('Vertical', 'mega-menu-pro-for-elementor'),
                'hidden' => __('Hidden', 'mega-menu-pro-for-elementor')
            ],
            'prefix_class' => 'emm emm2',
            'frontend_available' => true
        ]);

        $this->add_control('align_items', [
            'label' => __('Items Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-right',
                ],
                'justify' => [
                    'title' => __('Justify', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-stretch',
                ],
            ],
            'prefix_class' => 'emm1',
            'condition' => [
                'layout' => 'horizontal'
            ]
        ]);

        $this->add_control('align_text', [
            'label' => __('Text Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-right',
                ]
            ],
            'prefix_class' => 'emm34',
            'condition' => [
                'layout' => 'horizontal',
                'align_items' => 'justify'
            ]
        ]);

        $this->add_control('vertical_align_text', [
            'label' => __('Text Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-right',
                ]
            ],
            'prefix_class' => 'emm34',
            'condition' => [
                'layout' => 'vertical'
            ]
        ]);

        $this->add_control('flyout_align', [
            'label' => __('Top Level Flyout Menus Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'center',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-right',
                ]
            ],
            'prefix_class' => 'emm25',
            'condition' => [
                'layout' => 'horizontal'
            ]
        ]);

        $this->add_control('pointer', [
            'label' => __('Pointer', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'underline',
            'options' => [
                '' => __('None', 'mega-menu-pro-for-elementor'),
                'text' => __('Text', 'mega-menu-pro-for-elementor'),
                'framed' => __('Framed', 'mega-menu-pro-for-elementor'),
                'triangle' => __('Triangle', 'mega-menu-pro-for-elementor'),
                'overline' => __('Overline', 'mega-menu-pro-for-elementor'),
                'underline' => __('Underline', 'mega-menu-pro-for-elementor'),
                'doubleline' => __('Doubleline', 'mega-menu-pro-for-elementor'),
                'background' => __('Background', 'mega-menu-pro-for-elementor'),
            ],
            'description' => __('Triangle pointer is only applicable for horizontal layout and menu items which have submenu.', 'mega-menu-pro-for-elementor'),
            'condition' => [
                'layout!' => 'hidden'
            ]
        ]);

        $this->add_control('pointer_animation_line', [
            'label' => __('Pointer Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'grow',
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'fade' => __('Fade', 'mega-menu-pro-for-elementor'),
                'grow' => __('Grow', 'mega-menu-pro-for-elementor'),
                'slide' => __('Slide', 'mega-menu-pro-for-elementor'),
                'dropin' => __('Drop In', 'mega-menu-pro-for-elementor'),
                'dropout' => __('Drop Out', 'mega-menu-pro-for-elementor'),
                'sweep-left' => __('Sweep Left', 'mega-menu-pro-for-elementor'),
                'sweep-right' => __('Sweep Right', 'mega-menu-pro-for-elementor'),
            ],
            'frontend_available' => true,
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
            ],
        ]);

        $this->add_control('pointer_animation_framed', [
            'label' => __('Pointer Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'corners',
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'fade' => __('Fade', 'mega-menu-pro-for-elementor'),
                'grow' => __('Grow', 'mega-menu-pro-for-elementor'),
                'draw' => __('Draw', 'mega-menu-pro-for-elementor'),
                'shrink' => __('Shrink', 'mega-menu-pro-for-elementor'),
                'corners' => __('Corners', 'mega-menu-pro-for-elementor'),
            ],
            'condition' => [
                'pointer' => 'framed',
            ],
        ]);

        $this->add_control('pointer_animation_background', [
            'label' => __('Pointer Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'shutter-in-vertical',
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'fade' => __('Fade', 'mega-menu-pro-for-elementor'),
                'grow' => __('Grow', 'mega-menu-pro-for-elementor'),
                'shrink' => __('Shrink', 'mega-menu-pro-for-elementor'),
                'sweep-up' => __('Sweep Up', 'mega-menu-pro-for-elementor'),
                'sweep-down' => __('Sweep Down', 'mega-menu-pro-for-elementor'),
                'sweep-left' => __('Sweep Left', 'mega-menu-pro-for-elementor'),
                'sweep-right' => __('Sweep Right', 'mega-menu-pro-for-elementor'),
                'shutter-in-vertical' => __('Shutter In Vertical', 'mega-menu-pro-for-elementor'),
                'shutter-out-vertical' => __('Shutter Out Vertical', 'mega-menu-pro-for-elementor'),
                'shutter-in-horizontal' => __('Shutter In Horizontal', 'mega-menu-pro-for-elementor'),
                'shutter-out-horizontal' => __('Shutter Out Horizontal', 'mega-menu-pro-for-elementor'),
            ],
            'condition' => [
                'pointer' => 'background',
            ],
        ]);

        $this->add_control('pointer_animation_text', [
            'label' => __('Pointer Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'shrink',
            'options' => [
                'grow' => __('Grow', 'mega-menu-pro-for-elementor'),
                'shrink' => __('Shrink', 'mega-menu-pro-for-elementor'),
                'sink' => __('Sink', 'mega-menu-pro-for-elementor'),
                'float' => __('Float', 'mega-menu-pro-for-elementor'),
                'skew' => __('Skew', 'mega-menu-pro-for-elementor'),
                'rotate' => __('Rotate', 'mega-menu-pro-for-elementor')
            ],
            'condition' => [
                'pointer' => 'text',
            ],
        ]);

        $this->add_control('reverse_triangle_pointer', [
            'label' => __('Reverse Triangle Pointer', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'condition' => [
                'pointer' => 'triangle'
            ],
        ]);

        $this->add_control('indicator', [
            'label' => __('Submenu Indicator', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'caret',
            'options' => [
                'plus' => __('Plus', 'mega-menu-pro-for-elementor'),
                'caret' => __('Caret', 'mega-menu-pro-for-elementor'),
                'angle' => __('Angle', 'mega-menu-pro-for-elementor'),
                'chevron' => __('Chevron', 'mega-menu-pro-for-elementor'),
                'hidden' => __('Hidden', 'mega-menu-pro-for-elementor')
            ],
            'prefix_class' => 'emm18',
            'condition' => [
                'layout!' => 'hidden'
            ]
        ]);

        $this->add_control('sub_animation', [
            'label' => __('Submenu Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'fade-in-up',
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'fade-in' => __('Fade In', 'mega-menu-pro-for-elementor'),
                'fade-in-up' => __('Fade In Up', 'mega-menu-pro-for-elementor'),
                'fade-in-down' => __('Fade In Down', 'mega-menu-pro-for-elementor'),
                'stretch' => __('Curtain Falls', 'mega-menu-pro-for-elementor')
            ],
            'frontend_available' => true,
            'condition' => [
                'layout' => 'horizontal'
            ],
        ]);

        $this->add_control('vertical_sub_animation', [
            'label' => __('Submenu Animation', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'fade-in-right',
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'fade-in' => __('Fade In', 'mega-menu-pro-for-elementor'),
                'fade-in-left' => __('Fade In Left', 'mega-menu-pro-for-elementor'),
                'fade-in-right' => __('Fade In Right', 'mega-menu-pro-for-elementor')
            ],
            'frontend_available' => true,
            'condition' => [
                'layout' => 'vertical'
            ],
        ]);

        $this->add_control('show_sub_click', [
            'label' => __('Toggle Submenu On Click', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'frontend_available' => true
        ]);

        $this->add_control('show_sub_intent_hover', [
            'label' => __('Show Sub On Intent Hover', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'frontend_available' => true,
            'condition' => [
                'show_sub_click!' => 'yes'
            ]
        ]);

        $this->add_control('highlight_current_item', [
            'label' => __('Highlight Current Menu Item', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'frontend_available' => true,
            'condition' => [
                'layout!' => 'hidden'
            ],
        ]);

        $this->add_control('hide_highlighted_pointer', [
            'label' => __('Hide Current Menu Item Pointer', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'condition' => [
                'pointer!' => ['', 'text'],
                'highlight_current_item' => 'yes'
            ],
            'prefix_class' => 'emm76'
        ]);

        $this->add_control('push_indicator', [
            'label' => __('Push Sub Indicator To The End', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'default' => '',
            'prefix_class' => 'emm19',
            'frontend_available' => true,
            'condition' => [
                'layout' => 'vertical',
                'indicator!' => 'hidden',
                'vertical_align_text!' => 'center'
            ],
        ]);

        $this->end_controls_section();

		$this->start_controls_section('content__mobile', [
			'label' => __('Mobile Menu', 'mega-menu-pro-for-elementor')
        ]);

        $this->add_control('mobile_layout', [
            'label' => __('Layout', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'offcanvas',
            'options' => [
                'offcanvas' => __('Off-Canvas', 'mega-menu-pro-for-elementor'),
                'dropdown' => __('Dropdown', 'mega-menu-pro-for-elementor'),
                'paged' => __('Paged', 'mega-menu-pro-for-elementor'),
                'hidden' => __('Hidden', 'mega-menu-pro-for-elementor')
            ],
            'frontend_available' => true,
            'prefix_class' => 'emm12'
        ]);

        $this->add_control('breakpoint', [
            'label' => __('Breakpoint', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'tablet',
            'options' => [
                /* translators: %d: Breakpoint number. */
                'tablet' => sprintf(__('Tablet (< %dpx)', 'mega-menu-pro-for-elelemtor'), $breakpoints['lg']),
                /* translators: %d: Breakpoint number. */
                'mobile' => sprintf(__('Mobile (< %dpx)', 'mega-menu-pro-for-elelemtor'), $breakpoints['md']),
                'none' => __('None', 'mega-menu-pro-for-elelemtor')
            ],
            'description' => __('"None" will disable responsiveness. Mobile menu will replace desktop menu on desktop screen.', 'mega-menu-pro-for-elementor'),
            'prefix_class' => 'emm11',
            'frontend_available' => true,
            'condition' => [
                'mobile_layout!' => 'hidden'
            ]
        ]);

        $this->add_control('mobile_align_text', [
            'label' => __('Text Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-right',
                ]
            ],
            'prefix_class' => 'emm36',
            'condition' => [
                'mobile_layout!' => 'hidden'
            ]
        ]);

        $this->add_control('mobile_canvas_align', [
            'label' => __('Off-Canvas Panel Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-left',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-right',
                ]
            ],
            'prefix_class' => 'emm22',
            'condition' => [
                'mobile_layout' => ['paged', 'offcanvas']
            ]
        ]);

        $this->add_control('mobile_offcanvas_vertical_align', [
            'label' => __('Off-Canvas Vertical Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'top',
            'options' => [
                'top' => [
                    'title' => __('Top', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-v-align-top',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-v-align-middle',
                ],
                'bottom' => [
                    'title' => __('Bottom', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-v-align-bottom',
                ],
                'justify' => [
                    'title' => __('Justify', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-v-align-stretch',
                ]
            ],
            'prefix_class' => 'emm35',
            'condition' => [
                'mobile_layout' => 'offcanvas'
            ]
        ]);

        $this->add_control('mobile_offcanvas_close_btn', [
            'label' => __('Show Off-Canvas Close Button', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'condition' => [
                'mobile_layout' => 'offcanvas'
            ],
        ]);

        $this->add_control('mobile_paged_heading_type', [
            'label' => __('Default Heading Type', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'none' => __('None', 'mega-menu-pro-for-elementor'),
                'text' => __('Text', 'mega-menu-pro-for-elementor'),
                'icon' => __('Icon', 'mega-menu-pro-for-elementor'),
                'image' => __('Image', 'mega-menu-pro-for-elementor'),
            ],
            'default' => 'none',
            'condition' => [
                'mobile_layout' => 'paged'
            ]
        ]);

        $this->add_control('mobile_paged_heading_icon', [
            'label' => '',
            'label_hidden' => true,
            'type' => Controls_Manager::ICONS,
            'condition' => [
                'mobile_layout' => 'paged',
                'mobile_paged_heading_type' => 'icon'
            ]
        ]);

        $this->add_control('mobile_paged_title', [
            'label' => __('Default Heading Text', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Main Menu','mega-menu-pro-for-elementor'),
            'condition' => [
                'mobile_layout' => 'paged',
                'mobile_paged_heading_type' => 'text'
            ]
        ]);

        $this->add_control('mobile_paged_heading_image', [
            'label' => '',
            'label_hidden' => true,
            'type' => Controls_Manager::MEDIA,
            'condition' => [
                'mobile_layout' => 'paged',
                'mobile_paged_heading_type' => 'image'
            ]
        ]);

        $this->add_control('mobile_dropdown_overlap', [
            'label' => __('Dropdown Overlap', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'prefix_class' => 'emm38',
            'condition' => [
                'mobile_layout' => 'dropdown',
            ]
        ]);

        $this->add_control('mobile_dropdown_fullwidth', [
            'label' => __('Dropdown Full Width', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'frontend_available' => true,
            'condition' => [
                'mobile_layout' => 'dropdown',
                'mobile_dropdown_overlap' => 'yes'
            ],
        ]);

        $this->add_control('mobile_indicator', [
            'label' => __('Submenu Indicator', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'plus',
            'options' => [
                'plus' => __('Plus', 'mega-menu-pro-for-elementor'),
                'caret' => __('Caret', 'mega-menu-pro-for-elementor'),
                'angle' => __('Angle', 'mega-menu-pro-for-elementor'),
                'chevron' => __('Chevron', 'mega-menu-pro-for-elementor'),
                'hidden' => __('Hidden', 'mega-menu-pro-for-elementor')
            ],
            'prefix_class' => 'emm37',
            'condition' => [
                'mobile_layout!' => ['paged', 'hidden']
            ]
        ]);

        $this->add_control('mobile_highlight_current_item', [
            'label' => __('Highlight Current Menu Item', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'prefix_class' => 'emm79',
            'condition' => [
                'mobile_layout!' => 'hidden'
            ],
        ]);

        $this->add_control('mobile_push_indicator', [
            'label' => __('Push Sub Indicator To The End', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SWITCHER,
            'default' => '',
            'prefix_class' => 'emm21',
            'frontend_available' => true,
            'condition' => [
                'mobile_layout!' => ['paged', 'hidden'],
                'mobile_indicator!' => 'hidden'
            ]
        ]);

        $this->add_control('template_before_mobile_menu', [
            'label' => __('Template Before Navigation Menu', 'mega-menu-pro-for-elementor'),
            'label_block' => true,
            'type' => Controls_Manager::SELECT,
            'default' => '',
            'description' => __('Insert an Elementor section template before the navigation menu.', 'mega-menu-for-elementor'),
            'options' => $this->list_section_templates(),
            'condition' => [
                'mobile_layout!' => 'hidden'
            ]
        ]);

        $this->add_control('template_after_mobile_menu', [
            'label' => __('Template After Navigation Menu', 'mega-menu-pro-for-elementor'),
            'label_block' => true,
            'type' => Controls_Manager::SELECT,
            'default' => '',
            'description' => __('Insert an Elementor section template after the navigation menu.', 'mega-menu-for-elementor'),
            'options' => $this->list_section_templates(),
            'condition' => [
                'mobile_layout!' => 'hidden'
            ]
        ]);

        $this->end_controls_section();

		$this->start_controls_section('content__toggle_button', [
            'label' => __('Toggle Button', 'mega-menu-pro-for-elementor')
        ]);

        $this->add_control('toggle_layout', [
            'label' => __('Layout', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'default' => 'icon',
            'options' => [
                'text' => __('Text Only', 'mega-menu-pro-for-elementor'),
                'icon' => __('Icon Only', 'mega-menu-pro-for-elementor'),
                'text-icon' => __('Text & Icon', 'mega-menu-pro-for-elementor'),
                'custom' => __('Custom', 'mega-menu-pro-for-elementor')
            ],
            'frontend_available' => true
        ]);

        $this->add_control('toggle_custom_selector', [
            'label' => __('Toggle Selector', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::TEXT,
            'default' => '',
            'description' => __('Enter your toggle&#8217; CSS selector here to replace the default toggle.', 'mega-menu-pro-for-elementor'),
            'frontend_available' => true,
            'condition' => [
                'toggle_layout' => 'custom',
            ],
        ]);

        $this->add_control('toggle_text', [
            'label' => __('Text Label', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Menu','mega-menu-pro-for-elementor'),
            'condition' => [
                'toggle_layout!' => ['icon', 'custom']
            ],
        ]);

        $this->add_control('toggle_icon_type', [
            'label' => __('Icon Type', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'default' => __('Default', 'mega-menu-pro-for-elementor'),
                'custom' => __('Custom', 'mega-menu-pro-for-elementor'),
            ],
            'render_type' => 'none',
            'default' => 'default',
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon']
            ]
        ]);

        $this->add_control('toggle_icon', [
            'label' => __('Default Icon', 'mega-menu-for-elementor'),
            'label_hidden' => true,
            'type' => Controls_Manager::ICONS,
            'condition' => [
                'toggle_icon_type' => 'custom'
            ]
        ]);

        $this->add_control('toggle_close_icon', [
            'label' => __('Close Icon', 'mega-menu-for-elementor'),
            'label_hidden' => true,
            'type' => Controls_Manager::ICONS,
            'condition' => [
                'toggle_icon_type' => 'custom'
            ]
        ]);

        $this->add_control('toggle_align', [
            'label' => __('Toggle Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'center',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'selectors_dictionary' => [
                'left' => 'margin-right: auto',
                'center' => 'margin: 0 auto',
                'right' => 'margin-left: auto',
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13' => '{{VALUE}}',
            ],
            'condition' => [
                'toggle_layout!' => 'custom'
            ],
        ]);

        $this->end_controls_section();

		$this->start_controls_section('content__close_canvas_button', [
            'label' => __('Off-Canvas Close Button', 'mega-menu-pro-for-elementor'),
            'condition' => [
                'mobile_layout' => 'offcanvas',
                'mobile_offcanvas_close_btn' => 'yes'
            ]
        ]);

        $this->add_control('close_canvas_btn_icon_type', [
            'label' => __('Icon Type', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'default' => __('Default', 'mega-menu-pro-for-elementor'),
                'custom' => __('Custom', 'mega-menu-pro-for-elementor'),
            ],
            'render_type' => 'none',
            'default' => 'default',
        ]);

        $this->add_control('close_canvas_btn_icon', [
            'label' => '',
            'label_hidden' => true,
            'type' => Controls_Manager::ICONS,
            'condition' => [
                'close_canvas_btn_icon_type' => 'custom'
            ]
        ]);

        $this->add_control('close_canvas_btn_align', [
            'label' => __('Button Align', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'right',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-h-align-right',
                ],
            ],
            'selectors_dictionary' => [
                'left' => 'left:0',
                'center' => 'left:50%;transform:translateX(-50%)',
                'right' => 'right:0',
            ],
            'selectors' => [
                '{{WRAPPER}} .emm53' => '{{VALUE}}',
            ]
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style__desktop', [
            'label' => __('Desktop Menu', 'mega-menu-pro-for-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'layout!' => 'hidden'
            ]
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'typography',
            'selector' => '{{WRAPPER}} .emm0 .emm6'
        ]);

        $this->add_control('sub_z_index', [
            'label' => __('Submenus&#8217; z-index', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::NUMBER,
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm5' => 'z-index:{{VALUE}}'
            ]
        ]);

        $this->add_control('style__hr_top_menu_bar', [
            'type' => Controls_Manager::DIVIDER,
        ]);

		$this->add_control('heading_top_menubar', [
			'label' => __('Top Menu Bar', 'mega-menu-pro-for-elementor'),
			'type' => Controls_Manager::HEADING
        ]);

        $this->start_controls_tabs('tabs_menu_item_style');

        $this->start_controls_tab('tab_menu_item_normal', [
            'label' => __('Normal', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('color_menu_item', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6' => 'color:{{VALUE}}',
            ],
        ]);

        $this->add_control('bg_color_menu_item', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->add_control('color_indicator', [
            'label' => __('Submenu Indicator Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6 > .emm10' => 'color:{{VALUE}}',
            ]
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('tab_menu_item_hover', [
            'label' => __('Hover', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('color_menu_item_hover', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29:hover > .emm6' => 'color:{{VALUE}}',
            ]
        ]);

        $this->add_control('pointer_hover_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#39b54a',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6::before,{{WRAPPER}} .emm0 .emm29 > .emm6::after' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
                'pointer_animation_line!' => 'slide',
            ]
        ]);

        $this->add_control('framed_pointer_hover_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#39b54a',
            'selectors' => [
                '{{WRAPPER}} .emm30framed .emm29 > .emm6::before,{{WRAPPER}} .emm30framed .emm29 > .emm6::after' => 'border-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => 'framed'
            ]
        ]);

        $this->add_control('triangle_pointer_hover_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#39b54a',
            'selectors' => [
                '{{WRAPPER}} .emm30triangle .emm29 > .emm6::before' => 'border-top-color:transparent;border-bottom-color:{{VALUE}}',
                '{{WRAPPER}} .emm30triangle.emm30reverse .emm29 > .emm6::before' => 'border-top-color:{{VALUE}};border-bottom-color:transparent',
            ],
            'condition' => [
                'pointer' => 'triangle'
            ]
        ]);

        $this->add_control('slide_pointer_hover_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#39b54a',
            'selectors' => [
                '{{WRAPPER}} .emm28slide .emm29:last-child::before,{{WRAPPER}} .emm28slide .emm29:last-child::after' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
                'pointer_animation_line' => 'slide',
            ]
        ]);

        $this->add_control('color_menu_item_hover_pointer_bg', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6::before,{{WRAPPER}} .emm0 .emm29 > .emm6::after' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => 'background',
            ]
        ]);

        $this->add_control('bg_color_menu_item_hover', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29:hover > .emm6' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->add_control('color_indicator_hover', [
            'label' => __('Submenu Indicator Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6 > .emm10:hover' => 'color:{{VALUE}}'
            ]
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('tab_menu_item_active', [
            'label' => __('Active', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('color_menu_item_active', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29.emm17 > .emm6,{{WRAPPER}} .emm0 .emm29.emm32 > .emm6' => 'color:{{VALUE}}',
            ]
        ]);

        $this->add_control('pointer_active_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#fcb92c',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29.emm17 > .emm6::before,{{WRAPPER}} .emm0 .emm29.emm17 > .emm6::after,{{WRAPPER}} .emm0 .emm32 > .emm6::before,{{WRAPPER}} .emm0 .emm32 > .emm6::after' => 'background-color:{{VALUE}}'
            ],
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
                'pointer_animation_line!' => 'slide'
            ],
        ]);

        $this->add_control('framed_pointer_active_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#fcb92c',
            'selectors' => [
                '{{WRAPPER}} .emm30framed .emm29.emm17 > .emm6::before,
				{{WRAPPER}} .emm30framed .emm29.emm17 > .emm6::after,{{WRAPPER}} .emm30framed .emm32 > .emm6::before,
				{{WRAPPER}} .emm30framed .emm32 > .emm6::after' => 'border-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => 'framed'
            ]
        ]);

        $this->add_control('triangle_pointer_active_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#fcb92c',
            'selectors' => [
                '{{WRAPPER}} .emm30triangle .emm29.emm17 > .emm6::before,{{WRAPPER}} .emm30triangle .emm32 > .emm6::before' => 'border-top-color:transparent;border-bottom-color:{{VALUE}}',
                '{{WRAPPER}} .emm30triangle.emm30reverse .emm29.emm17 > .emm6::before,{{WRAPPER}} .emm30triangle.emm30reverse .emm32 > .emm6::before' => 'border-top-color:{{VALUE}};border-bottom-color:transparent',
            ],
            'condition' => [
                'pointer' => 'triangle'
            ]
        ]);

        $this->add_control('slide_pointer_active_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#fcb92c',
            'selectors' => [
                '{{WRAPPER}} .emm28slide .emm17.emm29:last-child::before,{{WRAPPER}} .emm28slide .emm17.emm29:last-child::after,{{WRAPPER}} .emm28slide .emm32:last-child::before,{{WRAPPER}} .emm28slide .emm32:last-child::after,{{WRAPPER}} .emm28slide .emm17 ~ .emm29:last-child::before,{{WRAPPER}} .emm28slide .emm17 ~ .emm29:last-child::after,{{WRAPPER}} .emm28slide .emm32 ~ .emm29:last-child::before,{{WRAPPER}} .emm28slide .emm32 ~ .emm29:last-child::after' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
                'pointer_animation_line' => 'slide',
            ]
        ]);

        $this->add_control('pointer_active_bg_color', [
            'label' => __('Pointer Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '#fcb92c',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29.emm17 > .emm6::before,{{WRAPPER}} .emm0 .emm29.emm17 > .emm6::after,{{WRAPPER}} .emm0 .emm32 > .emm6::before,{{WRAPPER}} .emm0 .emm32 > .emm6::after' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'pointer' => 'background',
            ]
        ]);

        $this->add_control('bg_color_menu_item_active', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29.emm17 > .emm6,{{WRAPPER}} .emm0 .emm29.emm32 > .emm6' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->add_control('color_indicator_active', [
            'label' => __('Submenu Indicator Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29.emm17 > .emm6 > .emm10' => 'color:{{VALUE}}'
            ]
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control('icon_font_size', [
            'label' => __('Icon Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm7' => 'font-size:{{SIZE}}px',
                '{{WRAPPER}} .emm0 .emm7 img' => 'width:{{SIZE}}px'
            ]
        ]);

        $this->add_responsive_control('indicator_font_size', [
            'label' => __('Submenu Indicator Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm10' => 'font-size:{{SIZE}}px',
            ],
            'condition' => [
                'indicator!' => 'none'
            ]
        ]);

        $this->add_responsive_control('pointer_thickness', [
            'label' => __('Pointer Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 20,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm30underline .emm29 > .emm6::after,{{WRAPPER}} .emm30overline .emm29 > .emm6::before,{{WRAPPER}} .emm30doubleline .emm29 > .emm6::before,{{WRAPPER}} .emm30doubleline .emm29 > .emm6::after,{{WRAPPER}} .emm28slide .emm29:last-child::before,{{WRAPPER}} .emm28slide .emm29:last-child::after' => 'height:{{SIZE}}px',
            ],
            'default' => [
                'unit' => 'px',
                'size' => 3
            ],
            'condition' => [
                'pointer' => ['underline', 'overline', 'doubleline'],
            ],
        ]);

        $this->add_responsive_control('framed_pointer_thickness', [
            'label' => __('Pointer Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 20,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm30framed .emm29 > .emm6::before' => 'border-width:{{SIZE}}px',
                '{{WRAPPER}} .emm30framed.emm28draw .emm29 > .emm6::before' => 'border-width:0 0 {{SIZE}}px {{SIZE}}px',
                '{{WRAPPER}} .emm30framed.emm28draw .emm29 > .emm6::after' => 'border-width:{{SIZE}}px {{SIZE}}px 0 0',
                '.rtl {{WRAPPER}} .emm30framed.emm28draw .emm29 > .emm6::before' => 'border-width:0 {{SIZE}}px {{SIZE}}px 0',
                '.rtl {{WRAPPER}} .emm30framed.emm28draw .emm29 > .emm6::after' => 'border-width:{{SIZE}}px 0 0 {{SIZE}}px',
                '{{WRAPPER}} .emm30framed.emm28corners .emm29 > .emm6::before' => 'border-width:{{SIZE}}px 0 0 {{SIZE}}px',
                '{{WRAPPER}} .emm30framed.emm28corners .emm29 > .emm6::after' => 'border-width:0 {{SIZE}}px {{SIZE}}px 0',
                '.rtl {{WRAPPER}} .emm30framed.emm28corners .emm29 > .emm6::before' => 'border-width:{{SIZE}}px {{SIZE}}px 0 0',
                '.rtl {{WRAPPER}} .emm30framed.emm28corners .emm29 > .emm6::after' => 'border-width:0 0 {{SIZE}}px {{SIZE}}px',
            ],
            'default' => [
                'unit' => 'px',
                'size' => 3
            ],
            'condition' => [
                'pointer' => 'framed',
            ],
        ]);

        $this->add_responsive_control('triangle_pointer_size', [
            'label' => __('Triangle Pointer Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 20
                ]
            ],
            'default' => [
                'unit' => 'px',
                'size' => 9,
            ],
            'selectors' => [
                '{{WRAPPER}} .emm30triangle .emm29 > .emm6::before' => 'border-width:0 {{SIZE}}px {{SIZE}}px {{SIZE}}px'
            ],
            'condition' => [
                'pointer' => 'triangle',
                'reverse_triangle_pointer' => ''
            ]
        ]);

        $this->add_responsive_control('reverse_triangle_pointer_size', [
            'label' => __('Triangle Pointer Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 20
                ]
            ],
            'default' => [
                'unit' => 'px',
                'size' => 9,
            ],
            'selectors' => [
                '{{WRAPPER}} .emm30triangle.emm30reverse .emm29 > .emm6::before' => 'border-width:{{SIZE}}px {{SIZE}}px 0 {{SIZE}}px'
            ],
            'condition' => [
                'pointer' => 'triangle',
                'reverse_triangle_pointer' => 'yes'
            ]
        ]);

		$this->add_responsive_control('triangle_pointer_offset', [
			'label' => __('Triangle Pointer Offset Top', 'mega-menu-pro-for-elementor' ),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => -50,
					'max' => 50,
				],
			],
            'default' => [
                'size' => 0,
                'unit' => 'px'
            ],
			'selectors' => [
				'{{WRAPPER}} .emm30triangle .emm29 > .emm6::before' => 'transform:translateX(-50%) translateY({{SIZE}}px)',
			],
            'condition' => [
                'pointer' => 'triangle'
            ]
		]);

        $this->add_responsive_control('padding_horizontal_menu_item', [
            'label' => __('Items&#8217; Horizontal Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6' => 'padding-left:{{SIZE}}px;padding-right:{{SIZE}}px',
            ],
        ]);

        $this->add_responsive_control('padding_vertical_menu_item', [
            'label' => __('Items&#8217; Vertical Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm6' => 'padding-top:{{SIZE}}px;padding-bottom:{{SIZE}}px',
            ],
        ]);

        $this->add_responsive_control('menu_space_between', [
            'label' => __('Margin Between Items', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}.emm2horizontal .emm0 .emm29:not(:last-child)' => 'margin-right:{{SIZE}}px',
                '.rtl {{WRAPPER}}.emm2horizontal .emm0 .emm29:not(:last-child)' => 'margin-left:{{SIZE}}px',
                '{{WRAPPER}}.emm2vertical .emm0 .emm29:not(:last-child)' => 'margin-bottom:{{SIZE}}px',
            ],
        ]);

        $this->add_control('style__hr_flyout_sub_menu', [
            'type' => Controls_Manager::DIVIDER,
        ]);

		$this->add_control('heading_flyout_menu', [
			'label' => __('Flyout Menus', 'mega-menu-pro-for-elementor'),
			'type' => Controls_Manager::HEADING
        ]);

        $this->start_controls_tabs('flyout_tabs_menu_item_style');

        $this->start_controls_tab('flyout_tab_menu_item_normal', [
            'label' => __('Normal', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('flyout_color_menu_item', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm6,{{WRAPPER}} .emm0 .emm23 .emm6 > .emm10' => 'color:{{VALUE}}',
            ],
        ]);

        $this->add_control('flyout_bg_color_menu_item', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23,{{WRAPPER}} .emm0 .emm23 .emm5' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('flyout_tab_menu_item_hover', [
            'label' => __('Hover', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('flyout_color_menu_item_hover', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emmi:hover > .emm6,{{WRAPPER}} .emm0 .emm23 .emmi:hover > .emm6 > .emm10' => 'color:{{VALUE}}',
            ]
        ]);

        $this->add_control('flyout_bg_color_menu_item_hover', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emmi:hover' => 'background-color:{{VALUE}}',
            ]
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('flyout_tab_menu_item_active', [
            'label' => __('Active', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('flyout_color_menu_item_active', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm17 > .emm6,{{WRAPPER}} .emm0 .emm23 .emm32 > .emm6,{{WRAPPER}} .emm0 .emm23 .emm17 > .emm6 > .emm10,{{WRAPPER}} .emm0 .emm23 .emm32 > .emm6 > .emm10' => 'color:{{VALUE}}',
            ]
        ]);

        $this->add_control('flyout_bg_color_menu_item_active', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm17,{{WRAPPER}} .emm0 .emm23 .emm32' => 'background-color:{{VALUE}}',
            ]
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'flyout_typography',
            'selector' => '{{WRAPPER}} .emm0 .emm23 .emm6'
        ]);

        $this->add_responsive_control('flyout_panel_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm77 .emm5' => 'padding-top:{{TOP}}px;padding-bottom:{{BOTTOM}}px',
                '{{WRAPPER}} .emm0 .emm77 .emm5 .emmi' => 'padding-left:{{LEFT}}px;padding-right:{{RIGHT}}px',
            ]
        ]);

        $this->add_responsive_control('flyout_top_border_radius', [
            'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm29 > .emm23' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('flyout_sub_width', [
            'label' => __('Width', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 220,
                    'max' => 480
                ]
            ],
            'default' => [
                'unit' => 'px',
                'size' => 220,
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23,{{WRAPPER}} .emm0 .emm24' => 'width:{{SIZE}}px',
            ]
        ]);

        $this->add_responsive_control('flyout_indicator_font_size', [
            'label' => __('Submenu Indicator Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm10' => 'font-size:{{SIZE}}px',
            ],
            'condition' => [
                'indicator!' => 'none'
            ]
        ]);

        $this->add_responsive_control('flyout_padding_horizontal_menu_item', [
            'label' => __('Items&#8217; Horizontal Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm6' => 'padding-left:{{SIZE}}px;padding-right:{{SIZE}}px',
            ],
        ]);

        $this->add_responsive_control('flyout_padding_vertical_menu_item', [
            'label' => __('Items&#8217; Vertical Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm6' => 'padding-top:{{SIZE}}px; padding-bottom:{{SIZE}}px',
            ],
        ]);

        $this->add_control('heading_style_flyout__items_separator', [
            'label' => __('Items\' Borderline', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'flyout_items_separator_border',
            'selector' => '{{WRAPPER}} .emm0 .emm23 .emmi:not(:last-child) > .emm6',
            'exclude' => ['width'],
        ]);

        $this->add_responsive_control('flyout_items_separator_width', [
            'label' => __('Border Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 20,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emmi:not(:last-child) > .emm6' => 'border-bottom-width:{{SIZE}}px',
            ],
            'condition' => [
                'flyout_items_separator_border_border!' => '',
            ],
        ]);

		$this->add_control('heading_top_sub', [
			'label' => __('Top Level Submenus', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before'
        ]);

		$this->add_responsive_control('sub_top_distance', [
			'label' => __('Offset Top', 'mega-menu-pro-for-elementor' ),
			'type' => Controls_Manager::SLIDER,
			'range' => [
				'px' => [
					'min' => -100,
					'max' => 100,
				],
			],
            'default' => [
                'size' => 0,
                'unit' => 'px'
            ],
			'selectors' => [
				'{{WRAPPER}} .emm0 .emm29 > .emm5' => 'margin-top:{{SIZE}}px',
			]
		]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'sub_box_shadow',
            'exclude' => ['box_shadow_position'],
            'selector' => '{{WRAPPER}} .emm0 .emm29 > .emm5'
        ]);

		$this->add_control('heading_sub_sub', [
			'label' => __('Sub Level Submenus', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before'
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'sub_sub_box_shadow',
            'exclude' => ['box_shadow_position'],
            'selector' => '{{WRAPPER}} .emm0 .emm31.emm61 > .emm5'
        ]);

        $this->add_responsive_control('flyout_sub_border_radius', [
            'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm0 .emm23 .emm24' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style__mobile', [
            'label' => __('Mobile Menu', 'mega-menu-pro-for-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'mobile_layout!' => 'hidden'
            ]
        ]);

        $this->start_controls_tabs('tabs_mobile_item_style');

        $this->start_controls_tab('tab_mobile_item_normal', [
            'label' => __('Normal', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('color_mobile_item', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm6' => 'color:{{VALUE}}',
            ],
        ]);

        $this->add_control('background_color_mobile_item', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm29' => 'background-color:{{VALUE}}',
            ]
        ]);

        $this->add_control('mobile_color_indicator', [
            'label' => __('Submenu Indicator Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm10' => 'color:{{VALUE}}',
            ]
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('tab_mobile_item_active', [
            'label' => __('Active', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('color_mobile_item_active', [
            'label' => __('Items&#8217; Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm17 > .emm6,{{WRAPPER}}.emm79yes .emm20 .emm32 > .emm6' => 'color:{{VALUE}}',
            ],
        ]);

        $this->add_control('background_color_mobile_item_active', [
            'label' => __('Items&#8217; Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm29.emm17,{{WRAPPER}}.emm79yes .emm20 .emm32' => 'background-color:{{VALUE}}',
            ]
        ]);

        $this->add_control('mobile_color_indicator_active', [
            'label' => __('Submenu Indicator Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm17 > .emm6 > .emm10,{{WRAPPER}}.emm79yes .emm20 .emm32 > .emm6 > .emm10' => 'color:{{VALUE}}',
            ]
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'mobile_item_typography',
            'exclude' => ['line_height'],
            'selector' => '{{WRAPPER}} .emm20 .emm6',
        ]);

		$this->add_group_control(Group_Control_Background::get_type(), [
            'name' => 'mobile_menu_background',
            'selector' => '{{WRAPPER}} .emm20'
        ]);

        $this->add_responsive_control('mobile_menu_margin', [
            'label' => __('Margin', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm20' => 'margin:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('mobile_menu_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm20' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('mobile_icon_font_size', [
            'label' => __('Icon Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm7' => 'font-size:{{SIZE}}px',
                '{{WRAPPER}} .emm20 .emm7 img' => 'width:{{SIZE}}px',
            ]
        ]);

        $this->add_responsive_control('mobile_indicator_font_size', [
            'label' => __('Submenu Indicator Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm10' => 'font-size:{{SIZE}}px',
            ]
        ]);

        $this->add_responsive_control('mobile_item_horizontal_padding', [
            'label' => __('Items&#8217; Horizontal Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm6,{{WRAPPER}} .emm20 .emm40' => 'padding-left:{{SIZE}}px;padding-right:{{SIZE}}px',
            ],
        ]);

        $this->add_responsive_control('mobile_item_vertical_padding', [
            'label' => __('Items&#8217; Vertical Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm6,{{WRAPPER}} .emm20 .emm40' => 'padding-top:{{SIZE}}px;padding-bottom:{{SIZE}}px',
            ],
        ]);

        $this->add_control('heading_style_mobile__items_separator', [
            'label' => __('Items\' Borderline', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before'
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'items_separator_border',
            'selector' => '{{WRAPPER}} .emm20 .emmi:not(:last-child),{{WRAPPER}} .emm20 .emm17 > .emm6',
            'exclude' => ['width'],
        ]);

        $this->add_responsive_control('mobile_items_separator_width', [
            'label' => __('Border Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'max' => 20,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm20 .emmi:not(:last-child),{{WRAPPER}} .emm20 .emm17 > .emm6' => 'border-bottom-width:{{SIZE}}px',
            ],
            'condition' => [
                'items_separator_border_border!' => '',
            ],
        ]);

        $this->add_control('mobile_dropdown_panel_heading', [
            'label' => __('Dropdown Panel', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

        $this->add_control('mobile_dropdown_align', [
            'label' => __('Alignment', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::CHOOSE,
            'default' => 'left',
            'options' => [
                'left' => [
                    'title' => __('Left', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'mega-menu-pro-for-elementor'),
                    'icon' => 'eicon-text-align-right',
                ]
            ],
            'prefix_class' => 'emm39',
            'condition' => [
                'mobile_layout' => 'dropdown',
                'mobile_dropdown_overlap' => 'yes',
                'mobile_dropdown_fullwidth!' => 'yes'
            ]
        ]);

        $this->add_responsive_control('mobile_dropdown_width', [
            'label' => __('Width', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'vw', '%'],
            'range' => [
                'px' => [
                    'min' => 200,
                    'max' => 1200,
                ],
                'vw' => [
                    'min' => 30,
                    'max' => 100
                ],
                '%' => [
                    'min' => 30,
                    'max' => 100
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'width:{{SIZE}}{{UNIT}}'
            ],
            'condition' => [
                'mobile_layout' => 'dropdown',
                'mobile_dropdown_overlap' => 'yes',
                'mobile_dropdown_fullwidth!' => 'yes'
            ],
        ]);

        $this->add_responsive_control('dropdown_offset_top', [
            'label' => __('Offset Top', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => -100,
                    'max' => 100,
                ],
            ],
            'default' => [
                'size' => 30,
                'unit' => 'px'
            ],
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'margin-top:{{SIZE}}px',
                '{{WRAPPER}}.emm38yes .emm15' => 'margin-top:0 !important;top:{{SIZE}}px !important',
            ],
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);


        $this->add_responsive_control('dropdown_max_height', [
            'label' => __('Max Height', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'vh'],
            'range' => [
                'px' => [
                    'min' => 100,
                    'max' => 680,
                ],
                'vh' => [
                    'min' => 100,
                    'max' => 680,
                ],
            ],
            'description' => __('When the menu is inside a sticky section, contents that exceed screen height may be cut off because of fixed position. Set a max height to avoid that.', 'mega-menu-pro-for-elementor'),
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'max-height:{{SIZE}}{{UNIT}}'
            ],
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'dropdown_border',
            'selector' => '{{WRAPPER}} .emm15',
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

		$this->add_group_control(Group_Control_Background::get_type(), [
            'name' => 'mobile_dropdown_panel_background',
            'selector' => '{{WRAPPER}} .emm15',
            'condition' => [
                'mobile_layout' => 'dropdown'
            ]
        ]);

        $this->add_group_control(Group_Control_Box_Shadow::get_type(), [
            'name' => 'dropdown_box_shadow',
            'exclude' => ['box_shadow_position'],
            'selector' => '{{WRAPPER}} .emm15',
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

        $this->add_responsive_control('mobile_dropdown_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px'
            ],
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

        $this->add_responsive_control('mobile_dropdown_border_radius', [
            'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px'
            ],
            'condition' => [
                'mobile_layout' => 'dropdown',
            ],
        ]);

        $this->add_control('style__mobile_offcanvas_panel_heading', [
            'label' => __('Off-Canvas Panel', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'mobile_layout' => ['paged', 'offcanvas']
            ],
        ]);

        $this->add_responsive_control('mobile_offcanvas_panel_width', [
            'label' => __('Width', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'vw', '%'],
            'range' => [
                'px' => [
                    'min' => 200,
                    'max' => 1024,
                ],
                'vw' => [
                    'min' => 30,
                    'max' => 100
                ],
                '%' => [
                    'min' => 30,
                    'max' => 100
                ],
            ],
            'default' => [
                'size' => 300,
                'unit' => 'px'
            ],
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'width:{{SIZE}}{{UNIT}}'
            ],
            'condition' => [
                'mobile_layout' => ['offcanvas', 'paged']
            ],
        ]);

        $this->add_responsive_control('mobile_offcanvas_panel_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm15' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px'
            ],
            'condition' => [
                'mobile_layout' => ['paged', 'offcanvas'],
            ],
        ]);

        $this->add_control('mobile_canvas_mask_color', [
            'label' => __('Overlay Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm14' => 'background-color:{{VALUE}}'
            ],
            'condition' => [
                'mobile_layout' => 'offcanvas'
            ],
        ]);

		$this->add_group_control(Group_Control_Background::get_type(), [
            'name' => 'mobile_offcanvas_panel_background',
            'selector' => '{{WRAPPER}} .emm15',
            'condition' => [
                'mobile_layout' => ['paged', 'offcanvas']
            ]
        ]);

        $this->add_control('style__mobile_paged_head_heading', [
            'label' => __('Paged Menu Header', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'mobile_layout' => 'paged'
            ],
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'mobile_paged_title_typography',
            'exclude' => ['line_height'],
            'selector' => '{{WRAPPER}} .emm20 .emm46',
            'condition' => [
                'mobile_layout' => 'paged'
            ],
        ]);

        $this->add_control('mobile_paged_head_color', [
            'label' => __('Text Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm46,{{WRAPPER}} .emm20 .emm43,{{WRAPPER}} .emm20 .emm45' => 'color:{{VALUE}}',
            ],
            'condition' => [
                'mobile_layout' => 'paged'
            ],
        ]);

        $this->add_control('mobile_paged_head_bg_color', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm40' => 'background-color:{{VALUE}}',
            ],
            'condition' => [
                'mobile_layout' => 'paged'
            ],
        ]);

        $this->add_responsive_control('paged_heading_icon_font_size', [
            'label' => __('Heading Icon Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 8,
                    'max' => 100
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm60 img' => 'width:{{SIZE}}px',
                '{{WRAPPER}} .emm60 .emm49' => 'font-size:{{SIZE}}px',
            ],
            'condition' => [
                'mobile_layout' => 'paged',
                'mobile_paged_heading_type' => 'icon'
            ]
        ]);

        $this->add_responsive_control('paged_heading_image_size', [
            'label' => __('Heading Image Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 8,
                    'max' => 100
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm60 img' => 'width:{{SIZE}}px'
            ],
            'condition' => [
                'mobile_layout' => 'paged',
                'mobile_paged_heading_type' => 'image'
            ]
        ]);

        $this->add_responsive_control('paged_nav_icon_font_size', [
            'label' => __('Back & Close Icon Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 8,
                    'max' => 50
                ]
            ],
            'default' => [
                'unit' => 'px',
                'size' => 18,
            ],
            'selectors' => [
                '{{WRAPPER}} .emm40 .emm43,{{WRAPPER}} .emm40 .emm45' => 'font-size:{{SIZE}}px',
            ],
            'condition' => [
                'mobile_layout' => 'paged'
            ]
        ]);

        $this->add_group_control(Group_Control_Border::get_type(), [
            'name' => 'mobile_paged_header_border',
            'selector' => '{{WRAPPER}} .emm40',
            'condition' => [
                'mobile_layout' => 'paged',
            ],
        ]);

        $this->add_responsive_control('mobile_paged_head_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm20 .emm40' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px'
            ],
            'condition' => [
                'mobile_layout' => 'paged',
            ],
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style__toggle', [
            'label' => __('Toggle Button', 'mega-menu-pro-for-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'mobile_layout!' => 'hidden',
                'toggle_layout!' => 'custom'
            ],
        ]);

        $this->start_controls_tabs('tabs_toggle_style');

        $this->start_controls_tab('tab_toggle_style_normal', [
            'label' => __('Normal', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('toggle_color', [
            'label' => __('Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm55,{{WRAPPER}} .emm13 .emm58' => 'color:{{VALUE}}',
                '{{WRAPPER}} .emm13 .emm56,{{WRAPPER}} .emm13 .emm56::before,{{WRAPPER}} .emm13 .emm56::after' => 'background-color:{{VALUE}}'
            ],
        ]);

        $this->add_control('toggle_background_color', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm13' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('style__tab_toggle_hover', [
            'label' => __('Hover', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('toggle_color_hover', [
            'label' => __('Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm13:hover .emm58' => 'color:{{VALUE}}',
                '{{WRAPPER}} .emm13:hover .emm56,{{WRAPPER}} .emm13:hover .emm56::before,{{WRAPPER}} .emm13:hover .emm56::after' => 'background-color:{{VALUE}}'
            ],
        ]);

        $this->add_control('toggle_background_color_hover', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm13:hover' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('style__tab_toggle_active', [
            'label' => __('Active', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('toggle_color_active', [
            'label' => __('Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm13.emm57 .emm58' => 'color:{{VALUE}}',
                '{{WRAPPER}} .emm13.emm57 .emm56,{{WRAPPER}} .emm13.emm57 .emm56::before,{{WRAPPER}} .emm13.emm57 .emm56::after' => 'background-color:{{VALUE}}'
            ],
        ]);

        $this->add_control('toggle_background_color_active', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm13.emm57' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control('style__toggle_typo_sep', [
            'type' => Controls_Manager::DIVIDER,
        ]);

        $this->add_group_control(Group_Control_Typography::get_type(), [
            'name' => 'mobile_toggle_typography',
            'exclude' => ['line_height'],
            'selector' => '{{WRAPPER}} .emm58',
            'condition' => [
                'toggle_layout!' => 'icon'
            ]
        ]);

        $this->add_responsive_control('toggle_icon_font_size', [
            'label' => __('Icon Font Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm55' => 'font-size:{{SIZE}}px',
                '{{WRAPPER}} .emm13 .emm55 img' => 'width:{{SIZE}}px',
            ],
            'condition' => [
                'toggle_icon_type' => 'custom'
            ]
        ]);

        $this->add_responsive_control('toggle_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm13' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('toggle_border_radius', [
            'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm13' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('toggle_icon_width', [
            'label' => __('Hamburger Icon Width', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 12,
                    'max' => 100
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm55' => 'width:{{SIZE}}px',
            ],
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon'],
                'toggle_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('toggle_icon_height', [
            'label' => __('Hamburger Icon Height', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 12,
                    'max' => 100
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm55' => 'height:{{SIZE}}px',
            ],
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon'],
                'toggle_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('toggle_icon_bar_thickness', [
            'label' => __('Hamburger Bars&#8217; Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 10
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm56,{{WRAPPER}} .emm13 .emm56::before,{{WRAPPER}} .emm13 .emm56::after' => 'height:{{SIZE}}px',
            ],
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon'],
                'toggle_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('toggle_icon_bar_space', [
            'label' => __('Distance Between Hamburger Bars', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 20
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm56::before' => 'top:-{{SIZE}}px',
                '{{WRAPPER}} .emm13 .emm56::after' => 'bottom:-{{SIZE}}px'
            ],
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon'],
                'toggle_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('toggle_icon_bar_border_radius', [
            'label' => __('Hamburger Bars&#8217; Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm13 .emm56,{{WRAPPER}} .emm13 .emm56::before,{{WRAPPER}} .emm13 .emm56::after' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ],
            'condition' => [
                'toggle_layout' => ['icon', 'text-icon'],
                'toggle_icon_type' => 'default'
            ]
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style__close_canvas_button', [
            'label' => __('Off-Canvas Close Button', 'mega-menu-pro-for-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'mobile_layout' => 'offcanvas',
                'mobile_offcanvas_close_btn' => 'yes'
            ],
        ]);

        $this->start_controls_tabs('tabs_close_canvas_btn_style');

        $this->start_controls_tab('tab_close_canvas_btn_style_normal', [
            'label' => __('Normal', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('close_canvas_btn_color', [
            'label' => __('Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .emm53 .emm55' => 'color:{{VALUE}}',
                '{{WRAPPER}} .emm53 .emm56,{{WRAPPER}} .emm53 .emm56::before,{{WRAPPER}} .emm53 .emm56::after' => 'background-color:{{VALUE}}'
            ],
        ]);

        $this->add_control('close_canvas_btn_bg_color', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->start_controls_tab('style__tab_close_canvas_btn_hover', [
            'label' => __('Hover', 'mega-menu-pro-for-elementor'),
        ]);

        $this->add_control('close_canvas_btn_color_hover', [
            'label' => __('Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm53:hover .emm55' => 'color:{{VALUE}}',
                '{{WRAPPER}} .emm53:hover .emm56,{{WRAPPER}} .emm53:hover .emm56::before,{{WRAPPER}} .emm53:hover .emm56::after' => 'background-color:{{VALUE}}'
            ],
        ]);

        $this->add_control('close_canvas_btn_bg_color_hover', [
            'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .emm53:hover' => 'background-color:{{VALUE}}',
            ],
        ]);

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control('close_canvas_btn_margin_left', [
            'label' => __('Margin', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'allowed_dimensions' => ['top', 'left'],
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'margin-top:{{TOP}}px;margin-bottom:{{BOTTOM}}px;margin-left:{{LEFT}}px',
            ],
            'condition' => [
                'close_canvas_btn_align' => 'left'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_margin_center', [
            'label' => __('Margin', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'allowed_dimensions' => ['top'],
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'margin-top:{{TOP}}px;margin-bottom:{{BOTTOM}}px',
            ],
            'condition' => [
                'close_canvas_btn_align' => 'center'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_margin_right', [
            'label' => __('Margin', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'allowed_dimensions' => ['top', 'right'],
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'margin-top:{{TOP}}px;margin-bottom:{{BOTTOM}}px;margin-right:{{RIGHT}}px',
            ],
            'condition' => [
                'close_canvas_btn_align' => 'right'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_padding', [
            'label' => __('Padding', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_border_radius', [
            'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm53' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_icon_size', [
            'label' => __('Icon Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 4,
                    'max' => 50
                ]
            ],
            'selectors' => [
                '{{WRAPPER}} .emm53 .emm55' => 'font-size:{{SIZE}}px',
                '{{WRAPPER}} .emm53 .emm55 img' => 'width:{{SIZE}}px',
            ],
            'condition' => [
                'close_canvas_btn_icon_type' => 'custom'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_width', [
            'label' => __('Icon Size', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 12,
                    'max' => 100
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm53 .emm55' => 'width:{{SIZE}}px',
            ],
            'condition' => [
                'close_canvas_btn_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_bar_thickness', [
            'label' => __('Crossbar Thickness', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 10
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .emm53 .emm56,{{WRAPPER}} .emm53 .emm56::before,{{WRAPPER}} .emm53 .emm56::after' => 'height:{{SIZE}}px',
            ],
            'condition' => [
                'close_canvas_btn_icon_type' => 'default'
            ]
        ]);

        $this->add_responsive_control('close_canvas_btn_bar_border_radius', [
            'label' => __('Crossbar Border Radius', 'mega-menu-pro-for-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'selectors' => [
                '{{WRAPPER}} .emm53 .emm56,{{WRAPPER}} .emm53 .emm56::before,{{WRAPPER}} .emm53 .emm56::after' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px',
            ],
            'condition' => [
                'close_canvas_btn_icon_type' => 'default'
            ]
        ]);

        $this->end_controls_section();
    }

    /**
     * Render
     */
    protected function render()
    {
        $settings = $this->get_active_settings();
        $is_edit_mode = Plugin::$instance->editor->is_edit_mode();

        if (empty($settings['menu'])) {
            echo '<p>' . __('No menu selected', 'mega-menu-pro-for-elementor') . '</p>';
            return;
        }

        $menu = get_term_by('slug', $settings['menu'], 'nav_menu');

        if (is_wp_error($menu)) {
            echo '<p>' . __('Invalid WordPress nav menu.', 'mega-menu-pro-for-elementor') . '</p>';
            return;
        }

        if ('horizontal' == $settings['layout']) {
            $desktop_sub_animation = $settings['sub_animation'];
        } elseif ('vertical' == $settings['layout']) {
            $desktop_sub_animation = $settings['vertical_sub_animation'];
        } else {
            $desktop_sub_animation = 'hidden';
        }

        $this->add_render_attribute('menu-toggle', [
            'class' => 'emm13 emm54' . $settings['toggle_layout'],
            'tabindex' => '0',
            'aria-label' => __('Mobile Menu Toggle', 'mega-menu-pro-for-elementor'),
            'aria-pressed' => 'false',
            'aria-expanded' => 'false',
            'aria-haspopup' => 'true',
            'aria-controls' => 'emm-' . $settings['menu']
        ]);

        $this->add_render_attribute('close-canvas-button', [
            'class' => 'emm53 emm57',
            'tabindex' => '0'
        ]);

        if ($is_edit_mode) {
            $this->add_render_attribute('menu-toggle', [
                'class' => 'elementor-clickable',
            ]);
            $this->add_render_attribute('close-canvas-button', [
                'class' => 'elementor-clickable',
            ]);
        }

        $this->add_render_attribute('desktop-menu', [
            'class' => 'emm27 emm0 emm33' . $desktop_sub_animation,
            'aria-label' => __('Desktop menu', 'mega-menu-pro-for-elementor')
        ]);

        $this->add_render_attribute('mobile-menu', [
            'id' => 'emm-' . $settings['menu'],
            'class' => 'emm27 emm20',
            'aria-label' => __('Mobile menu', 'mega-menu-pro-for-elementor')
        ]);

        $this->add_inline_editing_attributes('toggle_text');
        $this->add_inline_editing_attributes('mobile_paged_title');

        if ($is_edit_mode || ('hidden' != $settings['layout'] && 'none' != $settings['breakpoint'])) :
            if ($settings['pointer']) {
                $this->add_render_attribute('desktop-menu', 'class', 'emm30' . $settings['pointer']);
                if ($settings['reverse_triangle_pointer']) {
                    $this->add_render_attribute('desktop-menu', 'class', 'emm30reverse');
                }
                foreach ($settings as $key => $value) {
                    if (0 === strpos($key, 'pointer_animation') && $value) {
                        $this->add_render_attribute('desktop-menu', 'class', 'emm28' . $value);
                        break;
                    }
                }
            }
            ?><nav <?php echo $this->get_render_attribute_string('desktop-menu'); ?>><?php
                scemm_render_menu([
                    'menu' => $menu,
                    'item_spacing' => 'discard',
                    'walker' => new MegaMenuWalker($settings)
                ]);
            ?></nav><?php
        endif;

        if ('hidden' != $settings['mobile_layout'] || $is_edit_mode) :
            ?><button <?php echo $this->get_render_attribute_string('menu-toggle'); ?>><?php
                if (!empty($settings['toggle_icon']['value'])) {
                    echo scemm_render_icon($settings['toggle_icon'], 'emm55 emm49');
                    if (!empty($settings['toggle_close_icon']['value']))
                        echo scemm_render_icon($settings['toggle_close_icon'], 'emm55 emm80');
                } else {
                    echo '<span class="emm55 emm59"><i class="emm56"></i></span>';
                }
            ?><span class="emm58" <?php echo $this->get_render_attribute_string('toggle-text'); ?>><?php echo $settings['toggle_text'] ?></span>
            </button>
            <div class="emm14" aria-hidden="true"></div>
            <div class="emm15" aria-hidden="true"><?php
                if ($settings['mobile_offcanvas_close_btn']) {
                ?><button <?php echo $this->get_render_attribute_string('close-canvas-button'); ?>><?php
                    if (!empty($settings['close_canvas_btn_icon']['value'])) :
                        echo scemm_render_icon($settings['offcanvas_close_icon'], 'emm55 emm49');
                    else :
                        echo '<span class="emm55 emm59"><i class="emm56"></i></span>';
                    endif;
                ?></button><?php
                }
                if ($settings['template_before_mobile_menu']) {
                    $this->render_template($settings['template_before_mobile_menu']);
                }
                ?><nav <?php echo $this->get_render_attribute_string('mobile-menu'); ?>><?php
                    if ($settings['mobile_layout'] == 'paged' || $is_edit_mode) {
                        ?><div class="emm40">
                            <button class="emm43" tabindex="0" aria-label="<?php _e('Return back', 'mega-menu-pro-for-elementor') ?>" aria-pressed="false"><i></i></button><?php
                            if (!empty($settings['mobile_paged_heading_icon']['value'])) :
                                 ?><div class="emm46 emm60 emm48"><?php echo scemm_render_icon($settings['mobile_paged_heading_icon'], 'emm49'); ?></div><?php
                            elseif (!empty($settings['mobile_paged_heading_image']['url'])) :
                                ?><div class="emm46 emm60 emm48"><img role="presentation" src="<?php echo $settings['mobile_paged_heading_image']['url'] ?>"></div><?php
                            else :
                                ?><div class="emm46 emm60 emm48"><span <?php echo $this->get_render_attribute_string('paged-title'); ?>><?php echo $settings['mobile_paged_title'] ?></span></div><?php
                            endif;
                            ?><button class="emm45" aria-label="<?php _e('Close all menus', 'mega-menu-pro-for-elementor') ?>"><i class="eicon-editor-close"></i></button>
                        </div><div class="emm50"><?php
                    }
                    scemm_render_menu([
                        'menu' => $menu,
                        'item_spacing' => 'discard',
                        'walker' => new MegaMenuWalker($settings, true)
                    ]);
                    if ($settings['mobile_layout'] == 'paged' || $is_edit_mode) echo '</div>';
                ?></nav><?php
                if ($settings['template_after_mobile_menu']) {
                    $this->render_template($settings['template_after_mobile_menu']);
                }
            ?></div><?php
        endif;
    }

    /**
     * @return array
     */
    private function list_available_menus()
    {
        $menus = wp_get_nav_menus();

        $options = [];

        foreach ($menus as $menu) {
            $options[$menu->slug] = $menu->name;
        }

        return $options;
    }

    /**
     * @return array
     */
    private function list_section_templates()
    {
        $templates = [
            '' => __('None', 'mega-menu-pro-for-elementor')
        ];

        $posts = get_posts([
            'post_type' => 'elementor_library',
            'posts_per_page' => -1,
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
            'tax_query' => [
                [
                    'taxonomy' => 'elementor_library_type',
                    'field'    => 'slug',
                    'terms'    => 'section'
                ]
            ]
        ]);

        if ($posts) {
            foreach ($posts as $post) {
                $templates[$post->post_name] = $post->post_title;
            }
        }

        return $templates;
    }

    /**
     * Render an Elementor template
     */
    private function render_template($slug)
    {
        $tpl = get_page_by_path($slug, OBJECT, 'elementor_library');

        if ($tpl) {
            echo Plugin::instance()->frontend->get_builder_content_for_display($tpl->ID);
        } else {
            _e('Template not found!', 'mega-menu-pro-for-elementor');
        }
    }
}
