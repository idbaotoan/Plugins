<?php namespace SC\EMM;

use Walker_Nav_Menu;
use Elementor\Plugin;
use Elementor\Core\Responsive\Responsive;

/**
 * MegaMenuWalker
 */
final class MegaMenuWalker extends Walker_Nav_Menu
{
    /**
     * @var bool
     */
    private $is_rtl;

    /**
     * @var bool
     */
    private $is_mobile;

    /**
     * @var bool
     */
    private $is_preview;

    /**
     * @var bool
     */
    private $is_edit_mode;

    /**
     * @var array
     */
    private $menu_settings;

    /**
     * Constructor
     */
    public function __construct(array $menu_settings, $is_mobile = false)
    {
        $this->is_rtl = is_rtl();
        $this->is_mobile = $is_mobile;
        $this->is_preview = Plugin::$instance->preview->is_preview_mode();
        $this->is_edit_mode = Plugin::$instance->editor->is_edit_mode();
        $this->menu_settings = $menu_settings;
    }

    /**
     * @see \Walker::start_lvl()
     */
    public function start_lvl(&$output, $depth = 0, $args = [])
    {
        $html_classes = 'emm5 emm78' . $depth;

        if ($depth > 0) {
            $html_classes .= ' emm24';
        } else {
            $html_classes .= ' emm23';
        }

        $output .= '<ul class="' . $html_classes . '">';
    }

    /**
     * @see \Walker::end_lvl()
     */
    public function end_lvl(&$output, $depth = 0, $args = [])
    {
        $output .= '</ul>';
    }

    /**
     * @see \Walker::start_el()
     */
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $atts = ['class' => 'emm6'];
        $content = false;
        $settings = $this->get_item_settings($item->ID);

        if (!$this->is_item_viewable($settings['users'])) {
            return;
        }

        $_class = [];
        $classes = (array)$item->classes;
        $has_child = in_array('menu-item-has-children', $classes);

        if ($settings['hide_on_mobile']) {
            $_class[] = 'elementor-hidden-phone';
        }

        if ($settings['hide_on_tablet']) {
            $_class[] = 'elementor-hidden-tablet';
        }

        if ($settings['hide_on_desktop']) {
            $_class[] = 'elementor-hidden-desktop';
        }

        if ($settings['show_sub_mobile'] && $this->is_mobile) {
            $_class[] = 'emm17';
        }

        $_class[] = 'emmi emmi' . $item->ID;

        if ($has_child) {
            $_class[] = 'emm31';
            $atts['aria-haspopup'] = 'true';
            if (!$depth) {
                $_class[] = 'emm77';
            }
        }

        if ($settings['is_mega']) {
            $atts['aria-haspopup'] = 'true';
            $_class[] = 'emm31 emm63';
            $content = $this->get_item_content($item->ID);
            if ($settings['enforce_mobile_layout']) {
                $_class[] = 'emm3';
            }
        }

        if ($depth) {
            $_class[] = 'emm61';
        } else {
            $_class[] = 'emm29';
        }

        if (!$depth && !$has_child && !$settings['is_mega']) {
            $_class[] = 'emm62';
        }

        if (in_array('current-menu-item', $classes)) {
            $_class[] = 'emm64';
            if ($this->menu_settings['highlight_current_item']) {
                $_class[] = 'emm32';
            }
        }

        if (in_array('current-menu-ancestor', $classes) && $this->menu_settings['highlight_current_item']) {
            $_class[] = 'emm32';
        }

        $atts['rel'] = !empty($item->xfn) ? $item->xfn : '';
        $atts['href'] = !empty($item->url) ? $item->url : '';
        $atts['title'] = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';

        if (false !== strpos($atts['href'], '#')) {
            if (strlen($atts['href']) > 1) {
                $_class[] = 'emm65';
            } else {
                $_class[] = 'emm66';
            }
        }

        $html_classes = join(' ', $_class);

        if (!empty($item->_classes)) {
            $html_classes .= ' ' . join(' ', $item->_classes);
        }

        $output .= '<li class="' . $html_classes . '" data-id="' . $item->ID . '">';

        if ($this->is_edit_mode) {
            $output .= '<span class="emm67 elementor-clickable" title="' . __('Click to edit the menu item', 'mega-menu-pro-for-elementor') . '"><i class="eicon-edit">&nbsp;&nbsp;</i><span>' . __('Edit Item', 'mega-menu-pro-for-elementor') . '</span></span>';
        }

        $attributes = '';

        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        if ($atts['target'] == '_blank') {
            $attributes .= ' aria-label="' . __('External link:', 'mega-menu-pro-for-elementor') . ' ' . $item->title . '"';
        }

        $output .= '<a'. $attributes . '>';

        if (!empty($settings['icon'])) {
            $output .= scemm_render_icon($settings['icon']);
        }

        if (!$settings['hide_title'] || !empty($settings['icon'])) {
            $output .= '<span class="emm8';
            $output .= $settings['hide_title'] ? ' elementor-screen-only">' : '">';
            $output .= $item->title;
            $output .= '</span>';
        }

        if ($settings['show_badge']) {
            $output .= $this->get_item_badge($settings);
        }

        if ($settings['is_mega'] || $has_child) {
            $output .= '<button class="emm10" aria-label="' . __('Show sub menu', 'mega-menu-pro-for-elementor') . '" aria-pressed="false" tabindex="-1"><i></i></button>';
        }

        $output .= '</a>';

        if ($content) {
            $output .= '<div class="emm5 emm26" data-emm-settings="' . esc_js(json_encode($this->get_frontend_config($settings))) . '">' . $content . '</div>';
        }
    }

    /**
     * @see \Walker::end_el()
     */
    public function end_el(&$output, $item, $depth = 0, $args = [])
    {
        $output .= '</li>';
    }

    /**
     * Get item settings
     *
     * @return array
     */
    private function get_item_settings($item_id)
    {
        $elementor_item_id = get_post_meta($item_id, 'emm_elementor_menu_item_id', true);

        return array_merge([
            'icon' => '',
            'is_mega' => false,
            'users' => ['anyone'],
            'show_badge' => false,
            'hide_title' => false,
            'badge_label' => __('New', 'mega-menu-pro-for-elementor'),
            'badge_bg_color' => '#61ce70',
            'hide_on_mobile' => false,
            'hide_on_tablet' => false,
            'hide_on_desktop' => false,
            'show_sub_mobile' => false,
            'mega_panel_fit' => '',
            'mega_fit_to_el' => '',
            'mega_panel_width' => 0,
            'enforce_mobile_layout' => '',
            'badge_label_color' => '#fff'
        ], (array)get_post_meta($elementor_item_id, '_elementor_page_settings', true));
    }

    /**
     * @param int $item_id
     *
     * @return string
     */
    private function get_item_content($item_id)
    {
        if (!$this->is_preview_mode()) {
            $id = get_post_meta($item_id, 'emm_elementor_menu_item_id', true);
            if ($id) {
                return Plugin::$instance->frontend->get_builder_content_for_display($id);
            } else {
                return __('Mega content not found.', 'mega-menu-pro-for-elementor');
            }
        }

        return '';
    }

    /**
     * @return string
     */
    private function get_item_badge(array $settings)
    {
        $style = 'line-height:1';
        $output = '<span class="emm9"';

        if (!empty($settings['badge_label_color'])) {
            $style .= ';color:' . $settings['badge_label_color'];
        } else {
            $style .= ';color:#fff';
        }

        if (!empty($settings['badge_bg_color'])) {
            $style .= ';background-color:' . $settings['badge_bg_color'];
        } else {
            $style .= ';background-color:#61ce70';
        }

        if (!empty($settings['badge_text_size']['size'])) {
            $style .= ';font-size:' . $settings['badge_text_size']['size'] . $settings['badge_text_size']['unit'];
        }

        if (!empty($settings['badge_padding']['top'])) {
            $style .= sprintf(';padding:%spx %spx %spx %spx', $settings['badge_padding']['top'], $settings['badge_padding']['right'], $settings['badge_padding']['bottom'], $settings['badge_padding']['left']);
            $style .= sprintf(';margin-top:-%spx;margin-bottom:-%spx', $settings['badge_padding']['top'], $settings['badge_padding']['bottom']);
        }

        if (!empty($settings['badge_border_radius']['top'])) {
            $style .= sprintf(';border-radius:%spx %spx %spx %spx', $settings['badge_border_radius']['top'], $settings['badge_border_radius']['right'], $settings['badge_border_radius']['bottom'], $settings['badge_border_radius']['left']);
        }

        if (!empty($settings['badge_offset_top']['size']) && !$this->is_mobile) {
            $style .= ';top:' . $settings['badge_offset_top']['size'] . 'px';
        }

        if (!empty($settings['badge_offset_h']['size']) && !$this->is_mobile) {
            if ($this->is_rtl) {
                $style .= ';margin-right:' . $settings['badge_offset_h']['size'] . 'px';
            } else {
                $style .= ';margin-left:' . $settings['badge_offset_h']['size'] . 'px';
            }
        }

        $output .= ' style="' . $style . '">' . $settings['badge_label'] . '</span>';

        return $output;
    }

    /**
     * @return array
     */
    private function get_frontend_config(array $settings)
    {
        if ($this->menu_settings['layout'] == 'vertical') {
            return [
                'width' => $settings['vertical_mega_panel_width'],
                'mWidth' => $settings['vertical_mega_panel_width_tablet']
            ];
        } else {
            return [
                'fit' => $settings['mega_panel_fit'],
                'fitEl' => $settings['mega_fit_to_el'],
                'width' => $settings['mega_panel_width'],
                'mWidth' => $settings['mega_panel_width_tablet']
            ];
        }
    }

    /**
     * @return bool
     */
    private function is_item_viewable($users)
    {
        if ($this->is_preview_mode()) {
            return true;
        }

        $valid_roles = [];
        $roles = wp_roles()->roles;

        foreach ($roles as $role => $data) {
            if (in_array($role, $users)) {
                $valid_roles[] = $role;
            }
        }

        $user = wp_get_current_user();

        if ($user->exists()) {
            $minimal_role = $user->roles[0];
        } else {
            $minimal_role = 'anyone';
        }

        if (in_array($minimal_role, $valid_roles) || in_array('anyone', $users)) {
            return true;
        }

        return false;
    }

    /**
     * Is editing a menu item?
     *
     * @return bool
     */
    private function is_preview_mode()
    {
        global $post;

        if (empty($post->post_type)) {
            return false;
        }

        return $this->is_preview && $post->post_type == 'elementor_menu_item';
    }
}
