<?php

use Elementor\Core\Schemes;
use Elementor\Scheme_Color;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Core\Schemes\Typography;

/**
 * Adds row meta links to the plugin list table
 *
 * @return array An array of plugin row meta links.
 */
function scemm_add_plugin_quicklinks($meta, $file)
{
	if ('mega-menu-pro-for-elementor/mega-menu-pro-for-elementor.php' === $file) {
		return array_merge($meta, [
			'docs' => '<a href="https://sarahcoding.com/docs/elementor-mega-menu" target="_blank">' . __('Documentation', 'mega-menu-pro-for-elementor') . '</a>',
			'video' => '<a href="https://www.youtube.com/channel/UC-K1xIweau7JUDLXH6Fsv2g/playlists" target="_blank">' . __('Video Tutorials', 'mega-menu-pro-for-elementor') . '</a>',
			'changelog' => '<a href="https://github.com/sarah-coding/mega-menu-pro-for-elementor/releases" target="_blank">' . __('Changelog', 'mega-menu-pro-for-elementor') . '</a>',
		]);
	}

	return $meta;
}
add_filter('plugin_row_meta', 'scemm_add_plugin_quicklinks', 10, 2);

/**
 * Register elemetor controls for menu item
 */
function scemm_register_elementor_menu_item_controls($doc)
{
    $post = $doc->get_post();

    if ('elementor_menu_item' !== $post->post_type) {
        return;
    }

    $users = ['anyone' => __('Anyone', 'mega-menu-pro-for-elementor')];
    $roles = wp_roles()->roles;

    foreach ($roles as $role => $cap) {
        $users[$role] = $cap['name'];
    }

    $doc->remove_control('post_title');

    remove_all_actions('elementor/documents/register_controls');

	$doc->start_injection([
		'of' => 'post_status'
	]);

	$doc->add_control('hide_on_mobile', [
		'label' => __('Hide On Mobile', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->add_control('hide_on_tablet', [
		'label' => __('Hide On Tablet', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->add_control('hide_on_desktop', [
		'label' => __('Hide On Desktop', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->add_control('show_sub_mobile', [
		'label' => __('Expand Submenu On Mobile', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->end_injection();

	$doc->start_controls_section('section_item_icon', [
		'label' => __('Icon', 'mega-menu-pro-for-elementor'),
		'tab' => Controls_Manager::TAB_SETTINGS
	]);

	$doc->add_control('icon', [
		'label' => '',
		'label_hidden' => true,
		'type' => Controls_Manager::ICONS,
	]);

	$doc->end_controls_section();

	$doc->start_controls_section('section_mega_menu', [
		'label' => __('Mega', 'mega-menu-pro-for-elementor'),
		'tab' => Controls_Manager::TAB_SETTINGS
	]);

	$doc->add_control('mega_disabled', [
		'raw' => __('Not applicable for the current menu item.', 'mega-menu-pro-for-elementor') . ' <a href="https://github.com/sarah-coding/mega-menu-pro-for-elementor/wiki/Mega-is-not-applicable-for-the-current-menu-item.-Why%3F" target="_blank">' . __('Why?', 'mega-menu-pro-for-elementor') . '</a>',
		'type' => Controls_Manager::RAW_HTML,
		'content_classes' => 'item-is-flyout',
	]);

	$doc->add_control('is_mega', [
		'label' => __('Enable Mega', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->add_control('enforce_mobile_layout', [
		'label' => __('Enforce Mobile Layout', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER,
        'condition' => [
            'is_mega' => 'yes'
        ],
        'description' => __('When displaying mobile menu on desktop or tablet, you may want mega contents to be laid out vertically like displaying on mobile instead.', 'mega-menu-pro-for-elementor')
	]);

	$doc->add_control('mega_panel_fit', [
		'label' => __('Mega Panel Fits To', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SELECT,
		'label_block' => true,
		'default' => 'container',
		'options' => [
            'viewport'  => __('Full screen width', 'mega-menu-pro-for-elementor'),
            'menu' => __('Menu root UL element', 'mega-menu-pro-for-elementor'),
			'auto' => __('Auto, as wide as content', 'mega-menu-pro-for-elementor'),
            'row' => __('Elementor containing row', 'mega-menu-pro-for-elementor'),
            'container' => __('Elementor widget container', 'mega-menu-pro-for-elementor'),
            'column' => __('Elementor containing column', 'mega-menu-pro-for-elementor'),
            'section' => __('Elementor containing section', 'mega-menu-pro-for-elementor'),
			'custom' => __('Custom', 'mega-menu-pro-for-elementor')
		],
		'condition' => [
			'is_mega!' => ''
		]
	]);

	$doc->add_control('mega_fit_to_el', [
		'label' => __('Fit-To Element', 'mega-menu-pro-for-elementor'),
		'description' => __('Enter a unique CSS selector of the element you want to sync the width and alignment with the mega panel. Or set a fixed width value below:', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::TEXT,
		'placeholder' => 'E.g. #element-123',
		'condition' => [
			'is_mega!' => '',
			'mega_panel_fit' => 'custom'
		]
	]);

	$doc->add_responsive_control('mega_panel_width', [
		'label' => __('Mega Panel Width', 'mega-menu-pro-for-elementor') . ' (px)',
		'type' => Controls_Manager::SLIDER,
		'size_units' => ['px'],
		'devices' => ['desktop', 'tablet'],
		'range' => [
			'px' => [
				'min' => 300,
				'max' => 1200
			]
		],
		'default' => [
			'size' => '',
			'unit' => 'px'
		],
		'save_default' => true,
		'condition' => [
			'is_mega!' => '',
			'mega_panel_fit' => 'custom',
			'mega_fit_to_el' => ''
		]
	]);

	$doc->add_responsive_control('vertical_mega_panel_width', [
		'label' => __('Mega Panel Width', 'mega-menu-pro-for-elementor') . ' (px)',
		'type' => Controls_Manager::SLIDER,
		'devices' => ['desktop', 'tablet'],
		'size_units' => ['px'],
		'range' => [
			'px' => [
				'min' => 300,
				'max' => 1200
			]
		],
		'default' => [
			'size' => '',
			'unit' => 'px'
		],
		'save_default' => true,
		'condition' => [
			'is_mega!' => ''
		]
	]);

	$doc->end_controls_section();

	$doc->start_controls_section('section_item_badge', [
		'label' => __('Badge', 'mega-menu-pro-for-elementor'),
		'tab' => Controls_Manager::TAB_SETTINGS
	]);

	$doc->add_control('show_badge', [
		'label' => __('Show Badge', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SWITCHER
	]);

	$doc->add_control('badge_label', [
		'label' => __('Label', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::TEXT,
		'default' => __('New', 'mega-menu-pro-for-elementor'),
		'condition' => [
			'show_badge' => 'yes'
		]
	]);

	$doc->add_control('badge_label_color', [
		'label' => __('Text Color', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::COLOR,
		'default' => '#ffffff',
		'selectors' => [
			'#menu-scope .emm70 > .emm6 > .emm9' => 'color:{{VALUE}} !important',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->add_control('badge_bg_color', [
		'label' => __('Background Color', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::COLOR,
		'default' => '#61ce70',
		'selectors' => [
			'#menu-scope .emm70 > .emm6 > .emm9' => 'background-color:{{VALUE}} !important',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->add_control('badge_text_size', [
		'label' => __('Font Size', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SLIDER,
		'size_units' => ['px', 'em', 'rem'],
		'range' => [
			'px' => [
				'min' => 4,
				'max' => 100
			],
			'em' => [
				'min' => 0.1,
				'max' => 10
			],
			'rem' => [
				'min' => 0.1,
				'max' => 10
			],
		],
		'selectors' => [
			'#menu-scope .emm70 > .emm6 > .emm9' => 'font-size:{{SIZE}}{{UNIT}} !important',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->add_control('badge_offset_top', [
		'label' => __('Offset Top', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::SLIDER,
		'range' => [
			'px' => [
				'min' => -100,
				'max' => 100,
				'step' => 1,
			]
		],
		'selectors' => [
			'#menu-scope .emm0 .emm70 > .emm6 > .emm9' => 'top:{{SIZE}}px !important',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

    if (is_rtl()) {
        $dir = __('Right', 'mega-menu-pro-for-elementor');
        $selectors['#menu-scope .emm0 .emm70 > .emm6 > .emm9'] = 'margin-right:{{SIZE}}px !important';
    } else {
        $dir = __('Left', 'mega-menu-pro-for-elementor');
        $selectors['#menu-scope .emm0 .emm70 > .emm6 > .emm9'] = 'margin-left:{{SIZE}}px !important';
    }

	$doc->add_control('badge_offset_h', [
		'label' => __('Offset', 'mega-menu-pro-for-elementor') . ' ' . $dir,
		'type' => Controls_Manager::SLIDER,
		'range' => [
			'px' => [
				'min' => -200,
				'max' => 200,
				'step' => 1,
			]
		],
		'selectors' => $selectors,
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->add_control('badge_padding', [
		'label' => __('Padding', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::DIMENSIONS,
		'selectors' => [
			'#menu-scope .emm70 > .emm6 > .emm9' => 'padding:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px !important;',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->add_control('badge_border_radius', [
		'label' => __('Border Radius', 'mega-menu-pro-for-elementor'),
		'type' => Controls_Manager::DIMENSIONS,
		'selectors' => [
			'#menu-scope .emm70 > .emm6 > .emm9' => 'border-radius:{{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px !important;',
		],
		'condition' => [
			'show_badge' => 'yes',
			'badge_label!' => ''
		]
	]);

	$doc->end_controls_section();

	$doc->start_controls_section('section_user_restriction', [
		'label' => __('Restriction', 'mega-menu-pro-for-elementor'),
		'tab' => Controls_Manager::TAB_SETTINGS
	]);

	$doc->add_control('users', [
		'label' => __('Who can see this menu item?', 'mega-menu-pro-for-elementor'),
		'label_block' => true,
		'type' => Controls_Manager::SELECT2,
		'multiple' => true,
		'options' => $users,
		'default' => 'anyone'
	]);

	$doc->end_controls_section();
}
add_action('elementor/element/wp-post/document_settings/after_section_end', 'scemm_register_elementor_menu_item_controls');

/**
 * Ajax render item icon
 */
function scemm_ajax_render_menu_item_icon()
{
    if (!current_user_can('edit_posts')) {
        wp_die(-1);
    }

    wp_send_json(scemm_render_icon($_POST['emm_icon']));
}
add_action('wp_ajax_emm_render_menu_item_icon', 'scemm_ajax_render_menu_item_icon');

/**
 * Enqueue editor scripts
 */
function scemm_enqueue_elementor_editor_styles()
{
    wp_add_inline_style('elementor-editor', '#emm-settings-icon-intro{position:absolute;z-index:1;background-color:#fff;color:#556068;box-shadow:-4px -3px 20px 1px rgba(0,0,0,.07);height:60px;width:150px;padding:10px 20px;border-radius:3px}#emm-settings-icon-intro::before{content:"";position:absolute;border:solid transparent;border-right:solid #fff;border-width:5px 7px;left:-14px;top:70%}');
}
add_action('elementor/editor/after_enqueue_styles', 'scemm_enqueue_elementor_editor_styles', 10, 0);

/**
 * Enqueue editor scripts
 */
function scemm_enqueue_elementor_editor_scripts()
{
	global $post;

    if ('elementor_menu_item' !== $post->post_type)
        return;

    wp_enqueue_script('menu-item-editor', SCEMM_URI . 'assets/js/menu-item-editor.min.js', ['elementor-editor'], SCEMM_VER, true);

    wp_localize_script('menu-item-editor', 'scEmmI18n', [
        't0' => __('New', 'mega-menu-pro-for-elementor'),
        't1' => __('Edit Menu Item', 'mega-menu-pro-for-elementor'),
        't2' => __('More than one Fit-to element found.', 'mega-menu-pro-for-elementor'),
        't3' => __('Menu item not found. Please save the Mega Menu widget containing this menu and try again!', 'mega-menu-pro-for-elementor'),
        't4' => __('Data conflicts. The menu item found in more than one Mega Menu widget.', 'mega-menu-pro-for-elementor'),
        't5' => __('Data was not saved properly. Click on the UPDATE button below and try again!', 'mega-menu-pro-for-elementor'),
        't6' => __('Click here to open menu item settings.', 'mega-menu-pro-for-elementor'),
        't7' => __('Fit-to element not found.', 'mega-menu-pro-for-elementor'),
    ]);
}
add_action('elementor/editor/after_enqueue_scripts', 'scemm_enqueue_elementor_editor_scripts', 10, 0);

/**
 * Enqueue nav-menus.php scripts
 */
function scemm_enqueue_nav_menus_scripts($page)
{
	if ('nav-menus.php' == $page) {
        wp_enqueue_script('emm-nav-menu', SCEMM_URI . 'assets/js/nav-menu.min.js', ['nav-menu'], SCEMM_VER, true);
	}

    if ('toplevel_page_elementor' == $page) {
        wp_add_inline_script('jquery-core', 'jQuery(() => {jQuery("input[value=elementor_menu_item]").parent("label").hide()})');
    }
}
add_action('admin_enqueue_scripts', 'scemm_enqueue_nav_menus_scripts', 999);

/**
 * Save elementor data
 */
function scemm_save_menu_item_indentity()
{
    if (!current_user_can('edit_posts')) return;

    if (empty($_GET['emm-edit-menu-item']) || empty($_GET['emm_menu_item_id']) || empty($_GET['emm_menu_id'])) {
        return;
    }

    $menu_id = intval($_GET['emm_menu_id']);
    $menu_item_id = intval($_GET['emm_menu_item_id']);
    $elementor_item_id = get_post_meta($menu_item_id, 'emm_elementor_menu_item_id', true);

    if (!get_post($elementor_item_id)) {
        $elementor_item_id = wp_insert_post([
            'post_title' => 'Elementor Menu Item #' . $menu_item_id,
            'post_name' => 'elementor-menu-item-' . $menu_item_id,
            'post_status' => 'publish',
            'post_type' => 'elementor_menu_item',
        ]);
        if (!is_int($elementor_item_id)) {
            throw new Exception(__('Unable to edit the menu item with Elementor.', 'mega-menu-pro-for-elementor'));
        } else {
            update_post_meta($elementor_item_id, 'emm_menu_id', $menu_id);
            update_post_meta($elementor_item_id, 'emm_menu_item_id', $menu_item_id);
            update_post_meta($menu_item_id, 'emm_elementor_menu_item_id', $elementor_item_id);
        }
    }

    wp_redirect(add_query_arg([
		'post' => $elementor_item_id,
		'action' => 'elementor',
		'emm_menu_id' => $menu_id,
		'emm_menu_item_id' => $menu_item_id
	], admin_url('post.php')));

    exit;
}
add_action('init', 'scemm_save_menu_item_indentity', 11, 0);

/**
 * Delete Elementor data when deleting menu item
 */
function scemm_on_deleting_menu_item()
{
	if (!current_user_can('edit_theme_options')) {
		wp_die(-1);
	}

    $menu_item_id = intval($_POST['menu-item-id']);

    if ($elementor_item_id = get_post_meta($menu_item_id, 'emm_elementor_menu_item_id', true)) {
        $deleted = wp_delete_post($elementor_item_id, true);
        if (!$deleted) {
            wp_send_json(['success' => false]);
        } else {
            wp_send_json(['success' => true]);
        }
    }
}
add_action('wp_ajax_delete-menu-item', 'scemm_on_deleting_menu_item', 10, 0);

/**
 * Make a shallow copy of nav menu data
 * from editor data for research purpose. xD
 */
function scemm_copy_nav_menu_data($post_id, $data)
{
    $postx = get_post($post_id);

    if ('elementor_menu_item' == $postx->post_type) {
        return;
	}

    $stylesheet = get_option('stylesheet');

    foreach ($data as $el) {
        if ($el['elType'] == 'section') {
            $menu = scemm_has_nav_menu($el['elements']);
            if ($menu) {
                $el['_post_id'] = $post_id;
				update_option($stylesheet . '_sc_mod_emm_' . $menu, $el);
            }
        }
    }
}
add_action('elementor/editor/after_save', 'scemm_copy_nav_menu_data', 10, 2);
