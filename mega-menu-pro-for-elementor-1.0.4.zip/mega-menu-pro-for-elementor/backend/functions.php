<?php

/**
 * @return bool|string
 */
function scemm_has_nav_menu($elements)
{
    $menu = false;

    foreach ($elements as $el) {
        if (!empty($el['elements']) && !$menu) {
            $menu = scemm_has_nav_menu($el['elements']);
            continue;
        }
        if ($el['elType'] == 'widget' && $el['widgetType'] == 'mega-menu') {
            $menu = $el['settings']['menu'];
            break;
        }
    }

    return $menu;
}
