<?php

use Elementor\Core\Files\CSS\Post as PostCSS;

$classes = 'elementor';
$menu_id = get_post_meta($post->ID, 'emm_menu_id', true);
$item_id = get_post_meta($post->ID, 'emm_menu_item_id', true);
$menu_obj = get_term($menu_id, 'nav_menu');
$elementor = Elementor\Plugin::$instance;
$stylesheet = get_option('stylesheet');
$menu_section = get_option($stylesheet . '_sc_mod_emm_' . $menu_obj->slug, []);

if ($menu_section) {
    $classes .= ' elementor-' . $menu_section['_post_id'];
    add_action('wp_enqueue_scripts', function() use ($menu_section) {
        PostCSS::create($menu_section['_post_id'])->enqueue();
    }, 11, 0);
    unset($menu_section['_post_id']);
    $menu_section = $elementor->elements_manager->create_element_instance($menu_section);
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="menu-scope" class="<?php echo esc_attr($classes) ?>">
    <div class="elementor-inner">
    	<div class="elementor-section-wrap">
            <?php if ($menu_section) : ?>
                <?php $menu_section->print_element(); ?>
            <?php else : ?>
            <div id="no-assigned-menu">
                <p><?php _e('The containing menu is not assigned in any Mega Menu widget.', 'mega-menu-pro-for-elementor') ?>.</p>
            </div>
            <?php endif ?>
    	</div>
    </div>
</div>
<div id="editor-scope">
<?php
    while (have_posts()) {
        the_post();
        the_content();
    }
?>
</div>
<?php wp_footer(); ?>
</body>
</html>
