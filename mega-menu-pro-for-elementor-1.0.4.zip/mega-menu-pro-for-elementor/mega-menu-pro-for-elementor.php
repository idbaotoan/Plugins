<?php
/**
 * Plugin Name: Mega Menu Pro for Elementor
 * Plugin URI: https://demo.sarahcoding.com/elementor-mega-menu/
 * Description: The most intuitive mega menu builder for Elementor. Feature-rich, lightweight and RTL ready
 * Author: SarahCoding
 * Author URI: https://sarahcoding.com
 * Version: 1.0.4
 * Text Domain: mega-menu-pro-for-elementor
 * Tested up to: 5.5
 * License: GNU General Public License v3 or later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 */

define('SCEMM_VER', '1.0.4');
define('SCEMM_DIR', __DIR__ . '/');
define('SCEMM_URI', plugins_url('/', __FILE__));

/**
 * Do activation
 *
 * @see https://developer.wordpress.org/reference/functions/register_activation_hook/
 */
function scemm_activate($network)
{
    try {
        if (version_compare(PHP_VERSION, '7.2', '<')) {
            throw new Exception(__('This plugin requires PHP version 7.2 at least!', 'mega-menu-pro-for-elementor'));
        }
        if (version_compare($GLOBALS['wp_version'], '5.4', '<')) {
            throw new Exception(__('This plugin requires WordPress version 5.4 at least!', 'mega-menu-pro-for-elementor'));
        }
    } catch (Exception $e) {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            header('Content-Type: application/json; charset=' . get_option('blog_charset'));
            status_header(500);
            exit(json_encode([
                'success' => false,
                'name'    => __('Plugin Activation Error', 'mega-menu-pro-for-elementor'),
                'message' => $e->getMessage()
            ]));
        } else {
            exit($e->getMessage());
        }
    }
}
register_activation_hook(__FILE__, 'scemm_activate');

/**
 * Do installation
 *
 * @see https://developer.wordpress.org/reference/hooks/plugins_loaded/
 */
function scemm_install()
{
    load_plugin_textdomain('mega-menu-pro-for-elementor', false, 'mega-menu-pro-for-elementor/languages');

    require SCEMM_DIR . 'common/class-mega-menu-walker.php';
    require SCEMM_DIR . 'common/functions.php';
    require SCEMM_DIR . 'common/hooks.php';

    if (is_admin()) {
        require SCEMM_DIR . 'backend/functions.php';
        require SCEMM_DIR . 'backend/hooks.php';
    } else {
        require SCEMM_DIR . 'frontend/hooks.php';
    }
}
add_action('plugins_loaded', 'scemm_install', 10, 0);

/**
 * Do deactivation
 *
 * @see https://developer.wordpress.org/reference/functions/register_deactivation_hook/
 */
function scemm_deactivate()
{
    delete_option('sc_emm_flushed_rewrite_rules');
}
register_deactivation_hook(__FILE__, 'scemm_deactivate');
