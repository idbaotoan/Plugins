<?php

use Elementor\Plugin;
use Elementor\Core\Responsive\Responsive;

/**
 * Register Elementor scripts
 */
function scemm_register_elementor_frontend_scripts()
{
    $breakpoints = Responsive::get_breakpoints();

    wp_register_script('emm-frontend', SCEMM_URI . 'assets/js/frontend.min.js', ['elementor-frontend'], SCEMM_VER, true);

    wp_localize_script('emm-frontend', 'scEmmI18n', [
        't0' => __('Fit-to element not found.', 'mega-menu-pro-for-elementor'),
        't1' => __('More than one Fit-to element found.', 'mega-menu-pro-for-elementor'),
        't2' => __('If mobile paged layout doesn\'t work, please SAVE & RELOAD the page. It is a known bug that can\'t be solved by code.', 'mega-menu-pro-for-elementor'),
        't3' => __('Custom mobile toggle element not found.', 'mega-menu-pro-for-elementor'),
    ]);

    wp_localize_script('emm-frontend', 'scEmmConfig', [
        'breakpoints' => [
            'tablet' => $breakpoints['lg'],
            'mobile' => $breakpoints['md']
        ],
        'editUrl' => admin_url('?emm-edit-menu-item=true')
    ]);
}
add_action('elementor/frontend/before_register_scripts', 'scemm_register_elementor_frontend_scripts');

/**
 * Enqueue frontend scripts
 */
function scemm_enqueue_frontend_scripts()
{
    global $post;

    $breakpoints = Responsive::get_breakpoints();
    $max_tablet = $breakpoints['lg'] - 1;
    $max_mobile = $breakpoints['md'] - 1;
    $is_preview = Plugin::$instance->preview->is_preview_mode();
    $is_editing = isset($post->post_type) && $post->post_type == 'elementor_menu_item';

    wp_enqueue_style('emm-frontend', SCEMM_URI . 'assets/css/frontend.min.css', ['elementor-icons', 'elementor-frontend'], SCEMM_VER);

    wp_add_inline_style('emm-frontend', '@media (min-width:' . $breakpoints['lg'] . 'px){.emm11tablet .elementor-widget-container .emm15,.emm11tablet .elementor-widget-container .emm13{display:none}.emm11tablet:not(.emm2hidden) .elementor-widget-container .emm0,.emm12hidden:not(.emm2hidden) .elementor-widget-container .emm0{display:flex}}@media (min-width:' . $breakpoints['md'] . 'px){.emm11mobile .elementor-widget-container .emm15,.emm11mobile .elementor-widget-container .emm13{display:none}.emm11mobile:not(.emm2hidden) .elementor-widget-container .emm0,.emm12hidden:not(.emm2hidden) .elementor-widget-container .emm0{display:flex}}');

    if ($is_preview) {
        wp_add_inline_style('emm-frontend', '@media (min-width:' . $breakpoints['lg'] . 'px){.elementor-editor-preview[data-elementor-device-mode="desktop"] .emm .elementor-hidden-desktop{display:none !important}}@media (min-width:' . $breakpoints['md'] . 'px) and (max-width:' . $max_tablet . 'px){.elementor-editor-preview[data-elementor-device-mode="tablet"] .emm .elementor-hidden-tablet{display:none !important}}@media (max-width:' . $max_mobile . 'px){.elementor-editor-preview[data-elementor-device-mode="mobile"] .emm .elementor-hidden-phone{display:none !important}}');
    }

    if (!$is_preview || $is_editing) {
        wp_add_inline_style('emm-frontend', '@media (min-width:' . $breakpoints['lg'] . 'px){.emm .elementor-hidden-desktop{display:none !important}}@media (min-width:' . $breakpoints['md'] . 'px) and (max-width:' . $max_tablet . 'px){.emm .elementor-hidden-tablet{display:none !important}}@media (max-width:' . $max_mobile . 'px){.emm .elementor-hidden-phone{display:none !important}}');
    }

    if ($is_editing) {
        wp_deregister_style('wp-block-library');

        wp_enqueue_style('emm-edit-item', SCEMM_URI . 'assets/css/edit-item.min.css', [], SCEMM_VER);
    }
}
add_action('wp_enqueue_scripts', 'scemm_enqueue_frontend_scripts', 10, 0);

/**
 * Include elementor-menu-item template
 */
function scemm_include_edit_template($tmpl)
{
    if (is_singular('elementor_menu_item')) {
        $tmpl = SCEMM_DIR . 'templates/elementor-menu-item.php';
    }

    return $tmpl;
}
add_action('template_include', 'scemm_include_edit_template', PHP_INT_MAX);
