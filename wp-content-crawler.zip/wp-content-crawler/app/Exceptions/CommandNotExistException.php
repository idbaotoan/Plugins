<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 25/03/2020
 * Time: 12:07
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Exceptions;


use Exception;

class CommandNotExistException extends Exception {

}