<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 24/12/2018
 * Time: 20:39
 *
 * @since 1.8.0
 */

namespace WPCCrawler\PostDetail\WooCommerce\Adapter\Woo34;


use WPCCrawler\PostDetail\WooCommerce\Adapter\Interfaces\SimpleProductAdapter;

class Woo34SimpleProductAdapter extends Woo34ProductAdapter implements SimpleProductAdapter {

}