<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 02/05/2020
 * Time: 13:09
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Objects\Views\Enums;


abstract class ViewKey {

    const TEST_RESULT_CONTAINER = 'partials.test-result-container';

}