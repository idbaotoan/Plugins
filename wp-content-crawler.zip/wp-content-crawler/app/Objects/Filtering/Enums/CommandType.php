<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 29/03/2020
 * Time: 09:40
 *
 * @since 1.11.0
 */

namespace WPCCrawler\Objects\Filtering\Enums;


abstract class CommandType {

    const ACTION    = 'action';
    const CONDITION = 'condition';

}