<?php

namespace NF_FU_VENDOR\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
