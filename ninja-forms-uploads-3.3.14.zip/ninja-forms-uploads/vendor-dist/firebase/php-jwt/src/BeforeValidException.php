<?php

namespace NF_FU_VENDOR\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
