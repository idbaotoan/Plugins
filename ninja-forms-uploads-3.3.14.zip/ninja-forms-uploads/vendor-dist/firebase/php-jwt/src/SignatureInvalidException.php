<?php

namespace NF_FU_VENDOR\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{
}
