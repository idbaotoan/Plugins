<?php

namespace NF_FU_VENDOR\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
