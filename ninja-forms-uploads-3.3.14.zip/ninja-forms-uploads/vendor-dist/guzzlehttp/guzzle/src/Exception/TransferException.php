<?php

namespace NF_FU_VENDOR\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements GuzzleException
{
}
