<?php
// Silence is golden.