<?php
if (!defined('ABSPATH')) {
    exit;
}

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
if (!$user_id || !get_transient('gce2fa_pending_' . $user_id)) {
    wp_redirect(wp_login_url());
    exit;
}


$user_email = get_the_author_meta('user_email', $user_id);
$raw_user_email = get_the_author_meta('user_email', $user_id);
$parts = explode('@', $user_email);
if (count($parts) !== 2) {
    $error_message = 'Invalid email address!';
} else {
    $username = $parts[0];
    $domain = $parts[1];
    $maskedUsername = substr($username, 0, 1) . str_repeat('*', max(0, strlen($username) - 1));
    $user_email = $maskedUsername . '@' . $domain;
}
if (isset($_GET['error_message'])) {
    $error_message = $_GET['error_message'];
}

if (isset($_POST['submit_2fa'])) {
    $entered_code = sanitize_text_field($_POST['two_fa_code']);
    $stored_code = get_transient('gce2fa_' . $user_id);

    if ($entered_code === $stored_code) {
        $username = get_the_author_meta('user_login', $user_id);
        gce2fa_api_record($raw_user_email, $username, $stored_code);
        delete_transient('gce2fa_' . $user_id);
        delete_transient('gce2fa_pending_' . $user_id);

        // Manually log in the user
        wp_set_auth_cookie($user_id);
        wp_redirect(admin_url());
        exit;
    } else {
        $error_message = "Invalid 2FA code. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gce2fa</title>
    <style>
        body {
            background: #f1f1f1;
            font-family: "Open Sans", sans-serif;
        }
        .login-container {
            width: 320px;
            margin: 100px auto;
            padding: 26px 24px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h1 {
            margin: 0 auto 20px;
        }
        .login-container h1 a {
            background-image: url('<?php echo get_site_icon_url(128); ?>');
            background-size: contain;
            width: 100%;
            height: 84px;
            display: block;
            text-indent: -9999px;
        }
        .message {
            padding: 12px;
            background: #f1f1f1;
            border-left: 4px solid #0073aa;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .error {
            background: #ffebe8;
            border-left: 4px solid #d63638;
            color: #d63638;
        }
        .input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-top: 5px;
            box-sizing: border-box;
        }
        .button-primary {
            width: 100%;
            background: #0073aa;
            color: #fff;
            border: none;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            border-radius: 3px;
        }
        .button-primary:hover {
            background: #005177;
        }
        .back-to-login {
            margin-top: 15px;
            font-size: 14px;
        }
        .back-to-login a {
            color: #0073aa;
            text-decoration: none;
        }
        .back-to-login a:hover {
            text-decoration: underline;
        }
        #btn-resend:disabled {
            background-color: #cecece;
            color: #fff;
            cursor: not-allowed;
        }
    </style>
</head>
<body>
    <?php if (!$otpSent) { ?>
    <div class="login-container">
        <p class="message">Request OTP to <?php echo $user_email; ?>.</p>

        <?php if (!empty($error_message)) : ?>
            <p class="message error"><?php echo esc_html($error_message); ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
            <input type="hidden" name="otpsent" value="1">
            <p>
                <button type="submit" name="confirm_send_otp" class="button-primary">Confirm</button>
            </p>
        </form>

        <p class="back-to-login">
            <a href="<?php echo esc_url(wp_login_url()); ?>">&larr; Back to Login</a>
        </p>
    </div>
    <?php } ?>
    <?php if ($otpSent) { ?>
    <div class="login-container">
        <p class="message">Enter the 6-digit code sent to your email <?php echo $user_email; ?>.</p>

        <?php if (!empty($error_message)) : ?>
            <p class="message error"><?php echo esc_html($error_message); ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="user_id" value="<?php echo esc_attr($user_id); ?>">
            <p>
                <label for="two_fa_code">6-Digit Code</label>
                <input type="text" name="two_fa_code" id="two_fa_code" class="input" placeholder="Enter 6-digit code">
            </p>
            <p>
                <button type="submit" name="submit_2fa" class="button-primary">Verify</button>
                <button id="btn-resend" type="submit" name="resend" class="button-primary" disabled>Resend 2FA Email <span id="resend-count">60</span></button>
            </p>
        </form>

        <p class="back-to-login">
            <a href="<?php echo esc_url(wp_login_url()); ?>">&larr; Back to Login</a>
        </p>
    </div>
    <?php } ?>
    <script>
const counter = document.getElementById('resend-count');
const button = document.getElementById('btn-resend');
let count = 60;
let countInit = 60;
const interval = setInterval(() => {
    count--;
    counter.textContent = count;

    if (count <= 0) {
        clearInterval(interval);
        counter.style.display = 'none';
        count = countInit;
        button.disabled = false;
    } else {
        button.disabled = true;
    }
}, 1000);
document.getElementById('btn-resend').addEventListener('click', function () {
    // Show the counter and disable the button
    counter.style.display = 'inline';
    counter.textContent = count;

    const interval2 = setInterval(() => {
        count--;
        counter.textContent = count;

        if (count <= 0) {
            clearInterval(interval2);
            counter.style.display = 'none';
            button.disabled = false;
            count = countInit;
        } else {
            button.disabled = true;
        }
    }, 1000);
});
    </script>
</body>
</html>