<?php
/**
 * Plugin Name: GoCloudEasy 2FA
 * Plugin URI: https://gocloudeasy.com/
 * Description: A 2FA plugin to secure your wordpress admin login
 * Version: 1.0
 * Author: GoCloudEasy Pte Ltd
 * Author URI: https://gocloudeasy.com/
 * License: GPL2
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

function gce2fa_check_version() {
    if (version_compare(get_bloginfo('version'), '5.0', '<')) {
        deactivate_plugins('gce2fa/gce2fa.php');
        wp_die(
            'This plugin requires WordPress version 5.0 or higher. Please update your WordPress installation.',
            'Plugin Activation Error',
            array('back_link' => true)
        );
    }
}

register_activation_hook(__FILE__, 'gce2fa_check_version');

function gce2fa_before_login($user, $username, $password) {
    $client_ip = gce2fa_get_client_ip();

    if (is_wp_error($user)) {
        return $user;
    }

    if (!in_array('administrator', (array) $user->roles)) {
        return $user;
    }
    
    $cp_username = gce2fa_get_cp_username();

    $token_path = "/home/$cp_username/.wp";

    if (file_exists($token_path) && is_file($token_path)) {
        $token = file_get_contents($token_path);
    } else {
        return $user;
    }
    
    $response = gce2fa_api_verify_ip($client_ip, $user->user_email, $user->user_login, $cp_username, $token);

    if ($response && $response['status'] === 'allowed') {
        return $user;
    }
    
    if ($response && $response['status'] === 'timeout') {
        return $user;
    }
    
    $stored_code = get_transient('gce2fa_' . $user->ID);

    if ($stored_code === false) {
        $two_fa_code = gce2fa_generate_2fa();
    } else {
        $two_fa_code = $stored_code;
    }

    set_transient('gce2fa_' . $user->ID, $two_fa_code, 60 * 60);
    set_transient('gce2fa_pending_' . $user->ID, $user->ID, 60 * 60);
    $redirect_url = home_url('index.php?gce2fa=1&user_id=' . $user->ID);
    wp_redirect($redirect_url);
}

add_filter('authenticate', 'gce2fa_before_login', PHP_INT_MAX, 3);

// Add custom query var
function add_gce2fa_query_var($vars) {
    $vars[] = 'gce2fa';
    return $vars;
}

add_filter('query_vars', 'add_gce2fa_query_var', 1);

function load_gce2fa_template() {
    if (get_query_var('gce2fa') == 1) {
        if (isset($_POST['resend'])) {
            $client_ip = gce2fa_get_client_ip();
        
            $cp_username = gce2fa_get_cp_username();
        
            $token_path = "/home/$cp_username/.wp";
            
            $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
        
            if (file_exists($token_path) && is_file($token_path)) {
                $token = file_get_contents($token_path);
            } else {
                wp_redirect(home_url('index.php?gce2fa=1&user_id=' . $user_id . '&error_message=Invalid request.'));
                exit;
            }
            
            $user_email = get_the_author_meta('user_email', $user_id);
            $username = get_the_author_meta('user_login', $user_id);
            
            $two_fa_code = get_transient('gce2fa_' . $user_id);
    
            $email_api_status = gce2fa_api_send_2fa_email($client_ip, $user_email, $username, $two_fa_code, $cp_username, $token);
        

            if ($email_api_status['status'] == 'error') {
                wp_redirect(home_url('index.php?gce2fa=1&user_id=' . $user_id . '&error_message=' . $email_api_status['msg']));
                exit;
            }
        }
        
        if (isset($_POST['otpsent'])) {
            $otpSent = 1;
            $client_ip = gce2fa_get_client_ip();
        
            $cp_username = gce2fa_get_cp_username();
        
            $token_path = "/home/$cp_username/.wp";
            
            $user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;
        
            if (file_exists($token_path) && is_file($token_path)) {
                $token = file_get_contents($token_path);
            } else {
                wp_redirect(home_url('index.php?gce2fa=1&user_id=' . $user_id . '&error_message=Invalid request.'));
                exit;
            }
            
            $user_email = get_the_author_meta('user_email', $user_id);
            $username = get_the_author_meta('user_login', $user_id);
            
            $two_fa_code = get_transient('gce2fa_' . $user_id);
    
            $email_api_status = gce2fa_api_send_2fa_email($client_ip, $user_email, $username, $two_fa_code, $cp_username, $token);

            if ($email_api_status['status'] == 'error') {
                wp_redirect(home_url('index.php?gce2fa=1&user_id=' . $user_id . '&error_message=' . $email_api_status['msg']));
                exit;
            }
        } else {
            $otpSent = 0;
        }

        include_once 'gce2fa-template.php';
        exit;
    }
}

add_action('template_redirect', 'load_gce2fa_template', 1);

function gce2fa_generate_2fa() {
     return str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

function gce2fa_get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]; // First IP in case of multiple
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

function gce2fa_api_verify_ip($ip, $email, $username, $cp_username, $token) {
    $url = 'https://otp.gocloudeasy.com/check.php';

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'cip' => $ip,
        'email' => $email,
        'cpanel_user' => $cp_username,
        'token' => $token,
        'domain' => site_url(),
        'username' => $username,
    ]));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    $response = curl_exec($ch);
    $response_json = json_decode($response, true);
    $error_code = curl_errno($ch);
    curl_close($ch);

    if (in_array($error_code, [CURLE_OPERATION_TIMEOUTED, CURLE_COULDNT_CONNECT])) {
        return ['status' => 'timeout'];
    } elseif ($error_code) {
        return ['status' => 'nallowed'];
    } else {
        return $response_json;
    }
}

function gce2fa_api_send_2fa_email($ip, $email, $username, $otp, $cp_username, $token) {
    $url = 'https://otp.gocloudeasy.com/email.php';

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'cip' => $ip,
        'email' => $email,
        'otp' => $otp,
        'cpanel_user' => $cp_username,
        'token' => $token,
        'domain' => site_url(),
        'username' => $username,
    ]));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $response_json = json_decode($response, true);
    $error_code = curl_errno($ch);
    curl_close($ch);

    if (in_array($error_code, [CURLE_OPERATION_TIMEOUTED, CURLE_COULDNT_CONNECT])) {
        return ['status' => 'error', 'msg' => 'Request timeout, please contact plugin administrator.'];
        //return ['status' => 'timeout'];
    } else {
        if ($response_json['status'] != 'error') {
            return ['status' => 'success'];
        } else {
            return ['status' => 'error', 'msg' => $response_json['msg']];
        }
    }
}

function gce2fa_api_record($email, $username, $otp) {
    $client_ip = gce2fa_get_client_ip();
    
    $cp_username = gce2fa_get_cp_username();

    $token_path = "/home/$cp_username/.wp";

    if (file_exists($token_path) && is_file($token_path)) {
        $token = file_get_contents($token_path);
    } else {
        return false;
    }
    
    $url = 'https://otp.gocloudeasy.com/record.php';

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'cip' => $client_ip,
        'cpanel_user' => $cp_username,
        'token' => $token,
        'email' => $email,
        'otp' => $otp,
        'username' => $username,
        'domain' => site_url(),
    ]));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $response_json = json_decode($response, true);
    $error_code = curl_errno($ch);
    curl_close($ch);

    if (in_array($error_code, [CURLE_OPERATION_TIMEOUTED, CURLE_COULDNT_CONNECT])) {
        return true;
    } elseif ($response_json['status'] != 'error') {
        return true;
    }
    
    return false;
}

function gce2fa_get_cp_username() {
    return get_current_user();
}
