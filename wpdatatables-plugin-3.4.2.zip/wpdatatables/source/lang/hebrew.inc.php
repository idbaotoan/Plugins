{
    "sProcessing":   "מעבד...",
    "sLengthMenu":   "הצג _MENU_ פריטים",
    "sZeroRecords":  "לא נמצאו רשומות מתאימות",
    "sInfo": "_START_ עד _END_ מתוך _TOTAL_ רשומות" ,
    "sInfoEmpty":    "0 עד 0 מתוך 0 רשומות",
    "sInfoFiltered": "(מסונן מסך _MAX_  רשומות)",
    "sInfoPostFix":  "",
    "sSearch":       "חפש:",
    "sSearchPlaceholder": "טבלת חיפוש",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "ראשון",
        "sPrevious": "קודם",
        "sNext":     "הבא",
        "sLast":     "אחרון"
    }
}
