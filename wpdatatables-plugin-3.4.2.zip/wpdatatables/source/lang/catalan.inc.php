{
    "sProcessing":   "Processant...",
    "sLengthMenu":   "Mostra _MENU_ registres",
    "sZeroRecords":  "No s'han trobat registres.",
    "sInfo":         "Mostrant de _START_ a _END_ de _TOTAL_ registres",
    "sInfoEmpty":    "Mostrant de 0 a 0 de 0 registres",
    "sInfoFiltered": "(filtrat de _MAX_ total registres)",
    "sInfoPostFix":  "",
    "sSearch":       "Filtrar:",
    "sSearchPlaceholder": "Taula de cerca",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "Primer",
        "sPrevious": "Anterior",
        "sNext":     "Següent",
        "sLast":     "Últim"
    }
}
