{
    "sProcessing":   "Зачекайте...",
    "sLengthMenu":   "Показати _MENU_ записів",
    "sZeroRecords":  "Записи відсутні.",
    "sInfo":         "Записи з _START_ по _END_ із _TOTAL_ записів",
    "sInfoEmpty":    "Записи з 0 по 0 із 0 записів",
    "sInfoFiltered": "(відфільтровано з _MAX_ записів)",
    "sInfoPostFix":  "",
    "sSearch":       "Пошук:",
    "sSearchPlaceholder": "Arama tablosu",
    "sUrl":          "",
    "oPaginate": {
        "sFirst": "Перша",
        "sPrevious": "Попередня",
        "sNext": "Наступна",
        "sLast": "Остання"
    }
}
