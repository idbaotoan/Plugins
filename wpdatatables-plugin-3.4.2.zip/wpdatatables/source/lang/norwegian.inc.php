{
    "sProcessing":   "Laster...",
    "sLengthMenu":   "Vis _MENU_ linjer",
    "sZeroRecords":  "Ingen linjer matcher s&oslash;ket",
    "sInfo":         "Viser _START_ til _END_ av _TOTAL_ linjer",
    "sInfoEmpty":    "Viser 0 til 0 av 0 linjer",
    "sInfoFiltered": "(filtrert fra _MAX_ totalt antall linjer)",
    "sInfoPostFix":  "",
    "sSearch":       "S&oslash;k:",
    "sSearchPlaceholder": "Søk i tabellen",
    "sUrl":          "",
    "oPaginate": {
        "sFirst":    "F&oslash;rste",
        "sPrevious": "Forrige",
        "sNext":     "Neste",
        "sLast":     "Siste"
    }
}
