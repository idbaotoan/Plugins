<div class="wpdt-c">
    <div class="alert alert-danger m-10" role="alert">
        <span class="wdt-alert-title f-600"><?php _e('Error','wpdatatables'); ?><br></span>
        <span class="wdt-alert-subtitle"><?php echo $errorMessage ?></span>
    </div>
</div>