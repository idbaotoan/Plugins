<?php defined('ABSPATH') or die('Access denied.'); ?>

<script type="text/x-template" id="wdt-color-picker-template">

    <div class="cp-container">
        <div class="form-group">
            <div class="fg-line dropdown">
                <div id="cp" class="input-group wdt-color-picker">
                    <input id="test" type="text" value="" class="cp-value wdt-add-picker"/>
                    <span class="input-group-addon wpcolorpicker-icon"><i></i></span>
                </div>
            </div>
        </div>
    </div>

</script>
