# FacetWP - Pods Framework integration

Requires Pods 2.7.9+ (currently in beta: https://pods.io/latest/)
