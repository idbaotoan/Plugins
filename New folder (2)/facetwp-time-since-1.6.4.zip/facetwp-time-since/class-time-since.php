<?php

class FacetWP_Facet_Time_Since_Addon extends FacetWP_Facet
{

    function __construct() {
        $this->label = __( 'Time Since', 'facetwp-time-since' );
    }


    /**
     * Parse the multi-line options string
     */
    function parse_choices( $choices ) {
        $choices = explode( "\n", trim( $choices ) );
        foreach ( $choices as $key => $choice ) {
            $temp = array_map( 'trim', explode( '|', $choice ) );

            $choices[ $key ] = [
                'label' => facetwp_i18n( $temp[0] ),
                'format' => $temp[1],
                'range' => $this->calculate_date_range( $temp[1] ),
                'counter' => 0,
            ];
        }

        return $choices;
    }


    function calculate_date_range( $format ) {
        $now = new \DateTime();
        $dt = new \DateTime( $format );

        // defaults
        $range = [
            'lower' => $now->format( 'Y-m-d-H:i:s' ),
            'upper' => $now->format( 'Y-m-d-H:i:s' )
        ];

        // -X <day/week/month> OR last <day of week>
        if ( 0 === strpos( $format, '-' ) || 0 === strpos( $format, 'last' ) ) {
            $range['lower'] = $dt->format( 'Y-m-d-H:i:s' );
            $range['upper'] = $now->format( 'Y-m-d-H:i:s' );
        }
        // +X <day/week/month> OR next <day of week>
        elseif ( 0 === strpos( $format, '+' ) || 0 === strpos( $format, 'next' ) ) {
            $range['lower'] = $now->format( 'Y-m-d-H:i:s' );
            $range['upper'] = $dt->format( 'Y-m-d-H:i:s' );
        }
        // today
        elseif ( 'today' == $format ) {
            $range['lower'] = $dt->format( 'Y-m-d');
            $range['upper'] = $dt->format( 'Y-m-d') . '-23:59:59';
        }
        // tomorrow
        elseif ( 'tomorrow' == $format ) {
            $range['lower'] = $dt->format( 'Y-m-d' );
            $range['upper'] = $dt->format( 'Y-m-d' ) . '-23:59:59';
        }
        // yesterday
        elseif ( 'yesterday' == $format ) {
            $range['lower'] = $dt->format( 'Y-m-d' ) . '-00:00:00';
            $range['upper'] = $dt->format( 'Y-m-d' ) . '-23:59:59';
        }

        return $range;
    }


    /**
     * Load the available choices
     */
    function load_values( $params ) {
        global $wpdb;

        $output = [];
        $facet = $params['facet'];
        $where_clause = $params['where_clause'];

        $sql = "
        SELECT f.facet_display_value
        FROM {$wpdb->prefix}facetwp_index f
        WHERE f.facet_name = '{$facet['name']}' $where_clause";
        $results = $wpdb->get_col( $sql );

        // Parse facet choices
        $choices = $this->parse_choices( $facet['choices'] );

        // Loop through the results
        foreach ( $results as $val ) {
            foreach ( $choices as $key => $choice ) {
                if ( $val >= $choice['range']['lower'] && $val <= $choice['range']['upper'] ) {
                    $choices[ $key ]['counter']++;
                }
            }
        }

        // Return an associative array
        foreach ( $choices as $choice ) {
            if ( 0 < $choice['counter'] ) {
                $output[] = [
                    'facet_display_value' => $choice['label'],
                    'counter' => $choice['counter'],
                ];
            }
        }

        return $output;
    }


    /**
     * Generate the facet HTML
     */
    function render( $params ) {

        $output = '';
        $facet = $params['facet'];
        $values = (array) $params['values'];
        $selected_values = (array) $params['selected_values'];

        $is_empty = empty( $selected_values ) ? ' checked' : '';
        $output .= '<div class="facetwp-radio' . $is_empty  . '" data-value="">' . __( 'Any', 'facetwp-time-since' ) . '</div>';

        foreach ( $values as $row ) {
            $display_value = esc_html( $row['facet_display_value'] );
            $safe_value = FWP()->helper->safe_value( $display_value );
            $selected = in_array( $safe_value, $selected_values ) ? ' checked' : '';
            $display_value .= " <span class='counts'>(" . $row['counter'] . ")</span>";
            $output .= '<div class="facetwp-radio' . $selected . '" data-value="' . esc_attr( $safe_value ) . '">' . $display_value . '</div>';
        }

        return $output;
    }


    /**
     * Filter the query based on selected values
     */
    function filter_posts( $params ) {
        global $wpdb;

        $facet = $params['facet'];
        $selected_values = $params['selected_values'];
        $selected_values = is_array( $selected_values ) ? $selected_values[0] : $selected_values;

        $choices = $this->parse_choices( $facet['choices'] );

        foreach ( $choices as $key => $choice ) {
            $safe_value = FWP()->helper->safe_value( $choice['label'] );
            if ( $safe_value === $selected_values ) {
                $lower = $choice['range']['lower'];
                $upper = $choice['range']['upper'];

                $sql = "
                SELECT DISTINCT post_id FROM {$wpdb->prefix}facetwp_index
                WHERE facet_name = %s AND facet_value >= %s AND facet_value <= %s";
                $sql = $wpdb->prepare( $sql, $facet['name'], $lower, $upper );
                return $wpdb->get_col( $sql );
            }
        }

        return [];
    }


    /**
     * Output any admin scripts
     */
    function admin_scripts() {
?>
<script>
(function($) {
    $(function() {
        FWP.hooks.addAction('facetwp/load/time_since', function($this, obj) {
            $this.find('.facet-source').val(obj.source);
            $this.find('.facet-choices').val(obj.choices);
        });
    
        FWP.hooks.addFilter('facetwp/save/time_since', function(obj, $this) {
            obj['source'] = $this.find('.facet-source').val();
            obj['choices'] = $this.find('.facet-choices').val();
            return obj;
        });
    });
})(jQuery);
</script>
<?php
    }


    /**
     * Output any front-end scripts
     */
    function front_scripts() {
        FWP()->display->assets['time-since-front.js'] = [ plugins_url( '', __FILE__ ) . '/assets/js/front.js', FACETWP_TIME_SINCE_VERSION ];
    }


    /**
     * Output admin settings HTML
     */
    function settings_html() {
?>
        <div class="facetwp-row">
            <div>
                <div class="facetwp-tooltip">
                    <?php _e( 'Choices', 'facetwp-time-since' ); ?>:
                    <div class="facetwp-tooltip-content"><?php _e( 'Enter the available choices (one per line)', 'facetwp-time-since' ); ?></div>
                </div>
            </div>
            <div><textarea class="facet-choices"></textarea></div>
        </div>
<?php
    }
}
