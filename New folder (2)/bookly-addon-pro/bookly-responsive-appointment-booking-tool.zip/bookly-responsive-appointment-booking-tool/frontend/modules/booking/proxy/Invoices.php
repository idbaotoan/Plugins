<?php
namespace Bookly\Frontend\Modules\Booking\Proxy;

use Bookly\Lib;

/**
 * Class Invoices
 * @package Bookly\Frontend\Modules\Booking\Proxy
 *
 * @method static string getDownloadButton() Get html for Download invoice button.
 */
abstract class Invoices extends Lib\Base\Proxy
{

}