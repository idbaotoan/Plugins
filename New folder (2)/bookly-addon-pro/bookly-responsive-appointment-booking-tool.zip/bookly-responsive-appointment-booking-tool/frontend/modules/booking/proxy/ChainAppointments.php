<?php
namespace Bookly\Frontend\Modules\Booking\Proxy;

use Bookly\Lib as BooklyLib;

/**
 * Deprecated, deleted in Bookly 18.7
 */
abstract class ChainAppointments extends BooklyLib\Base\Proxy
{

}