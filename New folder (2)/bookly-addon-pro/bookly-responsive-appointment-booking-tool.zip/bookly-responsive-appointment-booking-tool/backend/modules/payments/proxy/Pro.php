<?php
namespace Bookly\Backend\Modules\Payments\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @deprecated Bookly 19.7
 * @package Bookly\Backend\Modules\Notifications\Proxy
 */
abstract class Pro extends Lib\Base\Proxy
{
}