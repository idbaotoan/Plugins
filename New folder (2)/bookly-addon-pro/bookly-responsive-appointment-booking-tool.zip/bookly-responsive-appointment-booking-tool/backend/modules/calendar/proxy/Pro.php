<?php
namespace Bookly\Backend\Modules\Calendar\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Modules\Calendar\Proxy
 *
 * @method static void renderServicesFilterOption()
 */
abstract class Pro extends Lib\Base\Proxy
{

}