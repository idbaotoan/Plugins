<?php
namespace Bookly\Backend\Modules\Staff\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Modules\Staff\Proxy
 *
 * @method static array getCategoriesList() Get categories list.
 */
abstract class Pro extends Lib\Base\Proxy
{

}