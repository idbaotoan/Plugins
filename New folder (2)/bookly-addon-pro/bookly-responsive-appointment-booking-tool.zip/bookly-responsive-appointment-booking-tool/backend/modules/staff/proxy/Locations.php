<?php
namespace Bookly\Backend\Modules\Staff\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 18.9
 * @deprecated To be removed in the future
 */
abstract class Locations extends Lib\Base\Proxy
{

}