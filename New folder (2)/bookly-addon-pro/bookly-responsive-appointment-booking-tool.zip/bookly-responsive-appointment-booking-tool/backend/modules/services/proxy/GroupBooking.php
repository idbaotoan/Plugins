<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class GroupBooking
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class GroupBooking extends Lib\Base\Proxy
{

}