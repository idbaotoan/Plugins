<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class ServiceExtras
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class ServiceExtras extends Lib\Base\Proxy
{

}