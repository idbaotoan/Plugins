<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class Tasks
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class Tasks extends Lib\Base\Proxy
{

}