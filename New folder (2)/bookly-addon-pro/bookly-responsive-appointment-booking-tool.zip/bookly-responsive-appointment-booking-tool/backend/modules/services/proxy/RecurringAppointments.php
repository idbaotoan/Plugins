<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class RecurringAppointments
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class RecurringAppointments extends Lib\Base\Proxy
{

}