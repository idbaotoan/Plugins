<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class CustomerGroups
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class CustomDuration extends Lib\Base\Proxy
{

}