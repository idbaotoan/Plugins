<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class Packages
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class Packages extends Lib\Base\Proxy
{

}