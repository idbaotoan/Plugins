<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class DepositPayments
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class DepositPayments extends Lib\Base\Proxy
{

}