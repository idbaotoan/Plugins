<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class ServiceSpecialDays
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class ServiceSpecialDays extends Lib\Base\Proxy
{

}