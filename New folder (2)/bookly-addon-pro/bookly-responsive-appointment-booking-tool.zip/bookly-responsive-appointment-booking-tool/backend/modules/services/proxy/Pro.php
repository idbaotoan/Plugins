<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 *
 * @package Bookly\Backend\Components\Service\Proxy
 */
abstract class Pro extends Lib\Base\Proxy
{

}