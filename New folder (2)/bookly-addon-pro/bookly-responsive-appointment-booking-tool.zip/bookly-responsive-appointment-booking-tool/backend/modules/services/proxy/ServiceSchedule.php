<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class ServiceSchedule
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class ServiceSchedule extends Lib\Base\Proxy
{

}