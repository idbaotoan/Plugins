<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class CompoundServices
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class CompoundServices extends Lib\Base\Proxy
{

}