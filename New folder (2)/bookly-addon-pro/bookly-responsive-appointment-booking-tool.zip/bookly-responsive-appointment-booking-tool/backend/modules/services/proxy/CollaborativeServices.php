<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class CollaborativeServices
 * @package Bookly\Backend\Modules\Services\Proxy
 */
abstract class CollaborativeServices extends Lib\Base\Proxy
{

}