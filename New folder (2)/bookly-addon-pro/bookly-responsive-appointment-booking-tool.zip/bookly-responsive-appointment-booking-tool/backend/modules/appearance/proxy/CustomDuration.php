<?php
namespace Bookly\Backend\Modules\Appearance\Proxy;

use Bookly\Lib;

/**
 * Class GoogleMapsAddress
 * @package Bookly\Backend\Modules\Frontend\Proxy
 *
 * @method static void renderServiceDuration() render a select with service durations
 */
abstract class CustomDuration extends Lib\Base\Proxy
{
}