<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * Deprecated, will be deleted in Bookly 17.9
 */
abstract class Ratings extends Lib\Base\Proxy
{

}