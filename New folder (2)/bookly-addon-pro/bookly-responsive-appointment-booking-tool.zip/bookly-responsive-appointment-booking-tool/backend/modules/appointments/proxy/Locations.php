<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * Class Locations
 * @package Bookly\Backend\Modules\Appointments\Proxy
 *
 * @method static void renderFilter() Render location filter on appointments list page.
 */
abstract class Locations extends Lib\Base\Proxy
{

}