<?php
namespace Bookly\Backend\Components\Dialogs\Customer\Delete;

use Bookly\Lib;
use Bookly\Backend\Components\Controls\Buttons;

/**
 * Class Dialog
 * @package Bookly\Backend\Components\Dialogs\Customer\Delete
 */
class Dialog extends Lib\Base\Component
{
    /**
     * Render customer dialog.
     */
    public static function render()
    {
        self::enqueueScripts( array(
            'module' => array( 'js/delete-customers.js' => array( 'bookly-backend-globals' ), )
        ) );

        static::renderTemplate( 'dialog' );
    }
}