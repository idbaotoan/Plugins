<?php
namespace Bookly\Backend\Components\Dialogs\Customer\Edit\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 19.6
 * @deprecated To be removed in the future.
 * Class CustomerGroups
 * @package Bookly\Backend\Components\Dialogs\Customer\Edit\Proxy
 */
abstract class CustomerGroups extends Lib\Base\Proxy
{

}