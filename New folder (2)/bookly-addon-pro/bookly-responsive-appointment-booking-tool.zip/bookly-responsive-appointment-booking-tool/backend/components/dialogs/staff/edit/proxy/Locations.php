<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * Class Locations
 * @package Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy
 *
 * @method static void renderLocationSwitcher( int $staff_id, int $location_id, string $type ) Render location switcher.
 */
abstract class Locations extends Lib\Base\Proxy
{

}