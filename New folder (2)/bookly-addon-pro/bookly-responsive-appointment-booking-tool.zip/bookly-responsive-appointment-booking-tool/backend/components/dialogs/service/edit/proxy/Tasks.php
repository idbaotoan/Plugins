<?php
namespace Bookly\Backend\Components\Dialogs\Service\Edit\Proxy;

use Bookly\Lib;

/**
 * Class Tasks
 * @package Bookly\Backend\Components\Dialogs\Service\Edit\Proxy
 *
 * @method static void renderSubForm( array $service ) Render taxes sub-form.
 */
abstract class Tasks extends Lib\Base\Proxy
{

}