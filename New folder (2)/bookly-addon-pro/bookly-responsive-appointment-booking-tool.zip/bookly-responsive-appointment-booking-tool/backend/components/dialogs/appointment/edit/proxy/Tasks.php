<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 19.6
 * @deprecated To be removed in the future.
 * Class Tasks
 * @package Bookly\Backend\Components\Dialogs\Appointment\Edit\Proxy
 */
abstract class Tasks extends Lib\Base\Proxy
{

}