<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * Class Shared
 * @package Bookly\Backend\Components\Dialogs\Appointment
 *
 * @method static array prepareL10n( array $localize )
 */
abstract class Shared extends Lib\Base\Proxy
{

}