<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 19.6
 * @deprecated To be removed in the future.
 * Class Pro
 * @package Bookly\Backend\Components\Dialogs\Appointment
 */
abstract class Pro extends Lib\Base\Proxy
{

}