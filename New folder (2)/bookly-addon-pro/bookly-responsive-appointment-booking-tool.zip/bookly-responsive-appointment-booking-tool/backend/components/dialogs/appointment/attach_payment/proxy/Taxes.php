<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 19.6
 * @deprecated To be removed in the future.
 * Class Taxes
 * @package Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy
 */
abstract class Taxes extends Lib\Base\Proxy
{

}