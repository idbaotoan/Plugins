<?php
namespace Bookly\Backend\Components\Editable\Proxy;

use Bookly\Lib;

/**
 * Class Shared
 * @package Bookly\Backend\Components\Editable\Proxy
 *
 * @method static void renderModals()
 */
abstract class Shared extends Lib\Base\Proxy
{

}