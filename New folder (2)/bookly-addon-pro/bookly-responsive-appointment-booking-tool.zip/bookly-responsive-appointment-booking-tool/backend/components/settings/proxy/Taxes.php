<?php
namespace Bookly\Backend\Components\Settings\Proxy;

use Bookly\Lib;

/**
 * Class Taxes
 * @package Bookly\Backend\Components\Settings\Proxy
 *
 * @method static void renderHelpMessage() Render tax help message.
 */
abstract class Taxes extends Lib\Base\Proxy
{

}