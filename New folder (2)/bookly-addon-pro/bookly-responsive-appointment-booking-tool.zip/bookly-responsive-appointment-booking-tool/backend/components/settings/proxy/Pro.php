<?php
namespace Bookly\Backend\Components\Settings\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Components\Settings\Proxy
 *
 * @method static void renderPurchaseCode( $blog_id = null ) Render purchase code
 */
abstract class Pro extends Lib\Base\Proxy
{

}