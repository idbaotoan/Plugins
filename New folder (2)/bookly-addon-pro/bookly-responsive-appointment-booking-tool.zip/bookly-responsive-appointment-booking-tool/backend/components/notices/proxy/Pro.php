<?php
namespace Bookly\Backend\Components\Notices\Proxy;

use Bookly\Lib;

/**
 * Class Pro
 * @package Bookly\Backend\Components\Notices\Proxy
 *
 * @method static void renderWelcome()
 */
abstract class Pro extends Lib\Base\Proxy
{

}