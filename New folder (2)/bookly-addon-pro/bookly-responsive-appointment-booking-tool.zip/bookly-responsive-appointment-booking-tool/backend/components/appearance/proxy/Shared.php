<?php
namespace Bookly\Backend\Components\Appearance\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 19.3
 * @deprecated To be removed in the future
 */
abstract class Shared extends Lib\Base\Proxy
{

}