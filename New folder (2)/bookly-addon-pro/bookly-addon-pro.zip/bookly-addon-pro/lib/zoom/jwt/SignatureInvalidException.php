<?php
namespace BooklyPro\Lib\Zoom\Jwt;

class SignatureInvalidException extends \UnexpectedValueException
{
}
