<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="bookly-box bookly-table" id="bookly-js-birthday">
    <?php echo implode( '', $fields ) ?>
</div>