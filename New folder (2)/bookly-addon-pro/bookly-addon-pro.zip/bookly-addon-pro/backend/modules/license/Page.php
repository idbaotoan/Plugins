<?php
namespace BooklyPro\Backend\Modules\License;

use Bookly\Lib as BooklyLib;

/**
 * Class Page
 * @package BooklyPro\Backend\Modules\License
 */
class Page extends BooklyLib\Base\Component
{
    /**
     * Render page.
     */
    public static function render()
    {
        // license required page
    }
}