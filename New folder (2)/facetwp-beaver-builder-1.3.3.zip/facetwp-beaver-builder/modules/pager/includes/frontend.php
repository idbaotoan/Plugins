<?php

echo facetwp_display( 'pager' );