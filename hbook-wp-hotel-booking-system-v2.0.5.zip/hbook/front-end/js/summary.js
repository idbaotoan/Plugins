jQuery( document ).ready( function( $ ) {
	'use strict';
	hb_format_date();
});