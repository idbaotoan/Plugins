jQuery( document ).ready( function( $ ) {
	'use strict';
	$( '.wp-first-item a[href="admin.php?page=hb_menu"]' ).parent().remove();
});