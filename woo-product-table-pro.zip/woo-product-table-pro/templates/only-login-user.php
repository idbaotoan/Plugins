<?php
$login_url  = apply_filters( 'wpto_login_url', admin_url(), $table_ID, $settings, $keyword );
// $login_text = apply_filters( 'wpto_login_button_text', sprintf( __( 'Login %s', 'wpt_pro' ), __( 'to see ', 'wpt_pro') . $keyword ), $table_ID, $settings, $keyword  );
$login_text = apply_filters( 'wpto_login_button_text', sprintf( __( 'Login', 'wpt_pro' ) ), $table_ID, $settings, $keyword  );
?>
<a href="<?php echo esc_url( $login_url ); ?>"><?php echo esc_html( $login_text ); ?></a>