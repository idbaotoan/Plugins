<?php
/**
 * Nothing to say
 * Invisibale Restricted Access
 */
?>
<!-- Silence is better than nothing -->