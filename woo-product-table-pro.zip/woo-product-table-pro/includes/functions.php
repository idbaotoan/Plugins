<?php
/****** PRO VERSION - INCLUDE / FRONTEND FUNCTION *******
 * WPT PRO VERSION
 * MAIN MODULE
 */
add_filter( 'wpto_item_final_loc', 'wpt_pro_template_for_guest_user', 10, 6 );

if( !function_exists( 'wpt_pro_template_for_guest_user' ) ){
    /**
     * Chnage the template url for not logged in user
     * 
     * @since 7.0.9.0
     */
    function wpt_pro_template_for_guest_user( $file, $file_name, $items_directory_2, $keyword, $table_ID, $settings ){
        if( is_user_logged_in() ){
            return $file;
        }
        
        $only_log_file = false;
        if( isset( $settings['only_login_user'] ) ){
            $only_log_file = WPTP_BASE_DIR . 'templates/only-login-user.php';
        }
        if( is_file( $only_log_file ) ){
            $file = $only_log_file;
        }
        return $file;
    }
}

if( !function_exists( 'wpt_pro_user_login_col' ) ){
    /**
     * To hide colum based on LogedIn user 
     * getting data from post data
     * Used: $enabled_column_array = apply_filters( 'wpto_enabled_column_array', $enabled_column_array, $table_ID, $atts, $column_settings, $column_array ); 
     * 
     * @param type $enabled_column_array
     * @param type $table_ID
     * @param type $atts
     * @param type $column_settings
     * @param type $column_array
     * @return type
     */
    function wpt_pro_user_login_col( $enabled_column_array, $table_ID, $atts, $column_settings  ){
        if( !is_array( $enabled_column_array ) || is_user_logged_in() ){
            return $enabled_column_array;
        }
        $configure = get_option('wpt_configure_options');
        
        foreach( $enabled_column_array as $key=>$colname ){
            if( isset( $column_settings[$key]['only_login_user'] ) && ! isset( $configure['column_hide_for_guest'] ) ){
                unset( $enabled_column_array[$key] );
            }
        }
        return $enabled_column_array;
    }
}
add_filter( 'wpto_enabled_column_array', 'wpt_pro_user_login_col', 10, 4 );

if( !function_exists( 'wpt_pro_user_login_item' ) ){
    
    /**
     * To hide Item of inside colum based on LogedIn user 
     * getting data from post data
     * 
     * $extra_items = apply_filters( 'wpto_extra_items_arr', $extra_items, $keyword, $column_settings, $table_ID, $product );
     * @param type $settings
     * @param type $table_ID
     * @param type $product
     * @param type $column_settings
     * @return type
     */
    function wpt_pro_user_login_item( $extra_items, $keyword, $column_settings ){
        if( !is_array( $extra_items ) || is_user_logged_in() ){
            return $extra_items;
        }
        $configure = get_option('wpt_configure_options');
        foreach( $extra_items as $i=>$item ){
            if( isset( $column_settings[$item]['only_login_user'] ) && ! isset( $configure['column_hide_for_guest'] ) ){
                // unset( $extra_items[$i] );
            }
        }
        return $extra_items;
    }
}
add_filter( 'wpto_extra_items_arr', 'wpt_pro_user_login_item', 10, 3 );

if( !function_exists( 'wpt_pro_add_default_col_arr' ) ){
    /**
     * Added two new Default Column for Pro version
     * 
     * @param type $column_array
     */
    function wpt_pro_add_default_col_arr( $column_array ){
        $column_array['shortcode'] = __( 'Shortcode', 'wpt_pro' );
        $column_array['content'] = __( 'Content', 'wpt_pro' );
        $column_array['audio_player'] = __( 'Audio', 'wpt_pro' );
        $column_array['quick_qty'] = __( 'Quick Qty', 'wpt_pro' ); //Added at V7.0.9.0
        $column_array['viewed'] = __( 'Viewed', 'wpt_pro' ); //Added at V78.0.1.0
        return $column_array;
    }
}
add_filter( 'wpto_default_column_arr', 'wpt_pro_add_default_col_arr' );

if( !function_exists( 'wpt_pro_change_template_folder' ) ){
    
    /**
     * TEMPLATE MAIN FOLDER DIRECTORY change for our Special column content
     * currently we have added new only two new column
     * and add two items file inside includes/items/
     * And we need to change main directory for that, and we did it
     * Even user also able to change template file loc
     * 
     * NEW ADDED: TEMPLATE CHANGE on type wise. Column Type Wise.
     * usings filter: $items_directory_1 = apply_filters('wpto_template_folder', $items_directory,$keyword, $type, $table_ID, $product, $settings, $column_settings );
     * 
     * 
     * @param String $items_directory
     * @param String $keyword
     * @return String
     */
    function wpt_pro_change_template_folder( $items_directory, $keyword, $type ){
        $our_pro_column = array(
            'shortcode',
            'content',
            'audio_player',
            'quick_qty', //Added at V7.0.9.0
            'viewed', //Added at V8.0.1.0
        );
        
        $our_pro_type = array(
            //'blank_type',
            'acf',
            'audio',
            'hook_action',
            'array',
            'all_content',
        );
        $items_pro_dir = WPTP_DIR_BASE . 'includes/items/';
        //var_dump(in_array( $keyword, $our_pro_column ),in_array( $keyword, $our_pro_column ) ? $items_permanent_dir : $items_directory );
        $my_item_dir = in_array( $keyword, $our_pro_column ) ||  in_array( $type, $our_pro_type ) ? $items_pro_dir : $items_directory;
        return $my_item_dir;
    }
}
add_filter( 'wpto_template_folder', 'wpt_pro_change_template_folder', 50, 3 );


if( !function_exists( 'wpt_pro_args_manipulation_frontend' ) ){
    /**
     * IN PRO
     * Args Manipulation for FrontEnd
     * By Useing following Filter
     * $args = apply_filters( 'wpto_table_query_args', $args, $table_ID, $atts, $column_settings, $enabled_column_array, $column_array );
     * 
     * @param type $args
     * @param type $table_ID
     * @param type $atts
     * @param type $column_settings
     * @param type $enabled_column_array
     * @param type $column_array
     * @return type
     */
    function wpt_pro_args_manipulation_frontend( $args, $table_ID, $atts, $column_settings, $enabled_column_array, $column_array ){
        
        /**
         * Has Transferred into Free Version
        //MainTain for Archives Page
        global $wpdb;
        $page_query = isset( $GLOBALS['wp_query'] ) ? $GLOBALS['wp_query']->query_vars : null;
        $args_product_in = false;
        if( isset( $page_query['wc_query'] ) && $page_query['wc_query'] == 'product_query' ){
            $gen_args = array_merge( $args,$GLOBALS['wp_query']->query_vars );
            $gen_args['post_type'] = isset( $args['post_type'] ) && !empty( $args['post_type'] ) ? $args['post_type'] : 'product';
            $args = $gen_args;

            $sql = $GLOBALS['wp_query']->request;
            $results = $wpdb->get_results( $sql, ARRAY_A );
            $args_product_in = array();
            foreach( $results as $result ){
                $args_product_in[] = $result['ID'];
            }
            $args['post__in'] = $args_product_in;
            $args['paged'] = 0;
            unset( $args['tax_query'] );
            unset( $args['meta_query'] );
        }
        */
        
        
        /**
         * Args Management from atts
         */
        $temp_atts = $atts;
        unset($temp_atts['id']);
        unset($temp_atts['name']);
        unset($temp_atts['meta_query']);
        unset($temp_atts['tax_query']);
        unset($temp_atts['table_ID']);
        if( is_array( $temp_atts ) && count( $temp_atts ) > 0 ){
            foreach( $temp_atts as $att_key => $att_val ){
               $args[$att_key] = $att_val;
            }
        }
        return $args;
    }
}
add_filter( 'wpto_table_query_args', 'wpt_pro_args_manipulation_frontend', 10, 6 );

if( !function_exists( 'wpt_shortcode_column_add' ) ){
    /**
     * Add new shortcode Column for Product Table Edit part
     * to show new column in table
     * 
     * @param Array $column_settings
     */
    function wpt_shortcode_column_add( $_device_name, $column_settings ){
        
       $shortcode = isset( $column_settings['shortcode']['content'] ) ? $column_settings['shortcode']['content'] : false;
       ?>
        <label>Input Your Shortcode Content:</label>
        <input type="text" name="column_settings<?php echo $_device_name; ?>[shortcode][content]" value='<?php echo esc_attr( $shortcode ); ?>'>
        <div class="wpt-column-info">
            <b>Supported Dynamic Value</b>
            <ul>
                <li><code>%product_id%</code>: Product ID</li>
                <li><code>%sku%</code>: Product SKU</li>
                <li><code>%name%</code>: Product Title</li>
                <li><code>%excerpt%</code>: Short Description</li>
                <li>... <a href="https://wooproducttable.com/supported-attributes-of-shortcode-and-content-column/" target="_blank"><?php echo esc_html__( 'Full list of Dynamic Shortcode', 'wpt_pro' ); ?></a></li>
            </ul>
            <p class="hints">Example: <strong>[favorite_button post_id="%product_id%" title="%name%"]</strong><br /></p>
        </div>
       <?php
   }
}
add_action( 'wpto_column_setting_form_shortcode', 'wpt_shortcode_column_add', 10, 2 );

if( !function_exists( 'wpt_content_column_add' ) ){
    
    
   function wpt_content_column_add( $_device_name, $column_settings ){

        $my_values = isset( $column_settings['content']['content'] ) ? $column_settings['content']['content'] : false;

        $settings = array(
            'textarea_name'     =>'column_settings' . $_device_name . '[content][content]',
            'textarea_rows'     => 3,
            'teeny'             => false,
            'autocomplete'             => 'on',
            );
        wp_editor( wp_kses_post( $my_values ), 'wpt_content_column' . $_device_name, $settings ); 
        ?>
        <div class="wpt-column-info">
            <b>Supported Dynamic Value</b>
            <ul>
                <li><code>%product_id%</code>: Product ID</li>
                <li><code>%sku%</code>: Product SKU</li>
                <li><code>%name%</code>: Product Title</li>
                <li><code>%excerpt%</code>: Short Description</li>
                <li>... <a href="https://wooproducttable.com/supported-attributes-of-shortcode-and-content-column/" target="_blank"><?php echo esc_html__( 'Full list of Dynamic Shortcode', 'wpt_pro' ); ?></a></li>
            </ul>
            <p class="hints"> <?php echo esc_html__( 'Example of Content Box with Supported Shortcode', 'wpt_pro' ); ?> <a href="https://wooproducttable.com/supported-attributes-of-shortcode-and-content-column/" target="_blank"><?php echo esc_html__( 'Click Here', 'wpt_pro' ); ?></a></p>
        </div>    
        <?php
    }

}
add_action( 'wpto_column_setting_form_content', 'wpt_content_column_add', 10, 2 );

if( !function_exists( 'wpt_mce_autosave_mod' ) ){
    /**
     * For Testing, It was added, Currently it's disabled.
     * Can be use later
     * 
     * @param array $init
     * @return string
     */
    function wpt_mce_autosave_mod( $init ) {
        $init['setup'] = 'function(a){a.on("change",function(b){jQuery(this).parent().find(\'#btnEditCharJournal\').trigger("click"),console.log("the event object ",b),console.log("the editor object ",a),console.log("the content ",a.getContent())})}';     
        return $init;
    }
}
//add_filter('tiny_mce_before_init', 'wpt_mce_autosave_mod');




if( !function_exists( 'wpt_add_extra_inside_items' ) ){
    function wpt_add_extra_inside_items( $columns_array ){
        //wpto_inside_item_arr
        $columns_array['menu_order'] = "Menu Order";
        //$columns_array['menu_order'] = "Menu Order";
        return $columns_array;
    }
}

add_filter( 'wpto_inside_item_arr', 'wpt_add_extra_inside_items' ); //$items,$keyword, $column_settings, $columns_array, $post

if( !function_exists( 'wpt_pro_body_class' ) ){
    /**
     * Special Boddy Class for Pro Version
     * 
     * @global type $post
     * @global type $shortCodeText
     * @param type $class
     * @return string
     */
    function wpt_pro_body_class( $class ) {
        global $post,$shortCodeText;

        if( isset($post->post_content) && has_shortcode( $post->post_content, $shortCodeText ) ) {
            $class[] = 'wpt_table_body_pro';
            $class[] = 'wpt_pro_table_body';
        }
        return $class;
    }
}
add_filter( 'body_class', 'wpt_pro_body_class' );

if( !function_exists( 'wpt_pro_wrapper_class' ) ){
    /**
     * Special Boddy Class for Pro Version
     * By using following Filter:
     * apply_filters( 'wpto_wrapper_tag_class_arr', $wrapper_class_arr, $table_ID, $args, $column_settings, $enabled_column_array, $column_array )
     * Available in shortcode.php file in Main Module
     * 
     * @global type $post
     * @global type $shortCodeText
     * @param type $class
     * @return string
     */
    function wpt_pro_wrapper_class( $class ) {
        $configure = get_option('wpt_configure_options');//advance_search
        $class[] = isset( $configure['advance_search'] ) ? 'wpt_advance_search' : '';
        $class[] = isset( $configure['column_sort'] ) ? 'wpt_column_sort' : '';
        return $class;
    }
}
add_filter( 'wpto_wrapper_tag_class_arr', 'wpt_pro_wrapper_class' );




if( !function_exists( 'wpt_custom_search_join' ) ){
    /**
     * Extend WordPress search to include custom fields
     *
     * Join posts and postmeta tables
     *
     * http://codex.wordpress.org/Plugin_API/Filter_Reference/posts_join
     */
    function wpt_custom_search_join( $join,$wp_query ) {
        global $wpdb;
        $validation = $wp_query->get( 'wpt_query_type' );
        $config = get_option( 'wpt_configure_options' ); //advance_search
        $v_fix = isset( $config['advance_search_issue'] ) && $config['advance_search_issue'] == 'on' ? false : true;
        if(!empty( $validation ) && $validation == 'search' && ( !empty($wp_query->query_vars['s']) || !empty($wp_query->query_vars['wpt_custom_search']) ) && $v_fix ){
            $join .=' LEFT JOIN '.$wpdb->postmeta. ' AS wpt_table ON '. $wpdb->posts . '.ID = wpt_table.post_id ';
        }
        return $join;
    }
}

if( !function_exists( 'wpt_custom_search_where' ) ){
    /**
     * Modify the search query with posts_where
     *
     * http://codex.wordpress.org/Plugin_API/Filter_Reference/posts_where
     */
    function wpt_custom_search_where( $where, $wp_query ) {
        global $pagenow, $wpdb;

        $validation = $wp_query->get( 'wpt_query_type' );

        if(!empty( $validation ) && $validation == 'search'  && ( !empty($wp_query->query_vars['s']) || !empty($wp_query->query_vars['wpt_custom_search']) ) ):
        $search_term = $wp_query->get( 'wpt_custom_search' );
        $search_from = false;
        if( is_string( $search_term ) && !empty($search_term) ){
            $search_term = ltrim($search_term);
            $search_term = rtrim( $search_term );

            $table_ID = $wp_query->get( 'table_ID' );

            $search_from = get_post_meta( $table_ID, 'search_n_filter', true );
            $search_from = isset($search_from['search_from']) && is_array( $search_from['search_from'] ) && count( $search_from['search_from'] ) > 0 ? $search_from['search_from'] : false;
        }else{
            $search_term = false;
        }

        if ( $search_from && !empty( $search_term ) ) {

            $inter_sql = array();
            foreach( $search_from as $search_item => $table_name ){
                $numeric = is_numeric( $search_item );
                $percent = !$numeric ? "%" : "";

                if( $table_name == 'posts' ){

                    $inter_sql[] =  $wpdb->posts . ".". $search_item . ' LIKE \'' . $percent . esc_sql( like_escape( $search_term ) ) . $percent . '\'';
                }elseif( $table_name == 'postmeta' ){

                    $inter_sql[] = "(wpt_table.meta_key='{$search_item}' AND wpt_table.meta_value LIKE'" . $percent . esc_sql( like_escape( $search_term ) ) . $percent . "')";
                }
            }
            $inter_sql_implode = implode( ' OR ', $inter_sql );
            $where .= !empty( $inter_sql_implode ) ? ' AND (' . $inter_sql_implode . ')' : false;
        }else{

            $myPreg = "(".$wpdb->posts.".post_title LIKE $1) OR (wpt_table.meta_value LIKE $1" . ")";
            $where = preg_replace("/\(\s*".$wpdb->posts.".post_title\s+LIKE\s*(\'[^\']+\')\s*\)/",$myPreg, $where );

        }
        endif;

        return $where;
    }
}

if( !function_exists( 'wpt_custom_search_distinct' ) ){
    /**
     * Prevent duplicates
     *
     * http://codex.wordpress.org/Plugin_API/Filter_Reference/posts_distinct
     */
    function wpt_custom_search_distinct( $where ) {
            global $wpdb;
            return "DISTINCT";
            return $where;

    }
}
//add_filter('posts_request', function( $request, $wp_query){
//    print_r($request);
//    return $request;
//}, 10, 2);
if( !function_exists( 'wpt_search_filter' ) ){
    function wpt_search_filter(){
        add_filter('posts_join', 'wpt_custom_search_join', 10, 2 );
        add_filter( 'posts_where', 'wpt_custom_search_where',10 ,2 );
        add_filter( 'posts_distinct', 'wpt_custom_search_distinct' );

    }
}

$config = get_option( 'wpt_configure_options' ); //advance_search
 if( isset( $config['advance_search'] ) && $config['advance_search'] == 'on' ){
    add_filter('init','wpt_search_filter');
 }


if( !function_exists( 'wpt_taxonomy_page_template' ) ){
   
    function wpt_taxonomy_page_template( $template_file ) {
        
        //Taxonomy page na hole amra niche jaboi na.
        if( ! is_product_taxonomy() ) return $template_file;

        $id = get_queried_object_id();
        $taxo_table_id = get_term_meta( $id, 'table_id', true );
        
        //empty hole ba numeric na hole niche jaboi na.
        if( empty( $taxo_table_id ) || !is_numeric( $taxo_table_id ) ) return $template_file;
        
           
        $my_archive = WPTP_BASE_DIR . 'templates/product-archives.php';
        $my_archive = apply_filters( 'wpto_taxonomy_page_template_loc', $my_archive, $template_file );
        $template_file = file_exists( $my_archive ) ? $my_archive : $template_file;

        return $template_file;
    }
}
 
add_filter( 'template_include', 'wpt_taxonomy_page_template', 99999 );




if( !function_exists( 'wpt_archives_page_template' ) ){
   
    function wpt_archives_page_template( $template_file ) {
        
        
        /**
         * Detect Search Page
         * Actually when user will search product using wc default search box
         */
        $search_page = isset( $_GET['s'] ) && isset( $_GET['post_type'] ) && $_GET['post_type'] == 'product' ? true : false;
        
        $search_page = apply_filters('wpto_search_page_template', $search_page, $template_file );
        
        $shop_display = get_option('woocommerce_shop_page_display');
        $cat_display = get_option('woocommerce_category_archive_display');

        $id = get_queried_object_id();

        
        $child = get_term_children( $id, 'product_cat');    
        
        if( ( is_shop() && $shop_display == 'subcategories' && ! $search_page ) || ( ! empty( $child ) && $cat_display == 'subcategories' && ! $search_page ) ){
            return $template_file;
        }
        $page_template_validation = apply_filters( 'wpto_direct_template_validation', true, $template_file );
        
        if( ( is_shop() || is_product_taxonomy() ) && $page_template_validation ){
           
           $my_archive = WPTP_BASE_DIR . 'templates/product-archives.php';
           $my_archive = apply_filters( 'wpto_archvie_page_template_loc', $my_archive, $template_file );
           return file_exists( $my_archive ) ? $my_archive : $template_file;
       }
       
       if( $page_template_validation && strpos( $template_file, 'dokan' ) > 0 && strpos( $template_file, 'store' ) > 0 ){
           $my_archive = WPTP_BASE_DIR . 'templates/store.php';
           $my_archive = apply_filters( 'wpto_dokan_page_template_loc', $my_archive, $template_file );
           return file_exists( $my_archive ) ? $my_archive : $template_file;
       }
       
       return $template_file;
    }
}
if( isset( $config['table_on_archive'] ) && $config['table_on_archive'] == 'on' ){  
    add_filter( 'template_include', 'wpt_archives_page_template', 999 );
}

if( !function_exists( 'wpt_playlist_class_body' ) ){
     
    function wpt_playlist_class_body( $table_class_arr ){
        $table_class_arr[] = 'playlist';
        return $table_class_arr;
    }

}
add_filter( 'wpto_table_tag_class_arr', 'wpt_playlist_class_body' );

//add_action( 'wpto_column_setting_form_inside_audio_player','wpt_audio_column_settings', 10, 2 );
add_action( 'wpto_column_setting_form_audio_player','wpt_audio_column_settings', 10, 2 );
function wpt_audio_column_settings( $_device_name, $column_settings ){
//     var_dump($column_settings['audio_player']);
    $audio_player = isset( $column_settings['audio_player'] ) ? $column_settings['audio_player'] : false;
    $audio = isset( $audio_player['player_position'] ) ? 'checked' : '';
    $auto_play = isset( $audio_player['auto_play'] ) ? 'checked' : '';
    $b_color = isset( $audio_player['bg_color'] ) ? $audio_player['bg_color'] : '';
    $pbar_color = isset( $audio_player['progressbar_color'] ) ? $audio_player['progressbar_color'] : '';
    
    
    ?>
<ul class="sss">
    <li>
        <label>Stick to Bottom?</label>
        <input type="checkbox" name="column_settings<?php echo $_device_name; ?>[audio_player][player_position]" <?php echo $audio; ?>>
        <!--
        <label>Auto Play</label>
        <input type="checkbox" name="column_settings[audio_player][auto_play]" <?php echo $auto_play; ?>>
        -->
    </li>
    <li>
        <label>Background Color</label>
        <input type="input" class="ua_input wpt-color" name="column_settings<?php echo $_device_name; ?>[audio_player][bg_color]" value="<?php echo $b_color; ?>">
        <label>Progress Bar Color</label>
        <input type="input" class="ua_input wpt-color" name="column_settings<?php echo $_device_name; ?>[audio_player][progressbar_color]" value="<?php echo $pbar_color; ?>">
    </li>
    <li>

<p>
    Create custom field by ACF<br>
    with following name, to display your desired item.<br>
    <code>audio_file</code>: For Audio Source as File Type<br>
    <code>audio_artist</code>: For Artist of Audio, use audio_artist custom field<br>
    <code>audio_title</code>: For Label/Title of Audio, use audio_title custom field. If not found <i>audio_title</i> field, Product tile will display<br>
</p>
<?php
}


if( !function_exists( 'wpt_pro_add_toggle_content' ) ){
    
    /**
     * Showing Toggle Button with text to Show/Hide full content of that TD
     * 
     * @param type $keyword
     * @param type $table_ID
     * @param type $settings Available full setting Like following
     * array (size=8)
  'type' => string 'default' (length=7)
  'type_name' => string 'Default' (length=7)
  'tag' => string '' (length=0)
  'tag_class' => string 'item_product_title_919 item_dJLoDtTFHw' (length=38)
  'toggle' => string 'on' (length=2)
  'toggle_label' => string 'Hello To Bangladesh' (length=19)
  'style' => 
    array (size=11)
      'color' => string '' (length=0)
      'background-color' => string '' (length=0)
      'border' => string '' (length=0)
      'text-align' => string '' (length=0)
      'vertical-align' => string '' (length=0)
      'width' => string '' (length=0)
      'height' => string '' (length=0)
      'font-size' => string '' (length=0)
      'font-style' => string '' (length=0)
      'padding' => string '' (length=0)
      'margin' => string '' (length=0)
  'style_str' => string '' (length=0)
     * 
     * 
     * @return void Return Nothing, It will show a Toggle Button
     */
    function wpt_pro_add_toggle_content( $keyword, $table_ID, $settings ){
        if( isset( $settings['toggle'] ) ){
            $label = isset( $settings['toggle_label'] ) && !empty( $settings['toggle_label'] ) ? $settings['toggle_label'] : esc_html__( 'Click to view', 'wpt_pro' );
            echo wp_kses_post('<span class="wpt_click_to_view"><i>+</i> ' . $label . '</span>');
        }
        return;
    }
}
add_action( 'wpto_column_top', 'wpt_pro_add_toggle_content', 10, 3);

if( !function_exists( 'wpt_show_variation_table' ) ){
    
    /**
     * Show variation table on each and every variable product page
     * which will replaced the default variation dropdown select options.
     * 
     * 
     * @since 7.0.8.1
     */
    function wpt_show_variation_table(){
        
        global $product;
        //var_dump($product->get_type());
        if( $product->get_type() !== 'variable' ) return;
        
        
        $config = get_option( 'wpt_configure_options' ); 
        $enable = isset( $config['table_for_variable_product'] ) && $config['table_for_variable_product'] == 'on' ? true : false;
        //if( isset( $config['table_on_archive'] ) && $config['table_on_archive'] == 'on' )
        
        $table_id = isset( $config['variation_table_id'] ) ? $config['variation_table_id'] : false;
        $table_id = apply_filters( 'wpto_variation_table_id', $table_id );
        $table_id = is_numeric( $table_id ) ? (int) $table_id : false;
        //var_dump($table_id);
        if( $table_id && $enable ){
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
            add_action( 'woocommerce_after_single_product_summary', 'wpt_woo_product_table_as_variation', 1 ); 
        }
        
        
    }
}

add_action( 'woocommerce_single_product_summary', 'wpt_show_variation_table', 3 );


if( !function_exists( 'wpt_woo_product_table_as_variation' ) ){
    function wpt_woo_product_table_as_variation(){

        $config = get_option( 'wpt_configure_options' ); 

        $table_id = isset( $config['variation_table_id'] ) ? $config['variation_table_id'] : false;
        $table_id = apply_filters( 'wpto_variation_table_id', $table_id );
        $table_id = is_numeric( $table_id ) ? (int) $table_id : false;
        //var_dump($table_id);
        if( $table_id ){
            add_filter( 'wpto_table_query_args', 'wpt_variation_table_args' );
            echo do_shortcode( "[Product_Table id='{$table_id}']" );
        }
    }
}

if( !function_exists( 'wpt_variation_table_args' ) ){
    
    /**
     * Args manipulation for variable product
     * 
     * @param type $args
     * @return type
     */
    function wpt_variation_table_args( $args ){
        
        $_ID = get_the_ID();
        $this_post_variable = new WC_Product_Variable( $_ID );
            $available_post_includes = $this_post_variable->get_children();

            if( isset( $available_post_includes ) && is_array($available_post_includes) && count( $available_post_includes ) > 0 ){
                foreach ($available_post_includes as $pperItem){
                    $product_includes[$pperItem] = $pperItem;
                }
            }

            
            $args['post_type'] = array( 'product', 'product_variation' );
            $args['post__in'] = $product_includes;
            unset( $args['tax_query'] );
            unset( $args['meta_query'] );
//            var_dump($args);
            return $args;
    }
}

/****************** NEW CODE *********************/


if( !function_exists( 'wpt_quckcart_fragments_for_products' ) ){
    function wpt_quckcart_fragments_for_products( $fragments ){
        ob_start();
        $Cart = WC()->cart->cart_contents;
        $product_response = false;
        if( is_array( $Cart ) && count( $Cart ) > 0 ){
            foreach($Cart as $perItem){
                
                $pr_id = (String) $perItem['product_id'];
                $pr_value = (String) $perItem['quantity'];
                $product_response[$pr_id] = $pr_value;
            }
        }
        $fragments['wpt_quckcart'] = $product_response;
        
        return $fragments;
    }
}
add_filter( 'woocommerce_add_to_cart_fragments', 'wpt_quckcart_fragments_for_products', 10 );



if( !function_exists( 'wpt_quckcart_ajax_update' ) ){
    function wpt_quckcart_ajax_update(){
        global $wpdb, $woocommerce;
        
        $contents = $woocommerce->cart->get_cart();

        $product_id = !empty( $_POST['product_id'] ) ? $_POST['product_id'] : false;
        $qty_val = !empty( $_POST['qty_val'] ) ? $_POST['qty_val'] : 0;
        $quantity = is_numeric( $qty_val ) ? (int) $qty_val : $qty_val;
        if( !$product_id ){
            return;
        }

        $product = wc_get_product( $product_id );
        $stock = $product->get_stock_quantity();
        if( ! empty( $stock ) && $quantity > $stock ){
            $quantity = $stock; 
        }

        if( $product->is_sold_individually() && $quantity > 0 ){
            $quantity = 1;
        }

        
        $add_to_cart = true;
        
        foreach ( $contents as $cart_item_key => $cart_item_data ){
            

            if( $cart_item_data['product_id'] == $product_id ){
                $add_to_cart = false;

                WC()->cart->set_quantity( $cart_item_key, $quantity, true );

            }
            
        }
        if( $add_to_cart ){
            $woocommerce->cart->add_to_cart( $product_id, $quantity );
        }
        
        WC()->cart->calculate_totals();

        WC_AJAX::get_refreshed_fragments();
        die();
    }
}
add_action( 'wp_ajax_wpt_quckcart_ajax_update', 'wpt_quckcart_ajax_update' );
add_action( 'wp_ajax_nopriv_wpt_quckcart_ajax_update', 'wpt_quckcart_ajax_update' );


if( !function_exists( 'wpt_quckcart_count_info' ) ){
    function wpt_quckcart_count_info( $fragments ){
        WC()->cart->calculate_totals();
        WC_AJAX::get_refreshed_fragments();
    }
}
add_action( 'wp_ajax_wpt_quckcart_count_info', 'wpt_quckcart_count_info' );
add_action( 'wp_ajax_wpt_quckcart_count_info', 'wpt_quckcart_count_info' );

if( !function_exists( 'wpt_pro_cf_filter_show' ) ){
    
    /**
     * Displaying Custom Field Filter Showing 
     * Under Advance Search Filter
     * 
     * 
     * Create filter using custom field for Product Table
     * This feature will be found under Search & Filter tab
     * 
     * @since 7.0.9
     */
    function wpt_pro_cf_filter_show( $table_ID ){

        $meta =  get_post_meta( $table_ID, 'search_n_filter', true );
        
        if( isset( $meta['cf_search_box'] ) && $meta['cf_search_box'] == 'no' ){
            return;
        }
       
        
        
        $data = get_post_meta( $table_ID, '_cf_filter', true );
        $label_text = get_post_meta($table_ID,'_cf_filter_text_data',true );

        $choose_text = isset( $label_text['choose_text'] ) && !empty( $label_text['choose_text'] ) ? $label_text['choose_text'] : "Choose";
        $multiple_bool = isset( $label_text['choose_text'] ) && empty( $label_text['choose_text'] ) ? true : false;
        $multiple = apply_filters('wpt_custom_field_multiple', $multiple_bool, $table_ID );
        $multiple_txt = $multiple ? 'multiple' : '';
        
        $html = "";
        if( is_array( $data ) && count( $data ) > 0 ):

            $inside_html = false;

            foreach( $data as $key => $items ){

                if( ! isset( $items['values'] ) || ! isset( $items['label'] ) ) continue;

                if( is_array( $items ) && is_array( $items['values'] ) ){
                    $name = $items['label'];
                    $item_values = $items['values'];
                    $inside_html .='<div class="search_single_column cf_fielter cf_fielter_wpt">';
                    $inside_html .= '<label class="search_keyword_label">' . $name . '</label>';
                    $inside_html .='<select data-key="' . $key . '"  class="search_select cf_query cf_query_' . $multiple_txt . '" tabindex="-1" ' . $multiple_txt . '>';
                    
                    $inside_html .= ! $multiple ? '<option value="">' . $choose_text . ' ' . $name . '</option>' : '';
                    foreach( $item_values as $item ){
                        $option_label = apply_filters( 'wpt_custom_field_option_label', $item, $table_ID );
                        $inside_html .='<option value="' . $item . '">' . $option_label . '</option>';
                    }

                    $inside_html .='</select >';
                    $inside_html .= '</div>';
                }

            }
            if( $inside_html ){
                $html .= "<div id='search_box_{$table_ID}' class='wpt_search_box search_box_{$table_ID}'>";
                $html .= "<div class='wpt_filter_wrapper'>";
                $html .= $inside_html;
                $html .= '<button data-type="query" data-temp_number="' . $table_ID . '" id="wpt_query_search_button_' . $table_ID . '" class="button wpt_search_button query_button wpt_query_search_button wpt_query_search_button_' . $table_ID . '">Search</button>';
                $html .= "</div>";
                $html .= "</div>";
            }

        endif;
        echo $html;
    }

}
add_action( 'wpto_after_advance_search_box', 'wpt_pro_cf_filter_show' );

/**
 * Track product views.
 */
function wpt_track_product_view() {
	if ( ! is_singular( 'product' ) || is_active_widget( false, false, 'woocommerce_recently_viewed_products', true ) ) {
		return;
	}

	global $post;

	if ( empty( $_COOKIE['woocommerce_recently_viewed'] ) ) { // @codingStandardsIgnoreLine.
		$viewed_products = array();
	} else {
		$viewed_products = wp_parse_id_list( (array) explode( '|', wp_unslash( $_COOKIE['woocommerce_recently_viewed'] ) ) ); // @codingStandardsIgnoreLine.
	}

	// Unset if already in viewed products list.
	$keys = array_flip( $viewed_products );

	if ( isset( $keys[ $post->ID ] ) ) {
		unset( $viewed_products[ $keys[ $post->ID ] ] );
	}

	$viewed_products[] = $post->ID;

	if ( count( $viewed_products ) > 15 ) {
		array_shift( $viewed_products );
	}

	// Store for session only.
	wc_setcookie( 'woocommerce_recently_viewed', implode( '|', $viewed_products ) );
}

add_action( 'template_redirect', 'wpt_track_product_view', 20 );
