<?php
$viewed_products = ! empty( $_COOKIE['woocommerce_recently_viewed'] ) ? (array) explode( '|', wp_unslash( $_COOKIE['woocommerce_recently_viewed'] ) ) : array(); // @codingStandardsIgnoreLine
$viewed_products = array_reverse( array_filter( array_map( 'absint', $viewed_products ) ) );

$view_message = apply_filters( 'wpto_viewed_product_message', __( "Viewed", 'wpt_pro' ), $settings, $column_settings, $keyword, $product, $table_ID );
if( in_array( $id, $viewed_products ) ){
    echo esc_html( $view_message );
}