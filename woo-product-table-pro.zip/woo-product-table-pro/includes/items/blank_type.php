<?php
/**
 * Blank Column
 * Default Blank Column
 * Only One Blank Column Available To our Woo Product Table
 * For more, User able to add Blank Type - by Add new Colum and Column Type -Blank Type
 * Here: Keyword is: $keyword => blank
 */
do_action( 'wpto_blank_centent', $table_ID, $product, $type );
//Nothing for Display