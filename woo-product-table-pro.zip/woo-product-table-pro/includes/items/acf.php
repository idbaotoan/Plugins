<?php
/**
 * Here: $id = $product_id - is Product's ID
 * 
 */

$settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
$label_text = isset( $settings['label_text'] ) ? $settings['label_text'] : false;
$target = apply_filters( 'wpto_acf_link_target', '_blank', $settings, $column_settings, $keyword, $product, $table_ID );

if( !function_exists( 'get_field_object' ) ){
    return;
}
 $variation_wise_id = apply_filters( 'wpto_product_real_id', false, $product, $temp_number, $keyword, $column_settings );
 if( $product->get_type() == 'variation' && !$variation_wise_id ){
     $id = $product->get_parent_id();
 }

$acf_obj = get_field_object($keyword, $id);

if( !$acf_obj ){
    return;
}

$get_field = get_field($keyword, $id);
$type = isset( $acf_obj['type'] ) ? $acf_obj['type'] : false;
if( !$type ){
    return;
}
//var_dump($acf_obj);
//var_dump($get_field); 



switch ($type){
    case 'file':
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        if( $value && isset( $value['url'] ) && !empty( $value['url'] )){
        $url =  $value['url'];   
        $label = $label_text ? $label_text :  $acf_obj['label'];
        $label = apply_filters( 'wpto_extra_label_text', $label, $id, $keyword, $acf_obj, $settings );
        ?>
<a class="wpt_acf wpt_type_file" target="<?php echo esc_attr( $target ); ?>" href="<?php echo esc_url( $url ) ?>"><?php echo esc_html( $label ); ?></a>
        <?php
        }
        break;
    
    case 'url':
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        if( !empty( $value ) ){
        $label = $label_text ? $label_text :  $acf_obj['label'];
        $label = apply_filters( 'wpto_extra_label_text', $label, $id, $keyword, $acf_obj, $settings );
        ?>
<a class="wpt_acf wpt_type_url" target="_blank" href="<?php echo esc_url( $value ) ?>"><?php echo esc_html( $label ); ?></a>
        <?php
        }
        break;
    
    case 'email':
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        if( !empty( $value ) ){
        $label = $label_text ? $label_text :  $value;
        ?>
<a class="wpt_acf wpt_type_email"  target="<?php echo esc_attr( $target ); ?>" href="mailto:<?php echo esc_attr( $value ) ?>"><?php echo esc_html( $label ); ?></a>
        <?php
        }
        break;
    
    case 'select':
    case 'radio':
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        echo isset( $acf_obj['choices'][$value] ) ? $acf_obj['choices'][$value] : false;
        break;
    
    case 'image':
        $target_url = false;
        $img_target_url_keyword = apply_filters( 'wpto_image_url_keyword','image_url', $settings, $column_settings, $keyword, $product, $table_ID );
        $target_url_acf_obj = get_field_object( $img_target_url_keyword, $id);
        if($target_url_acf_obj){
            $url = isset( $target_url_acf_obj['value'] ) ? $target_url_acf_obj['value'] : false;
            $target_url = !empty( $url ) && is_string( $url ) ? $url : false;
        }
        $target_url = apply_filters( 'wpto_image_target_url', $target_url, $product, $settings, $column_settings, $keyword, $table_ID);
        if( $target_url ){
        ?>
        <a href="<?php echo esc_attr( $target_url ); ?>"  target="<?php echo esc_attr( $target ); ?>">     
        <?php
        }
        
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        if( $value && isset( $value['url'] ) && !empty( $value['url'] ) ){
        $url =  $value['url'];   
        ?>
        <img class="wpt_acf wpt_type_file" src="<?php echo esc_url( $url ) ?>">
        
        <?php
        }
        
        if( $target_url ){
        ?>
        <a href="<?php echo esc_attr( $target_url ); ?>"  target="<?php echo esc_attr( $target ); ?>">     
        <?php
        }
        
        break;
        
    /**
     * Helped taken from Bari
     * 
     * @since 7.0.5.1
     */
    case 'checkbox':
        
        $values = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;

        if( is_array( $values ) ){
            echo esc_html( implode( ', ', $values ) );
        }
        break;
    
    default:
        echo is_string( $get_field ) ? $get_field : false;
}
