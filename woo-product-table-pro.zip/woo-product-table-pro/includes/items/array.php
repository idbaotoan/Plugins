<?php

$settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
$array = isset( $settings['array'] ) ? $settings['array'] : false;
       
if(!$array){
    echo esc_html__( "Empty customfield and Array key.", 'wpt_pro' );
    return;
}



$array = str_replace( ' ', '', $array );
do_action( 'wpto_array_column', $array, $product, $table_ID, $type, $column_settings, $keyword );

$arrays = explode( ',',$array );

$count = is_array( $arrays ) ? count( $arrays ) : 0;


if( $count > 1 ){
   $cf_key = $arrays[0];//is_string() ? $arrays[0] : false;
   $cf = is_string( $cf_key ) ? get_post_meta( $id, $cf_key,true) : false;
   $cf = apply_filters( 'wpto_array_column_array', $cf, $cf_key,$arrays, $table_ID, $id, $column_settings, $keyword, $product );
   if( ! is_array( $cf ) ) return;
   $output = false;
    switch ($count){
        case 2:
            $first_key = $arrays[1];
            $output = isset( $cf[$first_key] ) ? $cf[$first_key] : false;
            break;
        case 3:
            $first_key = $arrays[1];
            $second_key = $arrays[2];
            $output = isset( $cf[$first_key][$second_key] ) ? $cf[$first_key][$second_key] : false;
            break;
        case 4:
            $first_key = $arrays[1];
            $second_key = $arrays[2];
            $third_key = $arrays[3];
            $output = isset( $cf[$first_key][$second_key][$third_key] ) ? $cf[$first_key][$second_key][$third_key] : false;
            break;
    }
    $output = is_string( $output ) ? $output : '';
    $final_output = $final_output = apply_filters( 'wpto_array_column_output', $output, $cf_key, $arrays, $table_ID, $id, $column_settings, $keyword, $product );
    
    echo $final_output;

   
}elseif($count == 1){
    $cf_key = $arrays[0];//is_string() ? $arrays[0] : false;
    $cf = is_string( $cf_key ) ? get_post_meta( $id, $cf_key,true) : false;
    echo "<pre>";
    print_r( $cf );
    echo "</pre>";
    echo esc_html__( "Emample: {$cf_key},1st_array_key,2nd_array_key", 'wpt_pro' );
}else{
    echo esc_html__( "Error: eg: cf,1st_array_key,2nd_array_key", 'wpt_pro' );
    return;
}
//_enable_course