<?php

$settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
$hook = isset( $settings['hook'] ) ? $settings['hook'] : false;

if(!$hook){
    return;
}
$hook = str_replace( ' ', '', $hook );
do_action( 'wpto_hook_action', $hook, $product, $table_ID, $type, $column_settings, $keyword );

$hooks = explode( ',',$hook );

$hook_show = apply_filters( 'wpto_hook_action_show', true, $hooks, $product, $table_ID, $column_settings, $keyword );

if( is_array( $hooks ) &&  count( $hooks ) > 1 ){
   foreach( $hooks as $hook ){
       /**
        * To show or hide based on WC Default Hook, we can use following Filter Hook
        */
       
       if( $hook_show ){
           do_action( $hook );
       }
   }
}else{
    $hook_show = apply_filters( 'wpto_hook_action_show', true, $hook, $product, $table_ID, $column_settings, $keyword );
    if( $hook_show ){
           do_action( $hook );
    }
}




