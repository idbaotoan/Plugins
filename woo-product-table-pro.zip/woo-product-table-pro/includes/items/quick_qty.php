<?php 
$default_value = 0;
$max_value = -1;
$stock = $product->get_stock_quantity();

if( ! empty( $stock ) ){
   $max_value = $stock; 
}

if( $product->is_sold_individually() ){
    $max_value = 1;
}


$max_value = apply_filters( 'woocommerce_quantity_input_max', $max_value, $product );


echo woocommerce_quantity_input( 
        array( 
            'input_value'   => apply_filters( 'woocommerce_quantity_input_min', 1, $product ),
            'classes'      => apply_filters( 'woocommerce_quantity_input_classes', array( 'quantity_cart_plus_minus','input-text', 'qty', 'text' ), $product ),
            'max_value'   => $max_value,
            'min_value'   => apply_filters( 'woocommerce_quantity_input_min', 0, $product ),
            'step'        => apply_filters( 'woocommerce_quantity_input_step', 1, $product ),
        ) , $product, false );