<?php
/**
* audio css 
* Here added min version. But also available regular version in same directory
* 
* @since 1.9
*/
wp_enqueue_style( 'custom-css', WPTP_BASE_URL . 'assets/css/audio.css', array( ) );
//wp_enqueue_style( 'wpt-custom-audio-css', WPT_Product_Table::getPath('BASE_URL') . 'assets/css/audio.css', array(), WPT_Product_Table::getVersion(), 'all' );
/**
* audio jQuery Plugin file including. 
* Here added min version. But also available regular version in same directory
* 
* @since 1.9
*/
wp_enqueue_script( 'player-js', WPTP_BASE_URL . 'assets/js/musicplayer.js', array( 'jquery'), '4.0.5', true );
wp_enqueue_script( 'audio-js', WPTP_BASE_URL . 'assets/js/audio.js', array( 'jquery'), '4.0.5', true );

$WPT_DATA = array( 
           'player_position' => isset( $column_settings['audio_player']['player_position'] ) ? $column_settings['audio_player']['player_position'] : false,
           'bg_color' => isset( $column_settings['audio_player']['bg_color'] ) ? $column_settings['audio_player']['bg_color'] : false,
           'progressbar_color' => isset( $column_settings['audio_player']['progressbar_color'] ) ? $column_settings['audio_player']['progressbar_color'] : false,
           );
       $WPT_DATA = apply_filters( 'wpto_audio_localize_data', $WPT_DATA );
       wp_localize_script( 'audio-js', 'WPT_AUDIO_DATA', $WPT_DATA );