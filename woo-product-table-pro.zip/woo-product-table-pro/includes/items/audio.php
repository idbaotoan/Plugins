<?php
//var_dump($keyword);
$settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
$label_text = isset( $settings['label_text'] ) ? $settings['label_text'] : false;

if( !function_exists( 'get_field_object' ) ){
    return;
}
$acf_obj = get_field_object($keyword, $id);

if(!$acf_obj){
    return;
}

       
wp_enqueue_style( 'wptp-progres-bar', WOO_Product_Table::getPath('BASE_URL') . 'assets/css/progres-bar.css', array(), WOO_Product_Table::getVersion(), 'all' );

///custom JavaScript for Woo Product Table pro plugin
wp_enqueue_script( 'wptp-jquery-old', 'https://code.jquery.com/jquery-1.11.2.min.js', array(), '', true );
wp_enqueue_script( 'wptp-media-players', WOO_Product_Table::getPath('BASE_URL') . 'assets/js/audio/player.js', array( 'jquery' ), WOO_Product_Table::getVersion(), true );
wp_enqueue_script( 'wptp-handle-media-player', WOO_Product_Table::getPath('BASE_URL') . 'assets/js/audio/handle-media-player.js', array( 'jquery' ), WOO_Product_Table::getVersion(), true );

$get_field = get_field($keyword, $id);
$type = isset( $acf_obj['type'] ) ? $acf_obj['type'] : false;
if( !$type ){
    return;
}
//var_dump($acf_obj);
//var_dump($get_field);



switch ($type){
    case 'file':
        $value = isset( $acf_obj['value'] ) ? $acf_obj['value'] : false;
        if( $value && isset( $value['url'] ) && !empty( $value['url'] )){
        $url =  $value['url'];   
        $label = $label_text ? $label_text :  $acf_obj['label'];
        ?>

<div class="mediPlayer">
    <audio class="listen" preload="none" data-size="80" src="<?php echo esc_url( $url ) ?>"></audio>
</div>
        <?php
        }
        break;
    default:
        echo '<span class="acf_audio_error_file_type">' . esc_html( 'Only File type field supported.' ) . '</span>';
}
?>
