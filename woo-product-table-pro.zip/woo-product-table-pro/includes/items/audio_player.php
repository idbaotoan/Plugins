<?php
//var_dump($column_settings['audio_player']['style']);

// 
include_once 'audio_player_script.php';

//audio custom
$p_id = get_the_ID();
$attachment_id = get_post_meta( $p_id,'audio_file',true);
$artist = get_post_meta( $p_id,'audio_artist',true);
$artist = !empty( $artist ) ? $artist : '';

$title = get_post_meta( $p_id,'audio_title',true);
$title = !empty( $title ) ? $title : get_the_title();

$url = wp_get_attachment_url($attachment_id);
$url = $url ? $url : false;

$img_src = wp_get_attachment_image_src( get_post_thumbnail_id( $p_id ), 'thumbnail', false ); 

$thumbs = !empty( $img_src['0'] ) ? $img_src['0'] : false;

$audio_sorce = array(
    'thumbs'    => $thumbs,
    'artist'    => $artist,
    'url'       => $url,
    'title'     =>  $title,
    'icon' => '&#9658;', //Any entities code, or some html code
);

/**
 * Filter Hook
 * to change Audio Information 
 * Based on Product, settings, arg etc
 * 
 * @since 7.0.5
 * @date 27.12.2020
 * @info: Based on a client request, we added this feature as pro. Bari amake boleche, tai eta add korechi.
 */
$audio_sorce = apply_filters( 'wpto_audio_file_ars', $audio_sorce, $product, $settings, $args, $table_ID, $column_settings );

$g_url      = ! empty( $audio_sorce['url'] ) ? $audio_sorce['url'] : false;
$g_thumbs   = ! empty( $audio_sorce['thumbs'] ) ? $audio_sorce['thumbs'] : false;
$g_artist   = ! empty( $audio_sorce['artist'] ) ? $audio_sorce['artist'] : false;
$g_title    = ! empty( $audio_sorce['title'] ) ? $audio_sorce['title'] : false;
$g_icon    = ! empty( $audio_sorce['icon'] ) ? $audio_sorce['icon'] : false;

if( $g_url ){
    ?>
    <li data-cover="<?php echo esc_attr( $g_thumbs ); ?>" data-artist="<?php echo esc_attr( $g_artist ); ?>">
        <a href="<?php echo esc_attr( $g_url ); ?>"><span class="play_icon"><?php echo wp_kses_post( $g_icon ); ?></span> <span class="music_title"><?php echo esc_html( $g_title ); ?></span></a>
    </li>
    <?php
    
}