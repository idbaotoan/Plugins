<?php

if( !function_exists( 'wpt_pro_enqueue' ) ){
    /**
     * CSS or Style file add for FrontEnd Section. 
     * 
     * @since 1.0.0
     */
   function wpt_pro_enqueue(){
       wp_enqueue_style( 'wpt-universal-pro', WOO_Product_Table::getPath('BASE_URL') . 'assets/css/universal-pro.css', array(), WOO_Product_Table::getVersion(), 'all' );

       ///custom JavaScript for Woo Product Table pro plugin
       wp_enqueue_script( 'wpt-custom-pro-js', WOO_Product_Table::getPath('BASE_URL') . 'assets/js/custom-pro.js', array( 'wpt-custom-js' ), WOO_Product_Table::getVersion(), true );
   }
}
add_action( 'wp_enqueue_scripts', 'wpt_pro_enqueue', 99 );
