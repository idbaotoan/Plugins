<?php

/**************
 * FRONTEND *********FRONTEND ACTION HOOK****************FRONTEND
 * ACTION HOOK CONTROL
 * TO CONTROLL SOMETHING FROM MAIN MODULE
 */

$WPT_Module =  WP_PLUGIN_DIR . WPTP_PLUGIN;// Our Main Plugin'woo-product-table/woo-product-table.php';
if( file_exists( $WPT_Module ) ){
   include_once $WPT_Module;
}


//do_action( 'wpto_item_top', $keyword, $table_ID, $settings, $column_settings, $parent_column_settings, $product );
if( !function_exists( 'wpt_pro_add_label_item' ) ){
    
    /**
     * Add Label Text Before Each Item
     * 
     * @param type $keyword
     * @param type $table_ID
     * @param type $settings
     * @param type $column_settings
     * @param type $parent_column_settings
     */
    function wpt_pro_add_label_item( $keyword, $table_ID, $settings, $column_settings, $parent_column_settings ){
        $label_stat = isset( $parent_column_settings['inside_label'] ) ? true : false;
        $label_stat = apply_filters( 'wpto_item_label_show', $label_stat, $keyword, $table_ID );
        
        if( !$label_stat ){
            return;
        }
        $column_array = get_post_meta( $table_ID, 'column_array', true );
        $label = isset( $column_array[$keyword] ) ? $column_array[$keyword] : $keyword;
        $label = apply_filters( 'wpto_item_label_text', $label, $keyword, $table_ID );
        
        $label_class = esc_attr( 'wpt-item-label wpt-item-label ' . $keyword );
        
        echo wp_kses_post( "<span class='{$label_class}'>{$label}</span><span class>:</span> " );
    }
}
add_action( 'wpto_item_top', 'wpt_pro_add_label_item', 10, 5 );
