<?php

/**************
 * ADMIN *********ADMIN ACTION HOOK****************ADMIN
 * ACTION HOOK CONTROL
 * TO CONTROL SOMETHING FROM MAIN MODULE 
 */

$WPT_Module =  WP_PLUGIN_DIR . WPTP_PLUGIN;// Our Main Plugin'woo-product-table/woo-product-table.php';
if( file_exists( $WPT_Module ) ){
   include_once $WPT_Module;
}

remove_action( 'wpo_pro_feature_message', 'wpt_profeatures_message_box' );

if( !function_exists( 'wpt_pro_admin_form_top' ) ){
    /**
     * Docs and Support Link to Our Form Top
     */
    function wpt_pro_admin_form_top(){
        global $post;
        /**
         * @Hook Filter: wpt_admin_form_top_links
         * To Disable Top Links of Get pro, Documentation at the top of our Forms
         * @return Boolean True to displa link, false to hide links from the top of our Admin Post Edit form
         */
        $validation = apply_filters( 'wpt_admin_form_top_links', true, $post );
        if( $validation ){
        ?>
        <ul class="wpt_admin_form_links" style="margin: 0">
            <li><a class="wpt_get_pro_form_top_link" target="_blank" href="https://wooproducttable.com/documentation/">Basic Helps</a></li>
            <li>
                <a class="Header-link " href="https://github.com/codersaiful/woo-product-table" target="_blank">
  <svg class="octicon octicon-mark-github v-align-middle" height="16" 
       viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true">
  <path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z"></path>
  </svg>

                 GitHub Repo</a></li>  
            <li><a target="_blank" href="https://demo.wooproducttable.com/">Demo</a></li>
            <li><a target="_blank" href="https://github.com/codersaiful/woo-product-table/discussions">Forum on Repo</a></li>
            <li><a target="_blank" href="https://docs.codeastrology.com/woo-product-table-pro/#intro">Documentation</a></li>
            <li><a target="_blank" href="https://codeastrology.com/support/">Get Support</a></li> 
            

        </ul>    
        <?php
        }
    }
}
add_action( 'wpto_form_top', 'wpt_pro_admin_form_top' );
remove_action( 'wpto_form_top','wpt_admin_form_top' );


if( !function_exists( 'wpt_pro_configuration_page_extra' ) ){
    function wpt_pro_configuration_page_extra( $settings,$current_config_value ){
        if( !isset( $settings['page'] ) || isset( $settings['page'] ) && $settings['page'] != 'configuration_page' ){
            return;
        }
        ?>
        <div class="section ultraaddons-panel top_secion configuration_page">
        <table class="ultraaddons-table">
            <tr>
                <th>
                    <label class="wpt_label wpt_advance_search_on_of" for="wpt_table_head_enable"><?php esc_html_e( 'Advance Search', 'wpt_pro' );?></label>
                </th>
                <td>
                    <label class="switch">
                        <input  name="data[advance_search]" type="checkbox" id="wpt_advance_search_on_of" <?php echo isset( $current_config_value['advance_search'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">On</span><span class="off">Off</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html( 'To search By any Title, Custom Field, Taxonomy. Use this feature. If you want to search by any specific item, such: sku, id, cf, Go to [Search and Filter] tab: Edit Product Table -> Edit ->', 'wpt_pro' ); ?></p>
                                    
                </td>
            </tr>
            
            <tr>
                <th>
                    <label class="wpt_label wpt_advance_search_on_of" for="wpt_table_on_archive"><?php esc_html_e( 'Table on Archives', 'wpt_pro' );?></label>
                </th>
                <td>
                    <?php 
                    global $post;
                    $product_tables = get_posts( array(
                        'post_type' => 'wpt_product_table',
                        'numberposts' => -1,
                        ) );
                        if(!empty($product_tables)){
                    ?>
                    <select name="data[archive_table_id]" class="wpt_fullwidth ua_input wpt_table_on_archive">
                        <option value="">Select a Table</option>
                    <?php 
                    
                    foreach ($product_tables as $table){
                        $selected = isset( $current_config_value['archive_table_id'] ) && $current_config_value['archive_table_id'] == $table->ID ? 'selected' : '';
                        echo '<option value="'. $table->ID .'" ' . $selected . '>' . $table->post_title . '</option>'; 
                    }
                    ?>
                    </select>
                    <?php
                    } else { 
                        echo esc_html( 'Seems you have not created any table yet. Create a table first!', 'wpt_pro' );
                    } ?>
                    <br>
                    <label class="switch">
                        <input  name="data[table_on_archive]" type="checkbox" id="wpt_table_on_archive" <?php echo isset( $current_config_value['table_on_archive'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">On</span><span class="off">Off</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html__( 'Enable Table on Archive Page. Such as: Archive Page, Tag Page, Taxonomy Page. First Select a table and check [On] to show in shop/archive page.', 'wpt_pro' ); ?></p>
                    <p class="wpt-tips">
                        <b><?php echo esc_html__( 'Tips:', 'wpt_pro' ); ?></b>
                        <span><?php echo esc_html__( 'Advance Search box is not availeable on WooCommerce Archive page. Such: shop page, product category page.','wpt_pro' ); ?></span>
                    </p>
                </td>
            </tr>

            <tr>
                <th>
                    <label class="wpt_label wpt_variation_table_on_off" for="wpt_table__for_variation"><?php esc_html_e( 'Variation Table', 'wpt_pro' );?></label>
                </th>
                <td>
                    <?php 
                    global $post;
                    $product_tables = get_posts( array(
                        'post_type' => 'wpt_product_table',
                        'numberposts' => -1,
                        ) );
                        if( !empty($product_tables )){
                    ?>
                    <select name="data[variation_table_id]" class="wpt_fullwidth ua_input wpt_table__for_variation">
                        <option value="">Select a Table</option>
                    <?php 
                    
                    foreach ($product_tables as $table){
                        $selected = isset( $current_config_value['variation_table_id'] ) && $current_config_value['variation_table_id'] == $table->ID ? 'selected' : '';
                        echo '<option value="'. $table->ID .'" ' . $selected . '>' . $table->post_title . '</option>'; 
                    }
                    ?>
                    </select>
                    <?php
                    } else { 
                        echo esc_html( 'Seems you have not created any table yet. Create a table first!', 'wpt_pro' );
                    } ?>
                    <br>
                    <label class="switch">
                        <input  name="data[table_for_variable_product]" type="checkbox" id="wpt_table__for_variation" <?php echo isset( $current_config_value['table_for_variable_product'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">On</span><span class="off">Off</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html__( 'Select a table and enable above the button to show a variation table on every variable product page which will replace the default variation dropdown select options.', 'wpt_pro' ); ?></p>
                </td>
            </tr>

            <tr>
                <th>
                    <label class="wpt_label wpt_advance_search_on_of" for="wpt_table_head_enable"><?php esc_html_e( 'Advance Search PROBLEM FIX', 'wpt_pro' );?></label>
                </th>
                <td>
                    <label class="switch">
                        <input  name="data[advance_search_issue]" type="checkbox" id="wpt_advance_search_on_of" <?php echo isset( $current_config_value['advance_search_issue'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">On</span><span class="off">Off</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html( 'Only if found issue on Advance Search, Check it', 'wpt_pro' ); ?></p>
                                    
                </td>
            </tr>
            <tr>
                <th>
                    <label class="wpt_label wpt_column_sorting_on_off" for="wpt_column_sorting_on_off"><?php esc_html_e( 'Table Column Sorting', 'wpt_pro' );?></label>
                </th>
                <td>
                    <label class="switch">
                        <input  name="data[column_sort]" type="checkbox" id="wpt_column_sorting_on_off" <?php echo isset( $current_config_value['column_sort'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">On</span><span class="off">Off</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html( 'Column sorting for Table Column', 'wpt_pro' ); ?></p>
                                    
                </td>
            </tr>
            <tr>
                <th>
                    <label class="wpt_label wpt_column_hide_for_guest" for="wpt_column_hide_for_guest"><?php esc_html_e( 'Show/Hide Column for Guest', 'wpt_pro' );?></label>
                </th>
                <td>
                    <label class="switch">
                        <input  name="data[column_hide_for_guest]" type="checkbox" id="wpt_column_hide_for_guest" <?php echo isset( $current_config_value['column_hide_for_guest'] ) ? 'checked="checked"' : ''; ?>>
                        <div class="slider round"><!--ADDED HTML -->
                            <span class="on">Show</span><span class="off">Hide</span><!--END-->
                        </div>
                    </label>
                    <p><?php echo esc_html( 'Show or hide the restricted column for guest user.', 'wpt_pro' ); ?></p>
                                    
                </td>
            </tr>
        </table>
        <div class="ultraaddons-button-wrapper">
            <button name="configure_submit" class="button-primary primary button">Save All</button>
        </div>
    </div>
            
         <?php
    }
}
add_action( 'wpto_admin_configuration_form_top', 'wpt_pro_configuration_page_extra',50,2 );


if( !function_exists( 'wpt_pro_configuration_page_head' ) ){
    function wpt_pro_configuration_page_head(){
        ?>
        <div class="fieldwrap ultraaddons-head">
            <div class="ultraaddons-panel">
                <h1 class="wp-heading-inline plugin_name plugin-name"><?php echo WOO_Product_Table::getName(); ?> <span class="plugin-version">v <?php echo WOO_Product_Table::getVersion(); ?></span></h1>
                
            </div>
        </div>    
            
         <?php
    }
}
add_action( 'wpto_admin_configuration_head', 'wpt_pro_configuration_page_head',50 );
remove_action( 'wpto_admin_configuration_head', 'wpt_configuration_page_head',10 );


if( !function_exists( 'wpt_pro_configuration_page_version_data' ) ){
    
    /**
     * To add Version Data, I mean: Version Numbewr and Plugin name as Hidden Input
     * At the top of Configuration Page and Configuration Tab
     * 
     * @since 2.7 and 7.0.0
     */
    function wpt_pro_configuration_page_version_data(){
        ?>
        <input name="data[plugin_version]" type="hidden" value="<?php echo WOO_Product_Table::getVersion(); ?>">
        <input name="data[plugin_name]" type="hidden" value="<?php echo WOO_Product_Table::getName(); ?>"> 
            
         <?php
    }
}
add_action( 'wpto_admin_configuration_form_version_data', 'wpt_pro_configuration_page_version_data' );
remove_action( 'wpto_admin_configuration_form_version_data', 'wpt_configuration_page_version_data' );

if( !function_exists( 'wpt_pro_add_label_acf_column' ) ){
    
    /**
     * Add a new Field for Type Column: Advance Custom Field
     * Normally some time need an Extra text, I mean: Label text
     * Specially for Button
     * Such Download Button
     * Need Taxt for Download Button
     * 
     * @param type $keyword
     * @param type $column_settings
     * return Void
     */
    function wpt_pro_add_label_acf_column( $keyword, $_device_name, $column_settings){
        $this_settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
        if( $this_settings && isset( $this_settings['type'] ) && $this_settings['type'] == 'acf' ){
        $label_text = isset( $column_settings[$keyword]['label_text'] ) ? $column_settings[$keyword]['label_text'] : false;
       ?>
        <label><?php echo esc_html__( 'Extra Label Text (Optionals)', 'wpt_pro' ); ?></label>
        <input class="ua_input" type="text" name="column_settings<?php echo $_device_name; ?>[<?php echo esc_attr( $keyword ); ?>][label_text]" value='<?php echo esc_attr( $label_text ); ?>'>
        <p>Suppose: You have added file type, then need Download button. For this button text, you can use <b>Extra Label Text</b></p>
        
        <label><?php echo esc_html__( 'Target URL Instruction', 'wpt_pro' ); ?></label>
        <p>If it's a ACF Image column, you can set url for this image. Just need custom field named <code>image_url</code>.</p>
       <?php
        }
    }
}
add_action( 'wpto_column_setting_form', 'wpt_pro_add_label_acf_column', 10, 3 );



add_action( 'wpto_column_setting_form', 'wpt_all_type_content_column_add', 10, 3 );

if( !function_exists( 'wpt_all_type_content_column_add' ) ){
    
    
   function wpt_all_type_content_column_add( $keyword, $_device_name, $column_settings ){
        $this_settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;

        if( $this_settings && isset( $this_settings['type'] ) && $this_settings['type'] == 'all_content' ){
            $my_values = isset( $column_settings[$keyword]['content'] ) ? $column_settings[$keyword]['content'] : false;

            $settings = array(
                'textarea_name'     =>'column_settings' . $_device_name . '[' . $keyword . '][content]',
                'textarea_rows'     => 3,
                'teeny'             => true,
                'autocomplete'             => 'on',
                'tinymce' => false,
                );
            wp_editor( wp_kses_post( $my_values ), 'wpt_' . $keyword . '_column' . $_device_name, $settings ); 
            
            $label_text = isset( $column_settings[$keyword]['label_text'] ) ? $column_settings[$keyword]['label_text'] : false;
            
            ?>
        
            <div class="wpt-column-info">
                <b>Supported Dynamic Value</b>
                <ul>
                    <li><code>%product_id%</code>: Product ID</li>
                    <li><code>%sku%</code>: Product SKU</li>
                    <li><code>%name%</code>: Product Title</li>
                    <li><code>%excerpt%</code>: Short Description</li>
                    <li>... <a href="https://wooproducttable.com/supported-attributes-of-shortcode-and-content-column/" target="_blank"><?php echo esc_html__( 'Full list of Dynamic Shortcode', 'wpt_pro' ); ?></a></li>
                </ul>
                <p class="hints"> <?php echo esc_html__( 'Example of Content Box with Supported Shortcode', 'wpt_pro' ); ?> <a href="https://wooproducttable.com/supported-attributes-of-shortcode-and-content-column/" target="_blank"><?php echo esc_html__( 'Click Here', 'wpt_pro' ); ?></a></p>
            </div>    
            <?php
            
            
            
            
        }

        
    }

}


if( !function_exists( 'wpt_pro_hook_content_column' ) ){
    
    /**
     * Add a new Field for Type Column: Action Hook
     * by an input box, we will take Action Hook
     * 
     * New Added new field for Array type column
     * 
     * @param String $keyword
     * @param type $column_settings
     * return Void
     */
    function wpt_pro_hook_content_column( $keyword, $_device_name, $column_settings){
        $this_settings = isset( $column_settings[$keyword] ) ? $column_settings[$keyword] : false;
        if( $this_settings && isset( $this_settings['type'] ) && $this_settings['type'] == 'hook_action' ){
            $hook = isset( $column_settings[$keyword]['hook'] ) ? $column_settings[$keyword]['hook'] : false;
           ?>
            <label><?php echo esc_html__( 'WC Action Hook', 'wpt_pro' ); ?></label>
            <input class="ua_input" type="text" name="column_settings<?php echo $_device_name; ?>[<?php echo esc_attr( $keyword ); ?>][hook]" value='<?php echo esc_attr( $hook ); ?>'>
            <p>Suppose: You you want to show a possition of Action Hook, provided by WooCommerce, you can input here.</p>
           <?php
        }
        
        if( $this_settings && isset( $this_settings['type'] ) && $this_settings['type'] == 'array' ){
            $array = isset( $column_settings[$keyword]['array'] ) ? $column_settings[$keyword]['array'] : false;
           ?>
            <label><?php echo esc_html__( 'Custom field key and Array Key', 'wpt_pro' ); ?></label>
            <input class="ua_input" type="text" name="column_settings<?php echo $_device_name; ?>[<?php echo esc_attr( $keyword ); ?>][array]" value='<?php echo esc_attr( $array ); ?>'>
            <p>Enter Custom field key and array key with comma. Suppose: custom field key is: '_ready_course_info' and it's a array. an array index is 'location'. Then enter <pre>_ready_course_info,location</pre></p>
           <?php
        }
        
    }
}
add_action( 'wpto_column_setting_form', 'wpt_pro_hook_content_column', 10, 3 );

if( !function_exists( 'wpto_pro_product_incld_excld_basic_tab' ) ){
    
    /**
     * Displaying Products list by Select2 and 
     * for Product Includes, 
     * 
     * @global type $product
     * @global type $product
     * @param type $meta_basics
     */
    function wpto_pro_product_incld_excld_basic_tab( $meta_basics ){
   $args = isset( $meta_basics['post_include'] ) ? $meta_basics['post_include'] : false;
   $post_include = wpt_product_includes_select_option($args);

   $args= isset( $meta_basics['post_exclude'] ) ? $meta_basics['post_exclude'] : false;
   $post_exclude = wpt_product_includes_select_option($args);
       ?>

    
    <div class="wpt_column">
        <table class="ultraaddons-table">
            <tr id="wpt_row_product_id_includes">
                <th>
                    <label class="wpt_label"><?php esc_html_e( 'Product Includes', 'wpt_pro' );?></label>
                </th>
                <td>
                    <select class="ua_select product_includes_excludes" id="product_id_includes" name="basics[post_include][]" data-name="post_include" multiple="multiple">
                        <?php echo $post_include; ?>
                    </select>
                    <p class="notice-for-variations"><?php echo esc_html__( 'Please select only variable products', 'wpt_pro') ?></p>
                    <p><?php echo esc_html__( 'Choose your selected product to make a table with selected product from your while store. To select multiple products at a time, Please press [CTRL + S]', 'wpt_pro') ?></p>
                </td>
            </tr>
            <tr id="wpt_row_product_id_cludes">
                <th>
                    <label class="wpt_label"><?php esc_html_e( 'Product Exclude', 'wpt_pro' );?></label>
                </th>
                <td>
                    <select class="ua_select product_includes_excludes" id="product_id_cludes" name="basics[post_exclude][]" data-name="post_exclude" multiple="multiple">
                        <?php echo $post_exclude; ?>
                    </select>
                </td>
            </tr>
        </table>
    </div>
       <?php

    }
}
add_action( 'wpto_admin_basic_tab', 'wpto_pro_product_incld_excld_basic_tab', 10 );

if( !function_exists( 'wpto_pf_bulk_add_to_cart' ) ){
    
    /**
     * Displaying bulk add to cart feature 
     * 
     * @global type $product
     * @global type $product
     * @param type $meta_basics
     */
    function wpto_pf_bulk_add_to_cart( $meta_basics ){
       ?>

    
        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label wpt_table_ajax_action" for='wpt_table_checkbox'><?php esc_html_e('Checkbox Auto Check on Table Load (Enable/Disable)','wpt_pro');?></label>
                    </th>
                    <td>
                        <select name="basics[checkbox]" data-name='checkbox' id="wpt_table_checkbox" class="wpt_fullwidth wpt_data_filed_atts ua_input" >
                            <option value="wpt_no_checked_table" <?php echo isset( $meta_basics['checkbox'] ) && $meta_basics['checkbox'] == 'wpt_no_checked_table' ? 'selected' : false; ?>><?php esc_html_e('No Auto','wpt_pro');?></option>
                            <option value="wpt_checked_table" <?php echo isset( $meta_basics['checkbox'] ) && $meta_basics['checkbox'] == 'wpt_checked_table' ? 'selected' : false; ?>><?php esc_html_e('Automatically All Check','wpt_pro');?></option>
                        </select>                  
                    </td>
                </tr>
            </table>
        </div>

        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label" for="wpt_table_add_to_cart_selected_text"><?php esc_html_e( '(Add to cart(Selected]) Text', 'wpt_pro' );?></label>
                    </th>
                    <td>
                        <input name="basics[add_to_cart_selected_text]"  class="wpt_data_filed_atts ua_input" data-name="add_to_cart_selected_text" type="text" value="<?php echo isset( $meta_basics['add_to_cart_selected_text'] ) ? $meta_basics['add_to_cart_selected_text'] : __( 'Add to Cart (Selected)', 'wpt_pro' ); ?>" placeholder="<?php esc_attr_e( 'Example: Add to cart Selected', 'wpt_pro' ); ?>" id="wpt_table_add_to_cart_selected_text">
                    </td>
                </tr>
            </table>
        </div>

        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label" for="wpt_table_check_uncheck_text"><?php esc_html_e( '(All Check/Uncheck) Text', 'wpt_pro' );?></label>
                    </th>
                    <td>
                        <input name="basics[check_uncheck_text]"  class="wpt_data_filed_atts ua_input" data-name="check_uncheck_text" type="text" value="<?php echo isset( $meta_basics['check_uncheck_text'] ) ? $meta_basics['check_uncheck_text'] : __( 'All Check/Uncheck','wpt_pro' ); ?>" placeholder="<?php esc_attr_e( 'Example: All Check/Uncheck', 'wpt_pro' );?>" id="wpt_table_check_uncheck_text">
                    </td>
                </tr>
            </table>
        </div>
       <?php

    }
}
add_action( 'wpto_admin_basic_tab_bottom', 'wpto_pf_bulk_add_to_cart', 10 );


if( !function_exists( 'wpto_pf_authorid_username_type' ) ){
    
    /**
     * Display product by
     * author id, username, product type 
     * 
     * @global type $product
     * @global type $product
     * @param type $meta_basics
     */
    function wpto_pf_authorid_username_type( $meta_basics ){
       ?>

        <hr> 
        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label" for="wpt_table_author"><?php esc_html_e( 'AuthorID/UserID/VendorID (Optional)', 'wpt_pro' );?></label>
                    </th>
                    <td>
                        <input name="basics[author]"  class="wpt_data_filed_atts ua_input" data-name="author" type="number" value="<?php echo isset( $meta_basics['author'] ) ? $meta_basics['author'] : ''; ?>" placeholder="Author ID/Vendor ID" id="wpt_table_author">
                        <p style="color: #006394;"><?php esc_html_e( 'Only AuthorID or AuthorName field for both [AuthorID/UserID/VendorID] or [author_name/username/VendorUserName]. Don\'t use both.', 'wpt_pro' );?></p>
                    </td>
                </tr>
            </table>
        </div>
        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label" for="wpt_table_author_name"><?php esc_html_e( 'author_name/username/VendorUserName (Optional)', 'wpt_pro' );?></label>
                    </th>
                    <td>
                        <input name="basics[author_name]"  class="wpt_data_filed_atts ua_input" data-name="author_name" type="text" value="<?php echo isset( $meta_basics['author_name'] ) ? $meta_basics['author_name'] : ''; ?>" placeholder="Author username/ Vendor username" id="wpt_table_author_name">
                        <p style="color: #006394;"><?php esc_html_e( 'Only AuthorID or AuthorName field for both [AuthorID/UserID/VendorID] or [author_name/username/VendorUserName]. Don\'t use both.', 'wpt_pro' );?></p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="wpt_column">
            <table class="ultraaddons-table">
                <tr>
                    <th>
                        <label class="wpt_label wpt_table_ajax_action" for='wpt_table_product_type'><?php esc_html_e('Product Type (Product/Variation Product)','wpt_pro');?></label>
                    </th>
                    <td>
                        <select name="basics[product_type]" data-name='product_type' id="wpt_table_product_type" class="wpt_fullwidth wpt_data_filed_atts ua_input" >
                            <option value="" <?php echo isset( $meta_basics['product_type'] ) && $meta_basics['product_type'] == '' ? 'selected' : false; ?>><?php esc_html_e('Product','wpt_pro');?></option>
                            <option value="product_variation" <?php echo isset( $meta_basics['product_type'] ) && $meta_basics['product_type'] == 'product_variation' ? 'selected' : false; ?>><?php esc_html_e('Only Variation Product','wpt_pro');?></option>
                        </select>
                        <p>
                            <?php esc_html_e('If select Variation product, you have to confirm, your all Variation is configured properly. Such: there will not support "any attribute" option for variation. eg: no support "Any Size" type variation.','wpt_pro');?>
                            <br><?php esc_html_e('And if enable Variation product, Some column and feature will be disable. such: Attribute, category, tag Column, Advernce Search box.','wpt_pro');?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>
       <?php

    }
}
add_action( 'wpto_admin_basic_tab_bottom', 'wpto_pf_authorid_username_type', 10 );


if( !function_exists( 'wpto_pro_search_from' ) ){
    

    function wpto_pro_search_from( $meta_search_n_filter, $post ){

       ?>
        <table class="ultraaddons-table wpt_snf_on_off">
            <tr>
                <th>
                    <label class="wpt_label"><?php esc_html_e( 'Search From', 'wpt_pro' ); ?></label>
                </th>
                <td>
                    <ul class="wpt-tag-list">
                    <?php
                    /**
                     * Key: Table's Field Name, such: ID, post_title
                     * Value: table name. posts,postmeta etc
                     * 
                     * User also able to update this array using
                     * filter hook: wpto_admin_search_from_arr
                     * 
                     * Comment added at at 7.0.8
                     */
                    $search_form_arr = array(
                        'ID' => 'posts',
                        'post_title' => 'posts',
                        'post_content' => 'posts',
                        'menu_order' => 'posts',
                        'post_author' => 'posts',
                        'post_excerpt' => 'posts',
                        'post_parent' => 'posts',
                        'post_name' => 'posts',
                        'post_date' => 'posts',
                        '_sku' => 'postmeta',
                        '_price' => 'postmeta',
                        '_regular_price' => 'postmeta',
                        '_sale_price' => 'postmeta',
                        '_sku' => 'postmeta',
                    );
                    $search_form_arr = apply_filters( 'wpto_admin_search_from_arr', $search_form_arr, $post, $meta_search_n_filter );

                    foreach($search_form_arr as $search_key => $search_type){
                        ?>  
                        <li class="wpt_checkbox wpt_search_form_checkbox wpt_<?php esc_attr_e( $search_key ); ?>_checkbox">
                            <input type="checkbox" name="search_n_filter[search_from][<?php esc_attr_e( $search_key ); ?>]" id="search_from_<?php esc_attr_e( $search_key ); ?>" value="<?php esc_attr_e( $search_type ); ?>" <?php echo isset( $meta_search_n_filter['search_from'][$search_key] ) && !empty( $meta_search_n_filter['search_from']) ? 'checked' : ''; ?>>
                            <label for="search_from_<?php esc_attr_e( $search_key ); ?>"><?php esc_html_e( $search_key ); ?></label>
                        </li>
                    <?php
                    }
                    ?>    
                    </ul>
                    <p><b>Search From</b> only will be activate, When <b>Advance Search</b> will stay [On]. Go to: <a href="<?php echo esc_url( admin_url( 'admin.php?page=woo-product-table-config' ) ); ?>" target="_blank">Configuration Page</a></p>
                </td>
            </tr>
        </table>
       <?php
       

    }
}
add_action( 'wpto_admin_search_n_filter_tab', 'wpto_pro_search_from', 10, 2 );

if( !function_exists( 'wpto_pro_custom_filed_filter' ) ){
    

    function wpto_pro_custom_filed_filter( $meta_search_n_filter, $post ){

       ?>
        <table class="ultraaddons-table">
            <tr>
                <th>
                    <label class="wpt_label" for="wpt_cf_search_box"><?php esc_html_e( 'Custom Field Filter', 'wpt_pro' ); ?></label>
                </th>
                <td>
                    <select name="search_n_filter[cf_search_box]" data-name='cf_search_box' id="wpt_cf_search_box" class="wpt_fullwidth wpt_data_filed_atts ua_input wpt_toggle" data-on="yes|.wpt_custom_field_on_off" >
                        <option value="no" <?php echo isset( $meta_search_n_filter['cf_search_box'] ) && $meta_search_n_filter['cf_search_box'] == 'no' ? 'selected' : ''; ?>><?php esc_html_e( 'Hide CF Filter', 'wpt_pro' ); ?></option>
                        <option value="yes" <?php echo isset( $meta_search_n_filter['cf_search_box'] ) && $meta_search_n_filter['cf_search_box'] == 'yes' ? 'selected' : ''; ?>><?php esc_html_e( 'Show CF Filter', 'wpt_pro' ); ?></option>
                    </select>
                    <p class="warning">
                        <b><?php echo esc_html__( 'Tips:', 'wpt_pro' ); ?></b>
                        <span><?php echo esc_html__( 'Not for WooCommerce Archive page. Such: shop page, product category page.','wpt_pro' ); ?></span>
                    </p>
                </td>
            </tr>
        </table>
        <table class="ultraaddons-table wpt_custom_field_on_off">
            <tr>
                <th>
                    <label class="wpt_label"><?php esc_html_e( 'Options', 'wpt_pro' ); ?></label>
                </th>
                <td>
                    <?php
                    
   global $post;
   $data_cfs = get_post_meta($post->ID,'_cf_filter',true );
   $data_cfs_text_data = get_post_meta($post->ID,'_cf_filter_text_data',true );
   
   $choose_text = isset( $data_cfs_text_data['choose_text'] ) && !empty( $data_cfs_text_data['choose_text'] ) ? $data_cfs_text_data['choose_text'] : "";
   ?>
    
    <div class="wpt_cf__wrap">
        <h3 class="wpt_header_title">Change Label -  <small>custom text</small></h3>
        <label for="wpt_key_cf_name_choose">Choose Text</label>
        <input id="wpt_key_cf_name_choose" value="<?php echo $choose_text; ?>" type="text" name="text_data[choose_text]" placeholder="Choose">
        <p class="wpt-tips">
            <b><?php echo esc_html__( 'Tips:', 'wpt_pro' ); ?></b>
            <span><?php echo esc_html__( 'Leave as empty for Multiple Selection.','wpt_pro' ); ?></span>
        </p>
        
        <h3 class="wpt_header_title">Add Custom Field -  <small>Key and Label</small></h3>
         <input class="wpt_key_cf" type="text" placeholder="Key. eg: _size">
         <input class="wpt_key_cf_name" type="text" placeholder="Names. eg: Size">
         <span class="wpt_key_add button button-primary"> <i class=" dashicons dashicons-plus-alt"></i> Add New Field</span>
         <span class="wpt_added_message" style="display: none;">Added to list</span>
         
         <h3 class="wpt_header_title">Add Value For Filter - <small>Based on cf</small></h3>
        <div class="wpt_fields">
            <select class="wpt_select_key">
                
                <?php  
                $warning_message = false;
                if(is_array( $data_cfs ) && count( $data_cfs ) ):
                    foreach($data_cfs as $key=>$perrrrr){
                        $name = $perrrrr['label'];
                        echo '<option value="' . $key . '">' . $name . '</option>';
                    }
                else:
                    $warning_message = "<p class='wpt_warning'>No Custom Field Added. Please Add Custom Feied first.</p>";
                endif;
                ?>
            </select>
            <input class="wpt_field_adding_input" type="text" placeholder="Value">
            
        </div>
        
        <span class="wpt_add_field button button-primary" title="Click here to add new custom fields "><i class="dashicons dashicons-plus-alt"></i> Add Value</span>
        <?php echo $warning_message; ?>
    </div>


<h3 class="wpt_filt_value_wrapper_head wpt_header_title">Added Values: <smal>(bellow)</smal></h3>
        <div id="wpt_cf__form_field_wrapper">
        <?php
            
            //var_dump($data_cfs);
            if(is_array( $data_cfs ) && count( $data_cfs ) ):
            foreach($data_cfs as $key=>$per){
                
                echo "<div class='wpt_each_row_wrapper'>";
                //echo "<input>";
                /*****************************/
                $name = $per['label'];
                echo "<div class='wpt_fld_header'>Label: <b>{$name}</b> | Key: <i>" . $key . "</i></div>";//<span class='key_name'>
                echo "<div class='wpt_each_row wpt_each_row_{$key}'>";
                echo "<input type='hidden' name='_cf_filter[{$key}][label]' value='{$name}' >";
                if( isset( $per['values'] ) && is_array( $per['values'] ) && count( $per['values'] ) > 0 ){
                    $list = $per['values'];
                    foreach ($list as $pper){
                        echo "<input type='text' name='_cf_filter[{$key}][values][]' value='{$pper}' class='wpt_field_value'>";
                    }
                }
                
                
                echo "</div>";
                echo "<i class='wpt_cross_button'>x</i>";
                //******************************/
                echo "</div>";
            }
            else:
                echo "<p class='wpt_no_value'>Not found. Please add Custom Field and Values as well.</p>";
            endif;
        ?>

        </div>

                </td>
            </tr>
        </table>
       <?php
       

    }
}
add_action( 'wpto_admin_search_n_filter_tab_bottom', 'wpto_pro_custom_filed_filter', 10, 2 );


