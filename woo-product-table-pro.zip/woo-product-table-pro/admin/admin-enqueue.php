<?php
if( !function_exists( 'wpt_pro_admin_enqueue' ) ){
    /**
     * CSS or Style file add for Admin Section. 
     * 
     * @since 1.0.0
     * @update 1.0.3
     */
    function wpt_pro_admin_enqueue(){

        wp_enqueue_style( 'wpt-admin-pro', WOO_Product_Table::getPath( 'BASE_URL' ) . 'assets/css/admin-pro.css', array(), '1.0.0', 'all' );
        wp_enqueue_script( 'wpt-admin-pro', WOO_Product_Table::getPath( 'BASE_URL' ) . 'assets/js/admin-pro.js', array( 'jquery','select2' ), '1.0.0', true );
    }
}
add_action( 'admin_enqueue_scripts', 'wpt_pro_admin_enqueue', 99 );
