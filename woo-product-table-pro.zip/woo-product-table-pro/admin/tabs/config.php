<?php
$current_config_value = $temp_current_value =  get_post_meta( $post->ID, 'config', true );

if( ! is_array( $temp_current_value ) ){
    $current_config_value = get_option( 'wpt_configure_options' );
    $current_config_value = array_map(function($sss){
        return '';
    },$current_config_value);
    
}

$default_config = get_option( 'wpt_configure_options' );
if( is_array( $temp_current_value ) && is_array( $default_config ) ){
    
    foreach( $default_config as $key => $value ){
        $current_config_value[$key] = isset($current_config_value[$key]) ? $current_config_value[$key] : '';
    }
    
}

$settings = array(
    'page' => 'wpt_configuration_tab',
    'module' => 'free',
);
$settings = apply_filters( 'wpto_configuration_settings', $settings );
//*********************/
$wrapper_class = isset( $settings['module'] ) ? $settings['module'] : '';
?>
    <div style="padding-top: 15px;padding-bottom: 15px;" class="fieldwrap wpt_result_footer ultraaddons <?php echo esc_attr( $wrapper_class ); ?>">
        
        <?php
        do_action( 'wpto_admin_configuration_form_version_data', $settings,$current_config_value );
                    
        /**
         * To add something and Anything at the top of Form Of Configuratin Page
         */
        do_action( 'wpto_admin_configuration_form_top', $settings,$current_config_value ); 


        do_action( 'wpto_admin_configuration_form', $settings,$current_config_value,'config' ); //config it's form name. Such: <input name='config[search_box]'>

        do_action( 'wpto_admin_configuration_form_bottom', $settings,$current_config_value ); 
                    ?>

    </div>
