<?php
/****** PRO VERSION - ADMIN FUNCTION *******
 * WPT PRO VERSION
 * MAIN MODULE
 */



if( !function_exists( 'wpt_pro_admin_tab' ) ){
    
    /**
     * Adding New Tab on Product Table Edit
     * We have added to new Column For Pro Version
     * If any user want to add new Tab for Setting, Just u can use Filter: wpto_admin_tab_array
     * DEFAULT IN MODULE:
     * $tab_array = array(
        'column_settings'   => __( "Column", 'wpt_pro' ),
        'basics'            => __( 'Basics', 'wpt_pro' ),
        'conditions'        => __( 'Conditions', 'wpt_pro' ),
        'search_n_filter'   => __( 'Search Box And Filter','wpt_pro' ),
        'mobile'            => __( 'Mobile Issue', 'wpt_pro' ),
    );
     * FILE: admin/post_metabox_form.php
     * @param type $tab_array Form tab of Product edit populate from a Array
     * @return Array
     */
    function wpt_pro_admin_tab( $tab_array ){
        $tab_array['table_style'] = sprintf(__( 'Design %sspecial%s', 'wpt_pro' ), '<i class="wpt_pro_only">', '</i>' );//__( 'Design', 'wpt_pro' ); 
        $tab_array['config'] = sprintf(__( 'Configuration %sspecial%s', 'wpt_pro' ), '<i class="wpt_pro_only">', '</i>' );//__( 'Configuration', 'wpt_pro' );
        return $tab_array;
    }
}
add_filter( 'wpto_admin_tab_array', 'wpt_pro_admin_tab' );

if( !function_exists( 'wpt_pro_admin_tab_save' ) ){
    
    /**
     * If add new tab from Addon/ Pro version, have to add on wpto_save_tab_array Filter
     * If that Array is not builtin in Main Module Woo Product Table
     * 
     * @param type $save_tab_array
     * @return Array
     */
    function wpt_pro_admin_tab_save( $save_tab_array ){
        $save_tab_array['table_style'] = 'table_style';
        $save_tab_array['config'] = 'config';
        return $save_tab_array;
    }
}
add_filter( 'wpto_save_tab_array', 'wpt_pro_admin_tab_save' );

if( !function_exists( 'wpt_pro_admin_tab_file' ) ){
    
    /**
     * If add new tab of Product table Edit, and u want to show that tab content from your file, 
     * you have to indicate your template file.
     * User also able to change specific templabe for specific Tab
     * But we have changed main Tab's folder ditecotry by using wpto_admin_tab_folder_dir Filter
     * 
     * @param type $tab_dir_loc
     * @param type $tab
     * @return type
     */
    function wpt_pro_admin_tab_file( $tab_dir_loc, $tab ){
        $pro_tabs = array(
            'table_style',
            'config'
        );
        $loc = WPTP_BASE_DIR . 'admin/tabs/';
        return in_array( $tab, $pro_tabs ) ? $loc : $tab_dir_loc;
    }
}

add_filter( 'wpto_admin_tab_folder_dir', 'wpt_pro_admin_tab_file', 50, 2 );

if( !function_exists( 'wpt_pro_add_new_colunms' ) ){
    
    /**
     * Adding new option at ADD NEW COLUMN
     * Each column by default type is 'default'
     * but if a user add new column from "ADD NEW COLUMN" button, than user able to add new type
     * In main Module, Available type/setting is: default, cf, taxonomy
     * we will add new two type, blank, and afc
     * DEFAULT IN MODULE: 
     * $add_new_col_type = array(
                'default' => "Default/No Type",
                'cf' => 'Custom Field',
                'taxonomy' => 'Taxonomy',
            );
     * FILE: admin/tabs/column_settings.php
     * 
     * For this New Type Column, Obviously Need tempalte file,
     * we have added tempalte file at includes/functions.php file using
     * @param type $tab_dir_loc
     * @param type $tab
     * @return type
     */
    function wpt_pro_add_new_colunms( $add_new_col_type ){
        $add_new_col_type['blank'] = __( 'Blank', 'wpt_pro' );
        $add_new_col_type['acf'] = __( 'Advance Custom Field', 'wpt_pro' );
        $add_new_col_type['hook_action'] = __( 'Action Hooks', 'wpt_pro' );
        $add_new_col_type['array'] = __( 'Array type Custom Field', 'wpt_pro' );
        $add_new_col_type['audio'] = __( 'Audio File Type', 'wpt_pro' );
        $add_new_col_type['all_content'] = __( 'All Type Content', 'wpt_pro' );
        return $add_new_col_type;
    }
}
add_filter( 'wpto_addnew_col_arr', 'wpt_pro_add_new_colunms' );

if( !function_exists( 'wpt_pro_add_pro_class' ) ){
    
    /**
     * Adding new option at ADD NEW COLUMN
     */
    function wpt_pro_add_pro_class( $settings ){
        $settings['module'] ='pro_version';
        return $settings;
    }
}
add_filter( 'wpto_configuration_settings', 'wpt_pro_add_pro_class' );

if( !function_exists( 'wpt_pro_show_all_terms_query' ) ){
    
    /**
     * Adding All Terms at Query
     * 
     * @param type $supported_terms
     * @param type $tab_array
     * @param type $post
     * @return type
     */
    function wpt_pro_show_all_terms_query( $supported_terms, $tab_array, $post ){
        
        $ourTermList = $supported_terms;
        $support_all_terms = apply_filters( 'wpto_all_terms', true, $post );
        if( $support_all_terms ){
            $term_lists = get_object_taxonomies('product','objects');
            $ourTermList = false;
            foreach( $term_lists as $trm_key => $trm_object ){
                if( $trm_object->labels->singular_name == 'Tag' && $trm_key !== 'product_tag' ){
                    $ourTermList[$trm_key] = $trm_key;
                }else{
                    $ourTermList[$trm_key] = $trm_object->labels->singular_name;
                }
            }
        }else{
            return $supported_terms;
        }
        unset( $ourTermList['product_shipping_class'] );
        $supported_terms = apply_filters( 'wcmmq_terms_list', $ourTermList, $post );
        
        return $supported_terms;
    }
}
add_filter( 'wpt_supported_terms', 'wpt_pro_show_all_terms_query', 10, 3 );

if( !function_exists( 'wpt_pro_product_inex_clude_in_admin' ) ){
    
    /**
     * Only for Admin and for Product Exclude and include
     * 
     * @global type $product
     * 
     * @return void Exclude List of Product for exclude include option tag
     */
    function wpt_pro_product_inex_clude_in_admin(){
        // we will pass post IDs and titles to this array
            $return = array();

            // you can use WP_Query, query_posts() or get_posts() here - it doesn't matter

            $args = array(
                'posts_per_page' => 15,
                'post_type' => array('product'), //, 'product_variation','product'
                'post_status'   =>  'publish',
                's'         => isset( $_GET['q'] ) && !empty( $_GET['q'] ) ? $_GET['q'] : '',
            );

            $search_results = new WP_Query( $args );
            if( $search_results->have_posts() ) :
                    while( $search_results->have_posts() ) : $search_results->the_post();	
                        global $product;

                        $data = $product->get_data();
                            // shorten the title a little
                            $title = ( mb_strlen( $search_results->post->post_title ) > 50 ) ? mb_substr( $search_results->post->post_title, 0, 49 ) . '...' : $search_results->post->post_title;
                            $return[$search_results->post->ID] = array( 
                                'id' => $search_results->post->ID, 
                                'title' => $title ,
                                'stock_status' => $product->get_stock_status(),
                                'price' => $product->get_price_html(),
                                'image' => woocommerce_get_product_thumbnail( array( 50, 50 ) ),
                                    ); // array( Post ID, Post Title )
                    endwhile;
            endif;

            echo json_encode( $return );
            die;
    }
}
add_action( 'wp_ajax_wpt_pro_admin_product_list', 'wpt_pro_product_inex_clude_in_admin' );
add_action( 'wp_ajax_nopriv_wpt_pro_admin_product_list', 'wpt_pro_product_inex_clude_in_admin' );


if( !function_exists( 'wpt_pro_column_extra_options' ) ){
    
    /**
     * Adding Class for Each Item in Pro version
     * 
     * @param type $keyword
     * @param type $column_settings
     * @param type $columns_array
     * @param type $updated_columns_array
     * @param type $post
     * @return void Description
     */
    function wpt_pro_column_extra_options( $keyword, $_device_name, $column_settings, $columns_array, $updated_columns_array, $post ){
        $shuffle = substr( str_shuffle('abcdefjhijklmnopqrstuvwxyzABCDEFGHITJKLMNOPQRSTUFWXYZ'), 5, 10 );
        $default_class = 'item_' . $keyword . '_' . $post->ID . ' item_' . $shuffle;
        $inside_label_check = isset( $column_settings[$keyword]['inside_label'] ) ? 'checked' : '';
        
        $auto_responsive_column_label_show = isset( $column_settings[$keyword]['auto_responsive_column_label_show'] ) && $column_settings[$keyword]['auto_responsive_column_label_show'] == 'on' ? 'checked' : '';
        $only_login_user_check = isset( $column_settings[$keyword]['only_login_user'] ) ? 'checked' : '';
        
        //Toggle Features
        $toggle = isset( $column_settings[$keyword]['toggle'] ) ? 'checked' : '';
        $toggle_label = isset( $column_settings[$keyword]['toggle_label'] ) && ! empty( $column_settings[$keyword]['toggle_label'] ) ? $column_settings[$keyword]['toggle_label'] : '';
        
        $fullwidth = isset( $column_settings[$keyword]['fullwidth'] ) ? 'checked' : '';
        $tag_class = isset( $column_settings[$keyword]['tag_class'] ) ? $column_settings[$keyword]['tag_class'] : $default_class;
        $tag_class = is_string( $tag_class ) ? preg_replace('/[^A-Za-z0-9-_ ]+/', '-', $tag_class) : false;
        ?>
        <div class="column_tag_for_all">
            <label>Wrapper tag's class</label>
            <input type="text" class="ua_input" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][tag_class]" value='<?php echo esc_attr( $tag_class ); ?>'>
            <p><?php echo esc_html__( 'Set your preferred class for item.','wpt_pro' ); ?></p>
        </div>
        <div class="column_label_fullwidth">
            <label>Fullwidth Column</label>
            <input type="checkbox" class="" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][fullwidth]" <?php echo esc_attr( $fullwidth ); ?>>
            <p><?php echo esc_html__( 'To show Label of Item before Inside Item.','wpt_pro' ); ?></p>
        </div>
        <div class="column_label_showing">
            <label>Inside Item Label </label>
            <input type="checkbox" class="" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][inside_label]" <?php echo esc_attr( $inside_label_check ); ?>>
            <p><?php echo esc_html__( 'To show Label of Item before Inside Item.','wpt_pro' ); ?></p>
        </div>
        <?php if( $keyword != 'check' ) : ?>
        <div class="auto_responsive_column_label_show">
            <label for="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][auto_responsive_column_label_show]">Hide column label for Mobile/Tablet</label>
            <input type="checkbox" class="" id="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][auto_responsive_column_label_show]" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][auto_responsive_column_label_show]" <?php echo esc_attr( $auto_responsive_column_label_show ); ?>>
            <p><?php echo esc_html__( 'Hide column label for Mobile/Tablet before each item. Importance: Only for Auto Responsive Mode.','wpt_pro' ); ?></p>
        </div>
        <?php endif; ?>
        <div class="column_only_login_user">
            <label>Only Login user</label>
            <input type="checkbox" class="" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][only_login_user]" <?php echo esc_attr( $only_login_user_check ); ?>>
            <p><?php echo esc_html__( 'To show Hide Column or as Item inside Column, Check it.','wpt_pro' ); ?></p>
        </div>
        <div class="column_only_login_user">
            <label>Toggle Show Hide</label>
            <input type="checkbox" class="" name="column_settings[<?php echo $keyword; ?>][toggle]" <?php echo esc_attr( $toggle ); ?>>
            <br><label>Toggle Text</label>
            <input style="display: inline;" type="text" class="" name="column_settings<?php echo $_device_name; ?>[<?php echo $keyword; ?>][toggle_label]" value="<?php echo esc_attr( $toggle_label ); ?>">
            <p><?php echo esc_html__( 'To show Hide Column or as Item inside Column, Check it.','wpt_pro' ); ?></p>
        </div>

        <?php
    }
}

add_action( 'wpto_column_setting_form', 'wpt_pro_column_extra_options', 11, 6 );


if( !function_exists( 'wpt_product_includes_select_option' ) ){
    function wpt_product_includes_select_option( $args ){
        
        $html = false;
   $p_query_posts = $args;
        if( is_array( $p_query_posts ) && count( $p_query_posts ) > 0 ){
            foreach( $p_query_posts as $MY_ID ){
                $p_product = wc_get_product($MY_ID);
                $data = $p_product->get_data();
                $name = $data['name'];
                
                $stock_status = isset( $data['stock_status'] ) ? $data['stock_status'] : '';
                $price =  isset( $data['price'] ) ? get_woocommerce_currency_symbol(). '' . $data['price'] : '';
                $img_src = wp_get_attachment_image_src( get_post_thumbnail_id( $MY_ID ), array(50,50), false );
                $image = isset( $img_src[0] ) ? $img_src[0] : '';
                $text = $image . "|" . $price . "|" . $stock_status;
                $title = ( mb_strlen( $name ) > 50 ) ? mb_substr( $name, 0, 49 ) . '...' : $name;
                $html .= "<option title=" . esc_attr( $text ) . " value=". $MY_ID ." selected>$title</option>";

            }
        }
   $post_include = $html;//wpt_product_includes_select_option($args);


        return $post_include;
    }
}

if( !function_exists( 'wpt_pro_data_manipulation_on_save' ) ){
    
    /**
     * Used Filter:
     * $tab_data = apply_filters( 'wpto_tab_data_on_save', $tab_data, $tab, $post_id, $save_tab_array );
     * 
     * @param type $data
     * @return type
     */
    function wpt_pro_data_manipulation_on_save( $tab_data, $tab, $post_id, $save_tab_array ){
        
        return $tab_data;
    }
}
add_filter( 'wpto_tab_data_on_save', 'wpt_pro_data_manipulation_on_save', 10, 4 );

if( !function_exists( 'wpt_pro_add_supported_css_property' ) ){
    
    /**
     *$supported_css_property = array(
     *   'color'        =>  'Text Color',
     *   'background-color'=>'Background Color',
     *   'border'=>'Border',
     *);
     *$supported_css_property = apply_filters( 'wpto_supported_css_property', $supported_css_property, $tab_array, $post );
     * 
     * @param type $data
     * @return type
     */
    function wpt_pro_add_supported_css_property( $css_propertyt ){
        $css_propertyt['width'] = 'Column/Item width';
        $css_propertyt['height'] = 'Column/Item Height';
        $css_propertyt['font-size'] = 'Font or Text Size';
        $css_propertyt['font-style'] = 'Font Style';
        $css_propertyt['padding'] = 'Element Padding';
        $css_propertyt['margin'] = 'Element Margin';
        return $css_propertyt;
    }
}
add_filter( 'wpto_supported_css_property', 'wpt_pro_add_supported_css_property', 10);

if( !function_exists( 'wpto_pro_special_option' ) ){
    
    function wpto_pro_special_option( $settings, $current_config_value, $field_name ){
        if( !isset( $settings['page'] ) || isset( $settings['page'] ) && $settings['page'] != 'wpt_configuration_tab' ){
            return;
        }
        ?>
        <div class="section ultraaddons-panel label">
            <h3 class="with-background dark-background"><?php esc_html_e( 'Special Features', 'wpt_pro' );?></h3>
            <table class="ultraaddons-table">
                <tr class="each-style">
                    <th><label for="wpt_show_variation_label"><?php esc_html_e( 'Show Variation Label?', 'wpt_pro' );?></label></th>
                    <td>
                        <label class="switch">
                            <input name="<?php echo esc_attr( $field_name ); ?>[wpt_show_variation_label]" type="checkbox" id="wpto_show_variation_label" <?php echo isset( $current_config_value['wpt_show_variation_label'] ) ? 'checked="checked"' : ''; ?>>
                            <div class="slider round">
                                <span class="on">On</span><span class="off">Off</span><!--END-->
                            </div>
                        </label>
                        <p><?php echo esc_html__( 'If you want to show variation label before on each variation, enable this switch', 'wpt_pro' ); ?></p>
                    </td>
                    </tr>
            </table>
            <div class="ultraaddons-button-wrapper">
                <button name="configure_submit" class="button-primary primary button">Save All</button>
            </div>
        </div>
<?php
    }
    
}
add_action( 'wpto_admin_configuration_form', 'wpto_pro_special_option', 10, 3 );

 
//function wpt_filter_metabox(){
//    add_meta_box( 'wpt_filter_metabox_id', 'Custom Field Filter', 'wpt_filter_metabox_render', 'wpt_product_table', 'normal' );
//}
//add_action('add_meta_boxes','wpt_filter_metabox', 99);

/**
 * It's Unused function. actually has transferred to action-hook.php 
 * to insert Search and filter tab
 * 
 * @global type $post
 * @deprecated since 7.0.9.6 7096 It's removed from metabox. Now totally removed.
 */
function wpt_filter_metabox_render(){
   global $post;
   $data_cfs = get_post_meta($post->ID,'_cf_filter',true );
   $data_cfs_text_data = get_post_meta($post->ID,'_cf_filter_text_data',true );
   
   $choose_text = isset( $data_cfs_text_data['choose_text'] ) && !empty( $data_cfs_text_data['choose_text'] ) ? $data_cfs_text_data['choose_text'] : "Choose";
   ?>
    
    <div class="wpt_cf__wrap">
<!--        <h3 class="wpt_header_title">Change Label -  <small>custom text</small></h3>
        <label for="wpt_key_cf_name_choose">Choose Text</label>
        <input id="wpt_key_cf_name_choose" value="<?php echo $choose_text; ?>" type="text" name="text_data[choose_text]" placeholder="Choose">
        -->
        <h3 class="wpt_header_title">Add Custom Field -  <small>Key and Label</small></h3>
         <input class="wpt_key_cf" type="text" placeholder="Key. eg: _size">
         <input class="wpt_key_cf_name" type="text" placeholder="Names. eg: Size">
         <span class="wpt_key_add button button-primary"> <i class=" dashicons dashicons-plus-alt"></i> Add New Field</span>
         <span class="wpt_added_message" style="display: none;">Added to list</span>
         
         <h3 class="wpt_header_title">Add Value For Filter - <small>Based on cf</small></h3>
        <div class="wpt_fields">
            <select class="wpt_select_key">
                
                <?php  
                $warning_message = false;
                if(is_array( $data_cfs ) && count( $data_cfs ) ):
                    foreach($data_cfs as $key=>$perrrrr){
                        $name = $perrrrr['label'];
                        echo '<option value="' . $key . '">' . $name . '</option>';
                    }
                else:
                    $warning_message = "<p class='wpt_warning'>No Custom Field Added. Please Add Custom Feied first.</p>";
                endif;
                ?>
            </select>
            <input class="wpt_field_adding_input" type="text" placeholder="Value">
            
        </div>
        
        <span class="wpt_add_field button button-primary" title="Click here to add new custom fields "><i class="dashicons dashicons-plus-alt"></i> Add Value</span>
        <?php echo $warning_message; ?>
    </div>


<h3 class="wpt_filt_value_wrapper_head wpt_header_title">Added Values: <smal>(bellow)</smal></h3>
        <div id="wpt_cf__form_field_wrapper">
        <?php
            
            //var_dump($data_cfs);
            if(is_array( $data_cfs ) && count( $data_cfs ) ):
            foreach($data_cfs as $key=>$per){
                
                echo "<div class='wpt_each_row_wrapper'>";
                //echo "<input>";
                /*****************************/
                $name = $per['label'];
                echo "<div class='wpt_fld_header'>Label: <b>{$name}</b> | Key: <i>" . $key . "</i></div>";//<span class='key_name'>
                echo "<div class='wpt_each_row wpt_each_row_{$key}'>";
                echo "<input type='hidden' name='_cf_filter[{$key}][label]' value='{$name}' >";
                if( isset( $per['values'] ) && is_array( $per['values'] ) && count( $per['values'] ) > 0 ){
                    $list = $per['values'];
                    foreach ($list as $pper){
                        echo "<input type='text' name='_cf_filter[{$key}][values][]' value='{$pper}' class='wpt_field_value'>";
                    }
                }
                
                
                echo "</div>";
                echo "<i class='wpt_cross_button'>x</i>";
                //******************************/
                echo "</div>";
            }
            else:
                echo "<p class='wpt_no_value'>Not found. Please add Custom Field and Values as well.</p>";
            endif;
        ?>

        </div>
<?php

}

/**
 * In action-hook.php file, we added some field for 
 * Custom Field filter, and for these field,
 * following function is required.
 * 
 * @since 
 * 
 * @param type $post_id
 */
function wpt_save_cf_values_for_filter($post_id){
    //var_dump($_POST['text_data'],$_POST['data']);exit;
    if(isset($_POST['_cf_filter'])){
        update_post_meta($post_id,'_cf_filter', $_POST['_cf_filter']);
    }else{
        update_post_meta($post_id,'_cf_filter', false);
    }
    
    if(isset($_POST['text_data'])){
        update_post_meta($post_id,'_cf_filter_text_data', $_POST['text_data']);
    }else{
        update_post_meta($post_id,'_cf_filter_text_data', false);
    }

}
add_action( 'save_post', 'wpt_save_cf_values_for_filter'); // 

if( !function_exists( 'wpt_taxonomy_table_select_tag' ) ){
    
    /**
     * We need select tag with option 
     * in two different function:
     * -wpt_field_on_taxomoy()
     * -wpt_edit_term_fields()
     * 
     * to display table select field on when create taxonomy and on edit taxonomy
     * 
     * ___________________________
     * for that:
     * we have created a function, so that I can use same function in two different function.
     * 
     * 
     * @param Int $selected_table_id Table id number will be numeric. Default is: false.
     * 
     * @since 7.0.9
     * @author Saiful <codersaiful@gmail.com>
     */
    function wpt_taxonomy_table_select_tag( $selected_table_id = false ){

        
        $args = array(
            'post_type' => 'wpt_product_table',
            'numberposts' => -1,
        );
        $product_tables = get_posts( $args );

        if( ! empty( $product_tables ) ){
            ?>
            <select name="table_id" class="wpt-taxonomy-table" id="table_id">
            <option value=""><?php echo esc_html__( 'Select a Table', 'wpt_pro' ); ?></option>
            <?php 

            foreach ($product_tables as $table){
                $table_id = $table->ID;
                $selected = $table_id == $selected_table_id ? 'selected' : '';
                echo '<option value="'. $table_id .'" ' . $selected . '>' . $table->post_title . '</option>'; 
            }
            ?>
            </select>
            <?php
        } else { 
        ?>
            <p class="wpt-tips"><?php echo esc_html( 'Seems you have not created any table yet. Create a table first!', 'wpt_pro' ); ?></p>    
        <?php
        }   
    }
}
if( ! function_exists( 'wpt_field_on_taxomoy' ) ){
    
    /**
     * Display product table select option 
     * at our selected taxonomy
     * When Edit Taxonomy/Cat/Tag of Product
     * 
     * primarily we have did it for product tag and category
     * 
     * @since 7.0.9
     * @author Saiful <codersaiful@gmail.com>
     */
    function wpt_field_on_taxomoy(){
        global $taxonomy;
        $tax = get_taxonomy($taxonomy);
        $label = $tax->labels->singular_name;

        ?>
        <div class="form-field">
            <label for="table_id"><?php echo esc_html__( 'Product Table' ); ?></label>
            <?php wpt_taxonomy_table_select_tag(); ?>
            <p><?php echo esc_html__( sprintf( 'Select Product Table for this [%s] to display your product as Table.', $label ) ); ?></p>
        </div> 


        <?php
    }
}



if( !function_exists( 'wpt_edit_term_fields' ) ){
    
    /**
     * Display product table select option 
     * at our selected taxonomy
     * When Edit Taxonomy/Cat/Tag of Product
     * 
     * primarily we have did it for product tag and category
     * 
     * @param Object $term
     * @param string $taxonomy
     * 
     * @since 7.0.9
     * @author Saiful <codersaiful@gmail.com>
     */
    function wpt_edit_term_fields( $term, $taxonomy ) {


        $label = $term->name;
        $selected_table_id = get_term_meta( $term->term_id, 'table_id', true );
        ?>
        <tr class="form-field">
            <th>
                <label for="table_id"><?php echo esc_html__( 'Product Table' ); ?></label>
            </th>
            <td>
                <?php wpt_taxonomy_table_select_tag( $selected_table_id ); ?>
                <p><?php echo esc_html__( sprintf( 'Select Product Table for [%s] to display your products as Table.', $label ) ); ?></p>
            </td>
        </tr>
        <?php

    }    
}


$wpt_supported_taxonomy = array(
    'product_cat' => 'product_cat',
    'product_tag' => 'product_tag',
);
$wpt_supported_taxonomy = apply_filters( 'wpto_supported_taxonmy_arr', $wpt_supported_taxonomy );
if( is_array( $wpt_supported_taxonomy ) ){
    
    foreach( $wpt_supported_taxonomy as $tax_wpt ){
        add_action( $tax_wpt . '_add_form_fields', 'wpt_field_on_taxomoy' ); //product_cat_add_form_fields
        add_action( $tax_wpt . '_edit_form_fields', 'wpt_edit_term_fields', 10, 2 );
        
        //Save Data on Submit
        add_action( 'created_' . $tax_wpt, 'wpt_save_term_fields' ); //When create new tax
        add_action( 'edited_' . $tax_wpt, 'wpt_save_term_fields' ); //When update/edit existing tax
    }
}
if( !function_exists( 'wpt_save_term_fields' ) ){
    
    /**
     * Update our table id for our selected taxonomy
     * 
     * @since 7.0.9
     * @author Saiful <codersaiful@gmail.com>
     */
    function wpt_save_term_fields( $term_id ) {
            update_term_meta( $term_id, 'table_id', sanitize_text_field( $_POST[ 'table_id' ] ) );
    }    
}

