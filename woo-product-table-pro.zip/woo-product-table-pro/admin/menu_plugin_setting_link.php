<?php
add_filter('plugin_action_links_' . WOO_Product_Table::getPath('PLUGIN_BASE_FILE'), 'wpt_pro_add_action_links');

if( !function_exists( 'wpt_pro_add_action_links' ) ){
    /**
     * For showing configure or add new link on plugin page
     * It was actually an individual file, now combine at 4.1.1
     * @param type $links
     * @return type
     */
    function wpt_pro_add_action_links($links) {
        $hello[] = '<a href="' . admin_url( 'post-new.php?post_type=wpt_product_table' ) . '" title="' . esc_attr__( 'Add new Shortcode', 'wpt_pro' ) . '">' . esc_html__( 'Create Table', 'wpt_pro' ).'</a>';
        $hello[] = '<a href="' . admin_url( 'edit.php?post_type=wpt_product_table&page=woo-product-table-config' ) . '" title="' . esc_attr__( 'Configure for Universal', 'wpt_pro' ) . '">' . esc_html__( 'Configure', 'wpt_pro' ) . '</a>';
        $hello[] = '<a href="https://codeastrology.com/support/" title="' . esc_attr__( 'CodeAstrology Support', 'wpt_pro' ) . '" target="_blank">'.esc_html__( 'Support','wpt_pro' ).'</a>';
        return array_merge( $hello, $links );
    }                                       
}


if( !function_exists( 'wpt_pro_admin_menu' ) ){
    
    /**
     * Set Menu for WPT (Woo Product Table) Plugin
     * It was actually an individual file, now combine  at 4.1.1
     * 
     * @since 1.0
     * 
     * @package Woo Product Table
     * 
     * Pro Feature Menu removed, when installed pro. at V7.0.9.6
     */
    function wpt_pro_admin_menu() {
        
        remove_submenu_page('edit.php?post_type=wpt_product_table', 'https://codecanyon.net/item/woo-product-table-pro/20676867?ref=CodeAstrology&utm_source=WPT_Installed_Plugin');
        remove_submenu_page('edit.php?post_type=wpt_product_table', 'wpt_fac_contact_page');
        //Pro Feature Menu removed, when installed pro. at V7.0.9.6
        remove_submenu_page('edit.php?post_type=wpt_product_table', 'wpt-pro-features');
        add_submenu_page( 'edit.php?post_type=wpt_product_table', esc_html__( 'FAQ & Support page - Contact With US', 'wpt_pro' ), esc_html__( 'FAQ ', 'wpt_pro' ), WPTP_CAPABILITY, 'wpt_fac_contact_page', 'wpt_fac_support_page' );
        add_submenu_page( 'edit.php?post_type=wpt_product_table', esc_html__( 'Get Updates', 'wpt_pro' ), esc_html__( 'Get Updates', 'wpt_pro' ), WPTP_CAPABILITY, 'https://wooproducttable.com/get-automatic-updates-from-codecanyon/' );

    }
}
add_action( 'admin_menu', 'wpt_pro_admin_menu',50 );
