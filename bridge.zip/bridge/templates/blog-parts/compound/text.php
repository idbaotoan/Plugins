
<div class="post_text">
    <?php bridge_qode_excerpt(); ?>
</div>