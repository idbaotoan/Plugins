<?php

global $bridge_qode_framework;
global $bridge_qode_options;

/*old variable $qodeFramework that is changed with $bridge_qode_framework*/
global $qodeFramework;
$qodeFramework = $bridge_qode_framework;

/*old variable $qode_options_proya that is changed with $bridge_qode_options*/
global $qode_options_proya;
$qode_options_proya = $bridge_qode_options;

function qode_get_title_tag(){
    return null;
}

function qode_rating_criteria(){
    return null;
}

function qode_get_space_between_items_array(){
    return null;
}

function qode_options(){
    return bridge_qode_options();
}

function qode_framework(){
    return bridge_qode_framework();
}

function qode_get_button_html(){
    return null;
}

function qode_get_button_v2_html(){
    return null;
}

function qode_execute_shortcode(){
    return null;
}

function qode_add_admin_page(){
    return null;
}

function qode_add_admin_panel(){
    return null;
}

function qode_add_admin_field(){
    return null;
}

function qode_add_meta_box(){
    return null;
}

function qode_add_meta_box_field(){
    return null;
}

function qode_add_taxonomy_field(){
    return null;
}

function qode_add_repeater_field(){
    return null;
}

function qode_get_title(){
    return null;
}

function qode_add_taxonomy_fields(){
    return null;
}

function qode_kses_img(){
    return null;
}

function qode_class_attribute(){
    return null;
}

function qode_get_inline_style(){
    return null;
}

function qode_icon_collections(){
    return bridge_qode_icon_collections();
}

function qode_category_color_name(){
    return null;
}

function qode_show_comments(){
    return null;
}

function qode_get_meta_field_intersect(){
    return null;
}

function qode_get_query_order_array(){
    return null;
}

function qode_get_yes_no_select_array(){
    return null;
}

function qode_inline_style(){
    return null;
}

function qode_get_query_order_by_array(){
    return null;
}

function qode_get_text_transform_array(){
    return null;
}

function qode_string_ends_with(){
    return null;
}

function qode_is_woocommerce_installed(){
    return null;
}

function qode_get_page_id(){
    return null;
}

function qode_blog_item_has_link(){
    return null;
}

function qode_excerpt(){
    return null;
}

function qode_get_social_share_html(){
    return null;
}

function qode_return_post_format(){
    return null;
}

function qode_filter_px(){
    return null;
}

function qode_add_admin_container(){
    return null;
}

function qode_check_gallery_post_layout(){
    return null;
}

function qode_get_blog_gallery_layout(){
    return null;
}

function qode_get_inline_attrs(){
    return null;
}

function qode_sidebar_layout(){
    return null;
}

function qode_post_has_read_more(){
    return null;
}

function qode_get_content_sidebar_class(){
    return null;
}

function qode_get_sidebar_holder_class(){
    return null;
}

function qode_generate_thumbnail(){
    return null;
}

function qode_add_admin_group(){
    return null;
}

function qode_dynamic_css(){
    return null;
}

function qode_hex2rgb(){
    return null;
}

function qode_is_responsive_on(){
    return null;
}

function qode_add_admin_section_title(){
    return null;
}

function qode_add_admin_container_no_style(){
    return null;
}

function qode_add_admin_row(){
    return null;
}

function qode_is_font_option_valid(){
    return null;
}

function qode_get_font_option_val(){
    return null;
}

function qode_get_class_attribute(){
    return null;
}

function qode_get_blog_single_params(){
    return null;
}

function qode_get_pricing_table_item_html(){
    return null;
}

function qode_get_module_template_part(){
    return null;
}

function qode_is_ajax_enabled(){
    return null;
}

function qode_core_plugin_installed(){
    return null;
}

function qode_rating_posts_types(){
    return null;
}

function qode_is_wpml_installed(){
    return null;
}

function qode_get_link_target_array(){
    return null;
}

function qode_add_multiple_images_field(){
    return null;
}

function qode_get_font_style_array(){
    return null;
}

function qode_get_font_weight_array(){
    return null;
}

function qode_rgba_color(){
    return null;
}

function qode_get_attachment_id_from_url(){
    return null;
}