<?php
do_action('bridge_qode_action_style_dynamic_responsive');
