<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/page/page-functions.php';

if( bridge_qode_is_theme_registered() ) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/page/meta-boxes/map.php';
}

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/page/options-map/map.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/page/custom-styles/page.php';
