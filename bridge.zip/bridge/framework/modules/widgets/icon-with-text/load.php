<?php

include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/icon-with-text/icon-with-text.php';
include_once QODE_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/icon-with-text/functions.php';