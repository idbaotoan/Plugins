<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

global $wpdb;

$currencies = get_option('wmcs_store_currencies');

// Delete Prices for each currency
foreach ($currencies as $currency) {
	// Delete product prices
	$query = "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ('_{$currency['currency_code']}_price', '_{$currency['currency_code']}_regular_price', '_{$currency['currency_code']}_sale_price')";
	$wpdb->query($query);
}

// Delete options
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'wmcs\_%';");