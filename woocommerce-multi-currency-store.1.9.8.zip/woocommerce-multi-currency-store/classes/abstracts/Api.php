<?php

namespace CodeNinjas\WMCS\Classes;

use CodeNinjas\WMCS;
use CodeNinjas\WMCS\Helpers; 
use CodeNinjas\WMCS\Settings;
use CodeNinjas\WMCS\Currency;

abstract class Api
{
	public function __construct()
	{
		$this->settings = Settings\getOption('wmcs_exchange_rate_source_info');
		$this->is_selected = Settings\getOption('wmcs_exchange_rate_source') == $this->id ? true : false;
	}
	
	public function __get($key)
	{
		switch($key){
			case 'id':
				return $this->id;
				break;
			case 'name':
				return $this->name;
				break;
			case 'endpoint':
				return $this->endpoint;
				break;
			default:
				return isset($this->settings[$this->name][$key]) ? $this->settings[$this->name][$key] : '';
				break;
		}
	}
	
	/**
	 *  Return an array of currency code supported by this API
	 */
	abstract function getSupportedCurrencies();
	
	
	/**
	 *  Make request to endpoint URL and return format success/error array 
	 *  
	 *  @since	1.9
	 */
	public function request($endpoint)
	{
		WMCS\Log('info', 'Checking exchange rates from '.$this->name.' | '.$endpoint);
		
		$response = wp_remote_get($endpoint, array('timeout' => 10));
		
		// Wordpress Error
		if(is_wp_error($response)){
			$this->getRatesFailed('WP ERROR | '.json_encode($response->errors));
			return false;
		}
		
		if($response){
			$body = Helpers\isJSON($response['body']) ? json_decode($response['body']) : $response['body'];
            
			// Not 200?
			if($response['response']['code'] != 200){
				$this->getRatesFailed($response['response']['code'].': '.$response['response']['message'].' | '.json_encode($body));
				return false;
			}
			
			// Check are OK, return body
			return array(
				'result' => 'success',
				'response' => $body
			);
		}		
		
		$this->getRatesFailed('UNKNOWN ERROR | '.json_encode($response));
		return false; // response wasn't something we're expecting
	}
	
	
	/**
	 *  Check is the passed in currency is supported by this API
	 *  
	 *  @param	string	$currency	The currency code to check
	 *  @return	bool	
	 *  @since	1.9
	 */
	public function isCurrencySupported($currency, $log_error = true) 
	{		
		$supported_currencies = $this->getSupportedCurrencies();
		if(!in_array($currency, $supported_currencies)){
			if($log_error){
				$this->getRatesFailed('Currency ('.$currency.') not supported by '.$this->name);
			}
			return false;
		}
		
		return true;
	}
	
	protected function getRatesFailed($error)
	{
		Currency\setLastChecked(false);
		WMCS\Log('error', "Getting rates from {$this->name} failed | {$error}");
	}
	
	protected function saveRates($rates = array())
	{
        Currency\setRates($rates);
        Currency\setLastChecked(true);
        WMCS\Log('info', "Exchange rates successfully saved.");
	}
	
	protected function recalculateRatesToBase($rates, $source_currency)
	{
		$base_currency = Currency\getBase();
		$base_rate = round(1 / $rates[$base_currency], 4);
		
		$rates = array_map(function($item) use($base_rate){
			return $item * $base_rate;
		}, $rates);
		
		unset($rates[$base_currency]);
		$rates[$source_currency] = $base_rate; // Add the rate for the source currency
		
		return $rates;
	}
	
	protected function roundRates($rates, $decimals = 4)
	{
		$rates = array_map(function($item) use($decimals){
			return round($item, $decimals);
		}, $rates);
		
		return $rates;
	}
	
	protected function checkAPIKey($log_error = true)
	{
		if(!$this->api_key){
			if($log_error){
				$this->getRatesFailed('API key not provided');
			}
			return false;
		}
		
		return true;
	}
}