<?php

namespace CodeNinjas\WMCS\Classes;

class Yahoo extends Api
{
	protected $id = 'Yahoo';
	protected $name = 'Yahoo Finance API';
	
	public function getRates()
	{	
		/**
		 *  Yahoo Finance deprecated in November 2017
		 */
		$this->getRatesFailed('Yahoo\'s Finance API has been deprecated. Please select another exchange rate source.');
		return false;
	}
	
	public function getSupportedCurrencies()
	{
		return array();
	}
}