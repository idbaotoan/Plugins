<?php

namespace CodeNinjas\WMCS\Classes;

use CodeNinjas\WMCS\Settings;
use CodeNinjas\WMCS\Currency;

class ExchangeRateAPI extends Api
{
	protected $id = 'ExchangeRateAPI';
	protected $name = 'ExchangeRate-API.com';
	protected $endpoint = 'https://v3.exchangerate-api.com/bulk/{{API_KEY}}/{{BASE_CURRENCY}}';
	
	public function getRates($base_currency = '')
	{
		if(!$base_currency){
			$base_currency = Currency\getBase();
		}
	
		if(	!Settings\isMultiCurrencyEnabled() || // Multi Currency disabled
			!$this->checkAPIKey() || // No API key
			!$this->isCurrencySupported($base_currency) // Base currency not support
		) return false;
		
		$endpoint = str_replace('{{BASE_CURRENCY}}', $base_currency, $this->endpoint);
		$endpoint = str_replace('{{API_KEY}}', $this->api_key, $endpoint);
		
		$request = $this->request($endpoint);
		
		if($request && isset($request['result']) && $request['result'] == 'success'){
			// Process the response we get from this API - Make sure the response itself is not an error/failed
			$response = $request['response'];
			if($response->result != 'success'){
				$this->getRatesFailed($response->error);
				return false;
			}
			
			// Format and save the rates
			$rates = (array)$response->rates;
			unset($rates[$response->from]);
			$rates = $this->roundRates($rates);
			$this->saveRates($rates);
			
			return true;
		}
		
		return false;
	}
	
	/**
	 *  Currencies supported by this API
	 *  Theres no API call that can get the supported currencies without an API key, so we'll just
	 *  check this list periodically and keep it up to date
	 *  https://www.exchangerate-api.com/supported-currencies
	 */
	public function getSupportedCurrencies()
	{
		$json = '{"result":"success","timestamp":1512510811,"from":"USD","rates":{"USD":1,"AED":3.67251031,"AMD":484.160004,"ANG":1.78,"AOA":165.098007,"ARS":17.278999,"AUD":1.31189619,"BBD":2.00,"BDT":82.25367178,"BGN":1.65089206,"BHD":0.37716973,"BRL":3.2380263,"BSD":1.00,"BWP":10.2725,"BYN":2.02,"CAD":1.26710947,"CHF":0.98592055,"CLP":653.809998,"CNY":6.61570365,"COP":2994.00,"CZK":21.64361052,"DKK":6.28188811,"DOP":48.220001,"EGP":17.69412712,"ETB":27.049999,"EUR":0.8440226,"FJD":2.091,"GBP":0.7432631,"GHS":4.43451122,"GTQ":7.34,"HKD":7.81558956,"HNL":23.482,"HRK":6.3761326,"HUF":265.03903687,"IDR":13503.82118268,"ILS":3.49778758,"INR":64.3756533,"IQD":1181.00,"IRR":35142.36254533,"ISK":103.400002,"JMD":124.809998,"JOD":0.70772758,"JPY":112.55922438,"KES":102.99387123,"KHR":4027.00,"KRW":1085.7589264,"KWD":0.30184585,"KZT":333.059998,"LAK":8310.00,"LBP":1511.00,"LKR":153.40359325,"MAD":9.4335,"MKD":51.779999,"MMK":1363.82268009,"MUR":33.61734588,"MXN":18.69191062,"MYR":4.05917148,"NAD":13.441,"NGN":335.03152581,"NOK":8.28988404,"NZD":1.4530784,"OMR":0.3847029,"PAB":1.00,"PEN":3.23496605,"PGK":3.25623968,"PHP":50.60750258,"PKR":105.22140479,"PLN":3.55062781,"PYG":5650.799805,"QAR":3.64019008,"RON":3.90816803,"RSD":100.3209,"RUB":58.74980877,"SAR":3.75015593,"SCR":13.62606008,"SEK":8.39933423,"SGD":1.346674,"THB":32.59635706,"TJS":8.8139,"TND":2.48,"TRY":3.85856826,"TTD":6.6295,"TWD":30.01116305,"TZS":2234.00,"UAH":27.09,"UYU":28.950001,"UZS":8090.00,"VEF":9.97,"VND":22659.8071777,"XAF":554.200012,"XCD":2.70,"XOF":578.609985,"XPF":100.330002,"ZAR":13.49825093,"ZMW":10.28974239}}';
		$json = json_decode($json);
		$currencies = array_keys((array)$json->rates);
		
		return $currencies;
	}
}