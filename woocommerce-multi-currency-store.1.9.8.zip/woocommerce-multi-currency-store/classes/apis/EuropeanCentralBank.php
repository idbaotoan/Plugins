<?php
namespace CodeNinjas\WMCS\Classes;

use CodeNinjas\WMCS;
use CodeNinjas\WMCS\Currency;

class EuropeanCentralBank extends Api
{
	protected $id = 'EuropeanCentralBank';
	protected $name = 'European Central Bank';
	protected $endpoint = 'http://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml';
	
	/**
	 *  Get the rates
	 *  
	 *  @since	1.9
	 */
	public function getRates()
	{	
		$base_currency = Currency\getBase();
		
		// Check base currency is supported
		if(!$this->isCurrencySupported($base_currency)) return false;
		
		WMCS\Log('info', 'Checking exchange rates from '.$this->name.' | '.$this->endpoint);
		
		$xml = @simplexml_load_file($this->endpoint);
		
		if(!isset($xml->Cube->Cube) || empty($xml->Cube->Cube)){
			$this->getRatesFailed('XML attribute not available or empty');
			return false;
		}
		
		$rates = array();
		foreach($xml->Cube->Cube->Cube as $item){
			$code = $item->attributes()['currency']->__toString();
			$rate = $item->attributes()['rate']->__toString();
			$rates[$code] = $rate;
		}
		
		if($base_currency != 'EUR'){
			$rates = $this->recalculateRatesToBase($rates, 'EUR');
		}
		
		$rates = $this->roundRates($rates);
		$this->saveRates($rates);
		
		return true;
	}
	
	
	/**
	 *  Currencies supported by this API
	 *  
	 *  @since	1.9
	 */
	public function getSupportedCurrencies()
	{
		$currencies = array('EUR', 'USD', 'JPY', 'BGN', 'CZK', 'DKK', 'GBP', 'HUF', 'PLN', 'RON', 'SEK', 'CHF', 'NOK', 'HRK', 'RUB', 'TRY', 'AUD', 'BRL', 'CAD', 'CNY', 'HKD' , 'IDR' , 'ILS', 'INR', 'KRW', 'MXN', 'MYR', 'NZD', 'PHP', 'SGD', 'THB', 'ZAR');
		
		return $currencies;
	}
}