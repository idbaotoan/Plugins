<?php

/**
 * Update check
 */
include_once WMCS_DIR . '/lib/plugin-update-checker/plugin-update-checker.php';
$wmcs_update_checker = \PucFactory::buildUpdateChecker(
    'http://updates2.codeninjas.co/?action=get_metadata&slug=woocommerce-multi-currency-store',
    WMCS_BASE_FILE,
    'woocommerce-multi-currency-store'
);
