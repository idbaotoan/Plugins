<?php

namespace CodeNinjas\WMCS\Admin\Reports;

use CodeNinjas\WMCS\Currency;

add_action('wc_reports_tabs', __NAMESPACE__ . '\outputCurrencyDropdown');

add_filter('woocommerce_currency', __NAMESPACE__ . '\filterCurrency');
add_filter('woocommerce_reports_get_order_report_data_args', __NAMESPACE__ . '\modifyReportQuery');



/**
 *  Output currency switcher in reports
 *  
 *  @since 1.2.7
 */
function outputCurrencyDropdown()
{
	$base_currency = Currency\getBase();
    
    if (isset($_GET['wmcs_currency']) && $_GET['wmcs_currency']) {
        $selected_currency = $_GET['wmcs_currency'];
    }
    else {
        $selected_currency = $base_currency;
    }
	
	$store_currencies = Currency\getStoreCurrencies();
	
	echo '<label style="float: right;"><strong>'.__('Currency', 'woocommerce').':</strong> ';
	echo '<select id="wmcs_currency_switcher">';
	
	//base
	$selected = ( $selected_currency == $base_currency ) ? 'selected="selected"' : '';
	echo '<option value="' . \add_query_arg( 'wmcs_currency', $base_currency ).'" '.$selected.'>'.$base_currency.'</option>';
	
	//additional
	foreach($store_currencies as $currency){
		$selected = ( $currency['currency_code'] == $selected_currency ) ? 'selected="selected"' : '';
		echo '<option value="' . \add_query_arg( 'wmcs_currency', $currency['currency_code'] ).'" '.$selected.'>'.$currency['currency_code'].'</option>';
	}
	
	echo '</select></label>';
}


/**
 *  Replace Woocommerces currency is a currency has been selected
 *  
 *  @since 1.2.7
 */
function filterCurrency($currency)
{
	if (isset($_GET['wmcs_currency']) && $_GET['wmcs_currency']) {
		return $_GET['wmcs_currency'];
	}
	
	return $currency;
}


/**
 *  Replace the report data args and add the chosen currency
 *  
 *  @params array   $args
 *  @return array
 *  @since  1.2.7
 */
function modifyReportQuery($args)
{
	
	$currency = isset($_GET['wmcs_currency']) && $_GET['wmcs_currency'] ? $_GET['wmcs_currency'] : \get_woocommerce_currency();
        
	$where = [
		[
			'meta_key'      => '_order_currency',
			'meta_value'    => $currency,
			'operator'      => '='
		]
	];
	
	if (array_key_exists('where_meta', $args)) {
		$args['where_meta'] = array_merge($args['where_meta'], $where);
		$args['where_meta']['relation'] = 'AND';
	}
    else {
		$args['where_meta'] = $where;
	}
	
	return $args;
}   
