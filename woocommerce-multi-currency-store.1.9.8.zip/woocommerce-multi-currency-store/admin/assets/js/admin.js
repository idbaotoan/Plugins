jQuery(document).ready(function(){				
        jQuery('#wmcs_currency_switcher').on('change', function () {            
            var url = jQuery('#wmcs_currency_switcher').val()
            if (url) {
                window.location = url; 
            }
            return false;
        });

});


