<?php

delete_option('wmcs_exchange_rate_schedule');