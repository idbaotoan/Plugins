<?php

namespace CodeNinjas\WMCS\Admin\Dashboard;

use CodeNinjas\WMCS\Currency;

add_action('woocommerce_after_dashboard_status_widget', __NAMESPACE__ . 'modifyStatusWidget');


/**
 *  Modify the dashboard widget to show additonal currency sales also
 *  Copied from woocommerce/includes/admin/reports/class-wc-report-sales-by-date.php->query_report_data()
 *  
 *  @params array   $reports 
 *  @since 1.2.7
 */
function modifyStatusWidget($reports)
{
	$output = '';
	
	$store_currencies = Currency\getStoreCurrencies();
	
	if($store_currencies){
		
		$base_currency = Currency\getBase();
		$currencies = array_merge([$base_currency], array_keys($store_currencies));
		
		foreach ($currencies as $currency) {
			add_filter('woocommerce_reports_get_order_report_data_args', function($args) use ($currency){
				$args['where_meta'] = array(
					array(
						'meta_key' => '_order_currency',
						'meta_value' => $currency,
						'operator' => '='
					)
				);
				
                return $args;
			});

			$sales_by_date                 = new \WC_Report_Sales_By_Date();
			$sales_by_date->start_date     = strtotime( date( 'Y-m-01', current_time( 'timestamp' ) ) );
			$sales_by_date->end_date       = current_time( 'timestamp' );
			$sales_by_date->chart_groupby  = 'day';
			$sales_by_date->group_by_query = 'YEAR(posts.post_date), MONTH(posts.post_date), DAY(posts.post_date)';
			$report_data = $sales_by_date->get_report_data();

			$reports_link = admin_url("admin.php?page=wc-reports&tab=orders&range=month&wmcs_currency={$currency}");
			$output .= '<a href="'.$reports_link.'" style="width: 45%; float: left;">';
			$output .= sprintf( __( "<strong>%s</strong> net %s sales this month", 'woocommerce' ), wc_price( $report_data->net_sales, array('currency' => $currency) ), $currency );
			$output .= '</a>';
		}

		?>

		<script type="text/javascript">
			jQuery(function() {
				jQuery('#woocommerce_dashboard_status .sales-this-month .wc_sparkline').remove(); //remove the graph
				jQuery('#woocommerce_dashboard_status .sales-this-month').html('<?php echo $output; ?>');
			});
		</script>

		<?php
	}
}
