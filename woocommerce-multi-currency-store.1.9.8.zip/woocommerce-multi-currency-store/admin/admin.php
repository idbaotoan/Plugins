<?php 

namespace CodeNinjas\WMCS\Admin;

add_action('extra_plugin_headers', __NAMESPACE__ . '\addHeaders');
add_action('admin_enqueue_scripts', __NAMESPACE__ . '\enqueue_scripts');

add_filter('plugin_action_links_' . \plugin_basename(WMCS_BASE_FILE), __NAMESPACE__ . '\addActionLinks');

/**
 *  Add extra plugin header info
 *  
 *  @param  array   $headers
 *  @return array
 *
 *  @since  1.0
 *  @action extra_plugin_headers
 */
function addHeaders($headers)
{
    $headers['Documentation URI'] = 'Documentation URI';
    
    return $headers;	
}

/**
 *  Add action link to the plugins page.
 *
 *  @param  array   $links
 *  @return array
 *
-*  @since  1.0
*   @action plugin_action_links_WMCS_BASE_FILE
 */
function addActionLinks($links)
{
    $pluginData = \get_plugin_data(WMCS_BASE_FILE);

    $links = array_merge(
        $links,
        [
            'documentation' => '<a href="' . $pluginData['Documentation URI'] . '">'.__('Documentation', 'woocommerce').'</a>'
        ]
    );
    
    return $links;
}

/**
 * Enqueue styles and scripts
 *
 * @since     1.0.0
 */
function enqueue_scripts()
{
	wp_enqueue_script('wmcs-admin-js', plugins_url('assets/js/admin.js', __FILE__), array('jquery'));
            
	$screen = get_current_screen();
	switch ($screen->id) {
		case 'woocommerce_page_wc-settings';
			wp_enqueue_script( 'wmcs-settings-js', plugins_url( 'assets/js/settings.js', __FILE__ ), array( 'jquery' ) );
			wp_enqueue_style( 'wmcs-settings-css', plugins_url( 'assets/css/settings.css', __FILE__ ) );
			break;
            
		case 'product';
			wp_enqueue_style( 'wmcs-product-css', plugins_url( 'assets/css/product.css', __FILE__ ) );
			break;
	}
}
