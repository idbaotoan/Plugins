<?php

namespace CodeNinjas\WMCS\Admin\Product;

use CodeNinjas\WMCS\Settings;
use CodeNinjas\WMCS\Currency;


if (Settings\isMultiCurrencyEnabled()) {
    add_action('woocommerce_product_options_pricing', __NAMESPACE__ . '\outputCurrencyPriceFields');
    add_action('save_post', __NAMESPACE__ . '\saveCurrencyPrices');
    add_action('woocommerce_product_after_variable_attributes', __NAMESPACE__ . '\outputVariationCurrencyPriceFields', 10, 3);
    add_action('woocommerce_save_product_variation', __NAMESPACE__ . '\saveVariationCurrencyPrices', 10, 2);
}

/*
|--------------------------------------------------------------------------
| Functions
|--------------------------------------------------------------------------
*/

function outputCurrencyPriceFields()
{
	global $thepostid, $post;
		
	$product = \wc_get_product($thepostid);
	if ($product->get_type() == 'variable') {
        return;
    }
	
	$regular_price = \get_post_meta($thepostid, '_regular_price', true);
	$sale_price = \get_post_meta($thepostid, '_sale_price', true);
	
	$store_currencies = Currency\getStoreCurrencies();
	
	if (!empty($store_currencies)) {
	
		echo '</div>';
		echo '<div class="options_group wmcs_currency_pricing show_if_simple show_if_external">';
		
		foreach ($store_currencies as $currency => $data) {
			
			//regular price
			$converted_regular_price = '';
			if ($regular_price) {
				$converted_regular_price = Currency\convertPrice($regular_price, $currency);
				$converted_regular_price = 'Converted regular price - ' . \wc_price($converted_regular_price, array('currency' => $currency));
			}
            
			\woocommerce_wp_text_input([
				'id' => '_'.$currency.'_regular_price',
				'data_type' => 'price',
				'label' => $currency . ' ' . __( 'Regular Price', 'woocommerce' ) . ' (' . \get_woocommerce_currency_symbol($currency) . ')',
				'description' => $converted_regular_price
			]);
			
			//sale price
			$converted_sale_price = '';
			if ($sale_price) {
				$converted_sale_price = Currency\convertPrice( $sale_price, $currency );
				$converted_sale_price = 'Converted sale price - ' . \wc_price($converted_sale_price, array('currency' => $currency));
			}
			
			\woocommerce_wp_text_input([
				'id' => '_'.$currency.'_sale_price',
				'data_type' => 'price',
				'label' => $currency . ' ' . __( 'Sale Price', 'woocommerce' ) . ' (' . \get_woocommerce_currency_symbol($currency) . ')',
				'description' => $converted_sale_price
			]);
		}
	
	}
}


function saveCurrencyPrices($post_id)
{
	if (!$post_id) {
        return;        
    }
    
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
	
	$store_currencies = Currency\getStoreCurrencies();
	foreach ($store_currencies as $currency => $data) {
		$regular_price = isset($_POST['_'.$currency.'_regular_price']) ? $_POST['_'.$currency.'_regular_price'] : '';
		$sale_price = isset($_POST['_'.$currency.'_sale_price']) ? $_POST['_'.$currency.'_sale_price'] : '';
		$price = $sale_price ? $sale_price : $regular_price;
		
		\update_post_meta($post_id, '_'.$currency.'_regular_price', $regular_price);
		\update_post_meta($post_id, '_'.$currency.'_sale_price', $sale_price);
		\update_post_meta($post_id, '_'.$currency.'_price', $price);	
	}
}


function outputVariationCurrencyPriceFields($loop, $variation_data, $variation)
{ 
	$store_currencies = Currency\getStoreCurrencies();
		
	if (!empty($store_currencies)) {
		
		echo '<div class="variable_pricing">';
		
		foreach ($store_currencies as $currency => $data) {
			
			//regular price
			$regular_price = \get_post_meta($variation->ID, '_regular_price', TRUE);
			$converted_regular_price = '';
			if($regular_price){
				$converted_regular_price = Currency\convertPrice($regular_price, $currency);
				$converted_regular_price = 'Converted regular price - ' . \wc_price($converted_regular_price, array('currency' => $currency));
			}
			echo '<p class="form-row form-row-first">';	
			echo '<label>' . $currency . ' ' . __('Regular Price:', 'woocommerce') . ' (' . \get_woocommerce_currency_symbol($currency) . ') </label>';
			echo '<input type="text" size="5" name="currency_prices['.$loop.']['.$currency.'][regular]" value="' . \get_post_meta($variation->ID, "_{$currency}_regular_price", TRUE) . '" class="wc_input_price" />';
			echo '<small>'.$converted_regular_price.'</small>';
			echo '</p>';
			
			
			//sale price
			$sale_price = \get_post_meta($variation->ID, '_sale_price', TRUE);
			$converted_sale_price = '';
			if ($sale_price) {
				$converted_sale_price = Currency\convertPrice( $sale_price, $currency );
				$converted_sale_price = 'Converted sale price - ' . \wc_price($converted_sale_price, array('currency' => $currency));
			}
			echo '<p class="form-row form-row-last">';	
			echo '<label>' . $currency . ' ' . __('Sale Price:', 'woocommerce') . ' (' . \get_woocommerce_currency_symbol($currency) . ') </label>';
			echo '<input type="text" size="5" name="currency_prices['.$loop.']['.$currency.'][sale]" value="' . get_post_meta($variation->ID, "_{$currency}_sale_price", TRUE) . '" class="wc_input_price" />';
			echo '<small>'.$converted_sale_price.'</small>';
			echo '</p>';
		}
		
		echo '</div>';
	}
}


function saveVariationCurrencyPrices($variation_id, $loop)
{
	if (!$variation_id) {
        return;        
    }
    
	if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
	
	if (isset($_POST['currency_prices'])) {
		$currency_prices = $_POST['currency_prices'][$loop]; 
		foreach ($currency_prices as $currency => $prices) {
			$regular_price = $prices['regular'];
			$sale_price = $prices['sale'];
			$price = $sale_price ? $sale_price : $regular_price;
			
			\update_post_meta( $variation_id, '_'.$currency.'_regular_price', $regular_price );
			\update_post_meta( $variation_id, '_'.$currency.'_sale_price', $sale_price );
			\update_post_meta( $variation_id, '_'.$currency.'_price', $price );	
		}
	}
}
