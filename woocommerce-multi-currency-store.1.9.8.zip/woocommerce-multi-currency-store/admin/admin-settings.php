<?php

namespace CodeNinjas\WMCS\Admin\Settings;

use CodeNinjas\WMCS\Helpers;
use CodeNinjas\WMCS\Settings;
use CodeNinjas\WMCS\Currency;
use CodeNinjas\WMCS\Cron;

const SETTINGS_TAB_ID = 'multi_currency';
const SETTINGS_TAB_NAME = 'Multi Currency';

add_action('admin_init', __NAMESPACE__ . '\saveSettings');
add_action('admin_init', __NAMESPACE__ . '\outputAdminNotice');
add_action('woocommerce_sections_' . SETTINGS_TAB_ID, __NAMESPACE__ . '\outputSections');
add_action('woocommerce_settings_' . SETTINGS_TAB_ID, __NAMESPACE__ . '\outputSettings');
add_action('woocommerce_admin_field_wmcs_store_currencies', __NAMESPACE__ . '\outputSetting_wmcs_store_currencies');
add_action('woocommerce_admin_settings_sanitize_option__wmcs_store_currencies', __NAMESPACE__ . '\saveSetting_wmcs_store_currencies');
add_action('woocommerce_admin_field_wmcs_exchange_rate_source_info', __NAMESPACE__ . '\outputSetting_wmcs_exchange_rate_source_info');
add_action('woocommerce_admin_settings_sanitize_option_wmcs_exchange_rate_source_info', __NAMESPACE__ . '\saveSetting_wmcs_exchange_rate_source_info');

add_filter('woocommerce_settings_tabs_array', __NAMESPACE__ . '\addSettingsTab', 30);


/**
 *  Save the settings manually here instead of on woocommerce_update_options so that
 *  we can get the rates using the new settings and output an admin notice if something fails
 *  (woocommerce_update_options runs after admin_notices) 
 *
 *  @since  1.9
 *  @action admin_init
 */
function saveSettings()
{
    if (!isSettingsPage() || empty($_POST)) {
        return;
    }

    if (!function_exists('woocommerce_update_options')) {
        include \trailingslashit(WP_PLUGIN_DIR) . 'woocommerce/admin/settings/settings-save.php';
    }
	
    $sections = Settings\getSections();
    $current_section = empty($_REQUEST['section']) ? $sections[0] : \sanitize_text_field(urldecode($_REQUEST['section']));
    $sectionOptions = Settings\getSectionOptions($current_section);
    \woocommerce_update_options($sectionOptions);	
	
	//delete variation product prices transients
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE '%s'", '_transient_wc_var_prices%' ) );
	$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE '%s'", '_transient_timeout_wc_var_prices%' ) );
	
	// See if Multi Currency is/has been disabled
	if(Settings\isMultiCurrencyEnabled() == false){
		Cron\removeCron(); // Remove the cron
		return;
	}
	
	$source = Currency\getSource();
	if($source == 'custom'){
		// Set last checked to be success
		Currency\setLastChecked(true);
	}
	else{
		// Check the rates
		$status = $source->getRates();
			
		// Reschedule the cron
		Cron\reScheduleCron($source->schedule);	
	}
}

/**
 *  Output admin notice if needed on settings page
 *
 *  @since  1.9.8
 *  @action admin_init
 */
function outputAdminNotice()
{	
    if (Settings\isMultiCurrencyEnabled() == false) {
        return;
    }
    
    $source = Currency\getSource();
    
    if ($source == 'custom') {
        return;
    }
    
    $last_checked = Currency\getLastChecked();
    if ($last_checked['status'] != 'success') { // Last checked failed
        $log_url = admin_url('admin.php?page=wc-status&tab=logs');
        Helpers\addAdminNotice('error', 'It looks like something went wrong when trying to get the latest exchange rates.  Please check the <a href="'.$log_url.'">logs</a> for more information. (Woocommerce Multi Currency Store)');
    }
    else { // Check if store currencies are supported by API			
        $store_currencies = Currency\getStoreCurrencies();
        if ($store_currencies) {
            foreach ($store_currencies as $currency) {
                if (!$source->isCurrencySupported($currency['currency_code'], false) && $currency['exchange_rate_type'] == 'live'){ // Currency not supported and exchange rate set to live
                    $store_currencies_url = admin_url('admin.php?page=wc-settings&tab=multi_currency&section=additional_currencies');
                    Helpers\addAdminNotice('warning', 'Some of the currencies added to your store are not supported by the selected exchange rate source. Please <a href="'.$store_currencies_url.'">set a custom exchange rate for these currencies</a>.');
                    break;
                }
            }
        }
    }
}


/**
 *  Add our tab for Woocommerce's tabs
 *
 *  @param  array   $tabs
 *  @return array
 *
 *  @since  1.9
 *  @filter woocommerce_settings_tabs_array
 */
function addSettingsTab($tabs)
{
	$tabs[SETTINGS_TAB_ID] = SETTINGS_TAB_NAME;
	
	return $tabs;
}


/**
 *  Output sections
 *
 *  @since  1.9
 *  @action woocommerce_sections_{SETTINGS_TAB_ID}
 */
function outputSections()
{
	$sections = Settings\getSections();
	$current_section = empty($_REQUEST['section']) ? $sections[0] : sanitize_text_field(urldecode($_REQUEST['section']));
	$admin_url = admin_url('admin.php?page=wc-settings&tab=' . SETTINGS_TAB_ID);
	
	//output section links
	$section_links = array();
	foreach ($sections as $section) {
		$title = ucwords(str_replace('_', ' ', $section));
		$class = $section == $current_section ? 'current' : '';
		$link = \add_query_arg( 'section', $section, $admin_url );
		$section_links[] = "<a href=\"{$link}\" class=\"{$class}\">{$title}</a>";
	}

	echo '<ul class="subsubsub"><li>' . implode( ' | </li><li>', $section_links ) . '</li></ul><br class="clear" /><hr />';
}


/**
 *  Output settings
 *
 *  @since  1.9 
 *  @action woocommerce_settings_{SETTINGS_TAB_ID}
 */
function outputSettings()
{	
	$sections = Settings\getSections();
	$current_section = empty($_REQUEST['section']) ? $sections[0] : sanitize_text_field(urldecode($_REQUEST['section']));
	$options = Settings\getSectionOptions($current_section);
	
	$source = Currency\getSource();
	if(isset($options['wmcs_exchange_rate_source']) && $source != 'custom'){
		$rates_data = Currency\getLastChecked();
		$last_checked_date = date(\get_option('date_format'), $rates_data['last_checked']);
		$last_checked_time = date(\get_option('time_format'), $rates_data['last_checked']);
		
		$status = isset($rates_data['status']) && $rates_data['status'] === 'success' ? true : false; 
		
		$desc = '<strong>';
		$desc .= __('Last checked', 'woocommerce');
		$desc .= ': </strong> '.$last_checked_date.' at '.$last_checked_time.'. <strong>';
		$desc .= __('Status', 'woocommerce');
		$desc .= ':</strong> ';
		$desc .= $status ? '<span style="color: green;">'.__('OK!', 'woocommerce').'</span>' : '<span style="color: red;">'.__('Failed!', 'woocommerce').'</span>';
		
		$options['wmcs_exchange_rate_source']['desc'] = $desc;
	}
	
	\woocommerce_admin_fields($options);
}




/**
 *  Output custom wmcs_store_currencies setting type
 *
 *  @params array   $values
 *
 *  @since  1.9
 *  @action woocommerce_admin_field_wmcs_store_currencies
 */
function outputSetting_wmcs_store_currencies($values)
{
	extract($values);	
	$store_currencies = Currency\getStoreCurrencies();
	
	$currency_table_rows = '';
	foreach($store_currencies as $currency){
		$currency_table_rows .= getCurrencyTableRowHtml($currency);
	}
	
	include 'views/settings-store-currencies.phtml';
	
	?>
	<script type="text/javascript">
	
		jQuery('#wmcs_settings_add_currency').click(function(){
			jQuery('#wmcs_currencies').append('<?php echo trim(preg_replace('/\r|\n/', '', getCurrencyTableRowHtml())); ?>'); //need to remove new lines otherwise get unterminated string literal error
			wmcs_init_chosen_select();
		});
		
		
	</script>
	<?php
}


/**
 *  Save options for custom wmcs_store_currencies setting type
 *
 *  @since  1.9
 *  @action woocommerce_admin_settings_sanitize_option__wmcs_store_currencies
 */
function saveSetting_wmcs_store_currencies()
{
	if (empty($_POST)) {
        return false;
    }
	
	//sort currencies into their own array
	$sorted_currencies = array();
	if (isset($_POST['wmcs_store_currencies'])) {
		foreach ($_POST['wmcs_store_currencies'] as $k => $v) {
			foreach ($v as $key => $value) {
				$sorted_currencies[$key][$k] = $value; //$sorted_currencies[0]['currency_code'] = 'GBP';
			}
		}
	}
	
	//put currency code as the key for easy searching and do some checks
	$insert = array();
	foreach ($sorted_currencies as $currency) {
		
		//Some validation
		$currency['decimal_places'] = (int)$currency['decimal_places'];
		$currency['rounding_to'] = (int)$currency['rounding_to'];
		$currency['exchange_rate_value'] = (float)$currency['exchange_rate_value'];
		$currency['price_format'] = !empty($currency['price_format']) ? $currency['price_format'] : '[currency_symbol][price]';
	
		$insert[$currency['currency_code']] = $currency;
	}
	
	\update_option('wmcs_store_currencies', $insert);
}


/**
 *  Output custom wmcs_exchange_rate_source_info setting type
 *
 *  @params array   $values
 *
 *  @since  1.9
 *  @action woocommerce_admin_field_wmcs_exchange_rate_source_info
 */
function outputSetting_wmcs_exchange_rate_source_info($values)
{
	$schedules = array_reverse(Cron\getSchedules());
	$base = Currency\getBase();
	$sources = Currency\getAllSources();
	
	include 'views/settings-exchange-source-info.phtml';
}


/**
 *  Save options for custom wmcs_exchange_rate_source_info setting type
 *
 *  @since  1.9
 *  @action woocommerce_admin_settings_sanitize_option_wmcs_exchange_rate_source_info
 */
function saveSetting_wmcs_exchange_rate_source_info($option)
{
	\update_option('wmcs_exchange_rate_source_info', $_POST['wmcs_exchange_rate_source_info']);
}




/**
 *  Checks if we're on the settings page for this plugin
 */
function isSettingsPage()
{
	if (isset($_GET['page']) && $_GET['page'] == 'wc-settings' && isset($_GET['tab']) && $_GET['tab'] == SETTINGS_TAB_ID) {
		return true;
	}
	
	return false;
}


function getCurrencyTableRowHtml($currency = array())
{		
	$defaults = array(
		'currency_code' => '',
		'price_format' => '[currency_symbol][price]',
		'thousand_separator' => ',',
		'decimal_separator' => '.',
		'decimal_places' => '2',
		'rounding_type' => 'none',
		'rounding_to' => '2',
		'exchange_rate_type' => 'live',
		'exchange_rate_value' => '1',
	);
	$currency = \wp_parse_args( $currency, $defaults );
	
	$source_is_custom = Currency\getSource() === 'custom' ? true : false;
	
	$base_currency_code = \get_option('woocommerce_currency');
	//$live_exchange_rates = get_option( 'wmcs_live_exchange_rates', array( ) );
	$live_exchange_rates = Currency\getRates();
	$currencies_live_rate = array_key_exists($currency['currency_code'], $live_exchange_rates) ? $live_exchange_rates[$currency['currency_code']] : FALSE;
	
	//Currency select
	$currency_select_options = '';
	foreach (\get_woocommerce_currencies() as $code => $name) {
		if($code != $base_currency_code){ //don't want base currency to be selectable
			$selected = ( $code == $currency['currency_code'] ) ? 'selected="selected"' : '';  
			$currency_select_options .= '<option value="'.$code.'" '.$selected.'>' . $name . ' (' . \get_woocommerce_currency_symbol( $code ) . ')</option>';
		}
	}
	
	//round type
	$rounding_types = array( 'none', 'up', 'down' );
	$rounding_types_options = '';
	foreach ($rounding_types as $type) {
		$selected = ( $type == $currency['rounding_type'] ) ? 'selected="selected"' : '';  
		$rounding_types_options .= '<option value="'.$type.'" '.$selected.'>'.ucwords($type).'</option>';
	}
	$rounding_type_show_adds = ( $currency['rounding_type'] == $defaults['rounding_type'] ) ? 'display: none;' : '';
	
	// Exchange rate type drop down
	$exchange_type_dropdown = '<select class="wmcs_exchange_rate_type" ';
	$exchange_type_dropdown .= 'name="wmcs_store_currencies[exchange_rate_type][]" ';
	$exchange_type_dropdown .= 'onchange="toggleAddOpts(this, jQuery(this).val());" ';
	$exchange_type_dropdown .= $source_is_custom ? 'style="display: none;"' : '';
	$exchange_type_dropdown .= '>';
	
	$live_selected = $currency['exchange_rate_type'] == 'live' ? 'selected="selected"' : '';
	$exchange_type_dropdown .= '<option value="live" '.$live_selected.'>Use live rates</option>';
	
	$custom_selected = $currency['exchange_rate_type'] == 'custom' ? 'selected="selected"' : '';
	$exchange_type_dropdown .= '<option value="custom" '.$custom_selected.'>Use custom rates</option>';
	
	$exchange_type_dropdown .= '</select>';
	
	$exchange_type_dropdown .= '<div class="custom_exchange_rate" ';
	$exchange_type_dropdown .= $currency['exchange_rate_type'] == 'live' && !$source_is_custom ? 'style="display: none;"' : '';
	$exchange_type_dropdown .= '> 1 '.$base_currency_code.' = <input type="text" style="width: 60px;" name="wmcs_store_currencies[exchange_rate_value][]" value="'.$currency['exchange_rate_value'].'" /> '.$currency['currency_code'];
	$exchange_type_dropdown .= '</div>';
	
	$return = '
	<tr>
		<td class="currency" width="20%">
			<select style="margin-bottom: 10px;" class="wmcs_chosen_select" name="wmcs_store_currencies[currency_code][]">'.$currency_select_options.'</select>';
	
	if (!$source_is_custom) {
		if ( $currencies_live_rate !== FALSE ) {
		$return .= '
				<div class="exchange-rate" style="margin-top: 10px;">
					<span class="rate">Live rate: 1 '.$base_currency_code.' = '.$currencies_live_rate.'</span>
				</div>';
		} 
		else {
			if($currency['currency_code'] && !array_key_exists($currency['currency_code'], $live_exchange_rates) && $currency['exchange_rate_type'] == 'live'){
				$return .= '
					<div class="exchange-rate" style="margin-top: 10px;">
						<span class="description" style="color: #a00; font-weight: bold;">Currency not available from source. Please set a custom rate.</span>
					</div>';
			}
		}
	}
	//<select style="width: 100%;" name="wmcs_store_currencies[position][]">'.$currency_position_options.'</select>
	$return .= '
			<div class="submitbox" style="margin-top: 10px;">
				 <a class="submitdelete" onclick="jQuery(this).parent().parent().parent().remove();" style="vertical-align: bottom;">Remove Currency</a>
			</div>
		</td>
		
		<td class="currency_details">
			<table width="100%">					
				<tr>
					<td>Price Format <a class="tips" data-tip="How the price will be displayed.  Use the tags and any additonal text to create the price output. Defaults to [currency_symbol][price]">[?]</a></td>
					<td colspan="3">
						<input style="width:100%;" type="text" name="wmcs_store_currencies[price_format][]" value="'.$currency['price_format'].'" />
						<p class="description"><strong>Tags: </strong>[price], [currency_symbol], [currency_code]</p>
					</td>
					
				</tr>
				<tr>
					<td>Thousands Separator <a class="tips" data-tip="The thousands separator for the currency">[?]</a></td>
					<td><input style="width: 50px;" type="text" name="wmcs_store_currencies[thousand_separator][]" value="'.$currency['thousand_separator'].'" /></td>
					<td>Decimal Separator <a class="tips" data-tip="The decimal separator for the currency">[?]</a></td>
					<td><input style="width: 50px;" type="text" name="wmcs_store_currencies[decimal_separator][]" value="'.$currency['decimal_separator'].'" /></td>
				</tr>
				<tr>
					<td>Decimal Places <a class="tips" data-tip="The number of digits after the decimal separator">[?]</a></td>
					<td><input style="width: 50px;" type="number" min="0" name="wmcs_store_currencies[decimal_places][]" value="'.$currency['decimal_places'].'" /></td>
					<td>Rounding <a class="tips" data-tip="When using dynamic conversion of the currency, choose whether to round the converted value up or down to the nearest while number">[?]</a></td>
					<td>
						<select class="wmcs_rounding_type" name="wmcs_store_currencies[rounding_type][]" onchange="toggleAddOpts(this, jQuery(this).val());">'.$rounding_types_options.'</select>
						<span class="rounding_options" style="'.$rounding_type_show_adds.'">
							to <input type="number" min="0" style="width: 50px;" name="wmcs_store_currencies[rounding_to][]" value="'.$currency['rounding_to'].'" /> decimal places
						</span>
					</td>
				</tr>
				<tr>
					<td>Exchange Rate <a class="tips" data-tip="Custom exchange rate to use when converting prices instead of live exchange rates">[?]</a></td>
					<td>
						'.$exchange_type_dropdown.'
					</td>
					<td></td>
					<td></td>
				</tr>
			</table>
		</td>
		
	</tr>';
	/*
	<select class="wmcs_exchange_rate_type" name="wmcs_store_currencies[exchange_rate_type][]" onchange="toggleAddOpts(this, jQuery(this).val());">'.$exchange_type_options.'</select>
	*/
	return $return;
}
