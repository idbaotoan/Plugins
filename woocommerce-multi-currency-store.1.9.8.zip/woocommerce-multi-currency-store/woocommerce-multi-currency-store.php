<?php

/**
 * Plugin Name:       Woocommerce Multi Currency Store Pro
 * Plugin URI:        http://codeninjas.co/plugins/woocommerce-multi-currency-store
 * Description:       Turn your single currency Woocommerce store into a multi currency store!
 * Version:           1.9.8
 * Author:            Code Ninjas
 * Author URI:        https://codeninjas.co
 * Documentation URI: https://codeninjas.co/help/wmcs/
 */
 
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

define('WMCS_BASE_FILE', __FILE__);

include_once('includes/wmcs.php');
