<?php

namespace CodeNinjas\WMCS;

define('WMCS_MIN_PHP_VERSION', 5.5);
define('WMCS_MIN_WP_VERSION', 4.5);
define('WMCS_MIN_WOOCOMMERCE_VERSION', 3.5);

define('WMCS_DIR', dirname(WMCS_BASE_FILE));
define('WMCS_SLUG', 'woocommerce-multi-currency-store');
define('WMCS_CURRENCY_COOKIE_NAME', 'code_ninjas_wmcs_currency');

include_once WMCS_DIR . '/includes/helpers.php';

use CodeNinjas\WMCS\Helpers;

register_activation_hook(WMCS_BASE_FILE, __NAMESPACE__ . '\activate'); 
register_deactivation_hook(WMCS_BASE_FILE, __NAMESPACE__ . '\deactivate'); 

add_action('plugins_loaded', __NAMESPACE__.'\checkWoocommerceActive');
add_action('woocommerce_loaded', __NAMESPACE__.'\init');


/**
 *  Plugin Activation - Check requirements before doing anything else
 *  
 *  @since	1.0
 */
function activate()
{
    if (isPhpValid() !== true || 
        isWpValid() !== true || 
        isWoocommerceValid() !== true) {
        
        ob_start();
        include WMCS_DIR . '/admin/views/wp-die/activation-error.phtml';
        $output = ob_get_clean();

        \wp_die($output, 'Activation Failed', array('back_link' => true));
    }
}


/**
 *  Plugin Deactivation
 *  
 *  @since	1.0
 */
function deactivate()
{
	do_action('wmcs_deactivate');
}


/**
 *  Check PHP version against requirements
 *  
 *  @return bool
 *  @since	1.9.8
 */
function isPhpValid()
{
    return version_compare(phpversion(), WMCS_MIN_PHP_VERSION, '>=');
}

/**
 *  Check WP version against requirements
 *  
 *  @return bool
 *  @since	1.9.8
 */
function isWpValid()
{
    global $wp_version;
    
    return version_compare($wp_version, WMCS_MIN_WP_VERSION, '>=');
}


/**
 *  Check if Woocommerce is installed, active and the correct version
 *  
 *  @return string|bool
 *  @since	1.9.8
 */
function isWoocommerceValid()
{
    $slug = 'woocommerce/woocommerce.php';
    
    if (!function_exists('is_plugin_active')) {
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }
    
    if (!\is_plugin_active($slug)) {
        return 'not_active';
    }
    
    $path = Helpers\pluginDirPath($slug);
    $data = \get_plugin_data($path);
    
    if (version_compare($data['Version'], WMCS_MIN_WOOCOMMERCE_VERSION, '<')) {
        return 'wrong_version';
    }
    
    return true;
}


/**
 *  Check if Woocommerce if active and deactive plugin is not
 *  
 *  @since	1.9.8
 */
function checkWoocommerceActive()
{
    if (isWoocommerceValid() === 'not_active') {
        
        $notice = '<strong>Woocommerce Multi Currency Store</strong> has been deactivated because <strong>Woocommerce</strong> is no longer active.';
        $notice .= '<br />Please active Woocommerce before reactivating Woocommerce Multi Currency Store';
        
        add_action('admin_notices', function() use ($notice){
            echo "<div class='notice notice-error'><p>{$notice}</p></div>";
        });
        
        deactivate_plugins(WMCS_BASE_FILE); 
    }
}


/**
 *  Include all files in the includes folder
 *  
 *  @since	1.9
 */
function loadIncludes()
{
	// Include common files
	foreach(glob(WMCS_APP.'*.php') as $file) {
		\CodeNinjas\includeFile($file);
	}
	
	// Include admin files
	if(\CodeNinjas\isRequest('admin')){
		foreach(glob(WMCS_APP.'admin/*.php') as $file) {
			\CodeNinjas\includeFile($file);
		}
	}
	
	// Include frontend files
	if(\CodeNinjas\isRequest('frontend') && isEnabled()){
		foreach(glob(WMCS_APP.'frontend/*.php') as $file) {
			\CodeNinjas\includeFile($file);
		}
	}
}


/**
 *  Entry point of the plugin.
 *  
 *  @since	1.9
 */
function init()
{
	// Common includes
    include_once WMCS_DIR . '/includes/autoload.php';
    include_once WMCS_DIR . '/includes/settings.php';
    include_once WMCS_DIR . '/includes/currency.php';
    include_once WMCS_DIR . '/includes/cron.php';
    include_once WMCS_DIR . '/includes/widgets.php';
    
    // Admin includes
    if (Helpers\isRequest('admin')) {
        include_once WMCS_DIR . '/admin/admin.php';
        include_once WMCS_DIR . '/admin/admin-updates.php';
        include_once WMCS_DIR . '/admin/admin-settings.php';
        include_once WMCS_DIR . '/admin/admin-dashboard.php';
        include_once WMCS_DIR . '/admin/admin-product.php';
        include_once WMCS_DIR . '/admin/admin-reports.php';
    }
    
    // Public includes
    if (Helpers\isRequest('frontend')) {
        include_once WMCS_DIR . '/frontend/frontend.php';
        include_once WMCS_DIR . '/frontend/frontend-cart.php';
        include_once WMCS_DIR . '/frontend/frontend-product.php';
        include_once WMCS_DIR . '/frontend/frontend-widgets.php';
    }
	
	do_action('wmcs_after_init');
}


/**
 *  Return the plugins cookie
 *  
 *  @since  1.9.7
 */
function getCookie()
{
    return isset($_COOKIE[WMCS_CURRENCY_COOKIE_NAME]) ? $_COOKIE[WMCS_CURRENCY_COOKIE_NAME] : false;
}


/**
 *  Set the plugins cookie with the passed in value
 *  
 *  @since  1.9.7
 */
function setCookie($value)
{
    \setcookie(WMCS_CURRENCY_COOKIE_NAME, $value, time()+60*60*24*30, '/');
}


/**
 *  Log messages to Woocommerce log
 *  
 *  @since	1.9
 */
function log($level, $message)
{
	$logger = \wc_get_logger();
	$logger->log($level, "| {$message}", array('source' => 'woocommerce-multi-currency-store'));
}