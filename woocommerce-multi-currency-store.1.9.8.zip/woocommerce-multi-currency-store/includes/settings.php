<?php

namespace CodeNinjas\WMCS\Settings;

use CodeNinjas\WMCS\Currency;


/**
 *  Return if multi currency is enabled in store
 *  
 *  @since	1.9
 */
function isMultiCurrencyEnabled()
{
	return \get_option('wmcs_enabled');
}


/**
 * Wrapper for WP get_option
 * If the option doesn't exist in the DB, return the defualt value instead
 *
 * @param   string  $option_name
 * @return  string
 * @since   1.9
 */
function getOption($option_name, $default_value = null)
{
    $option_value = \get_option($option_name, $default_value); 
	
    if (is_null($option_value)) { //get the default	
        $defaults = getOptionDefaults();
        if (array_key_exists($option_name, $defaults)) {
            $option_value = $defaults[$option_name];
        }
    }
    
	switch ($option_value) {
		case 'yes':
			return true;
		case 'no':
			return false;
	}
	
    return $option_value;
}


/**
 * Return all defaults for opitons
 *
 * @param string $optionName The option name whose default value to return
 * @staticvar   NULL|array  $defaults
 * @return      array
 * @since		1.9
 */
function getOptionDefaults()
{
    static $defaults = null;
    
    if (is_null($defaults)) {
        $defaults = [];
        foreach (getAllOptions(true) as $option) {
            if (isset( $option['id']) && isset($option['default'])) {
                $defaults[$option['id']] = $option['default'];
            }
        }
    }

    return $defaults;
}


function getSections()
{
	$options = getAllOptions();
    
	return array_keys($options);
}


function getSectionOptions($section)
{
	$options = getAllOptions();
    
	if (array_key_exists($section, $options)) {
		return $options[$section];
	}
	
	return [];
}


/**
 *  Plugins Options
 *  
 *  @since 1.9
 */
function getAllOptions($raw = false)
{
	$sources = array();
	foreach (Currency\getAllSources() as $source) {
		$sources[$source->id] = $source->name;
	}
	$sources['custom'] = __('Use custom defined rates', 'woocommerce');
	
	
	$options = [];
	
	//General
	$options['multi_currency_options'] = [
		[
            'title' => __( 'General', 'woocommerce' ),
            'type' => 'title',
            'desc' => '',
            'id' => 'wmcs_general_settings'
        ],
			
		[
			'title'   => __( 'Enabled', 'woocommerce' ),
			'desc'    => __( 'Enable multiple currencies in your store', 'woocommerce' ),
			'id'      => 'wmcs_enabled',
			'default' => 'no',
			'type'    => 'checkbox'
		],
		
		[
			'title'   => __( 'Enable GeoIp', 'woocommerce' ),
			'desc'    => __( 'Attempt to automatically determine customers country/currency', 'woocommerce' ),
			'id'      => 'wmcs_enable_geoip',
			'default' => 'yes',
			'type'    => 'checkbox'
		],
		
		[
            'type' => 'sectionend',
            'id' => 'wmcs_general_settings'
        ],
		
		[
            'title' => __( 'Exchange Rates', 'woocommerce' ),
            'type' => 'title',
            'desc' => '',
            'id' => 'wmcs_exchange_rate_settings'
        ],
		
		'wmcs_exchange_rate_source' => [
			'title'    	=> 	__( 'Source', 'woocommerce' ),
			'desc'     	=> 	'',
			'id'       	=> 	'wmcs_exchange_rate_source',
			'class'    => 'wc-enhanced-select',
			'css'      	=> 	'min-width:250px;',
			'default'  	=> 	'ExchangeRateAPI',
			'type'     	=> 	'select',
			'options'  	=> 	$sources,
			'desc_tip' =>  'Set which exchange rates should be used when converting prices',
		],
		
		'wmcs_exchange_rate_source_info' => [
			'id' => 'wmcs_exchange_rate_source_info',
			'type' => 'wmcs_exchange_rate_source_info'
		],
		
		[
            'type' => 'sectionend',
            'id' => 'wmcs_exchange_rate_settings'
        ],
	];
	
	//Additional Currencies
	$options['additional_currencies'] = [
		[
            'title' => __( 'Additional Currencies', 'woocommerce' ),
            'type' => 'title',
            'desc' => '',
            'id' => 'additional_currencies'
        ],
			
		[ 
			'id' 	=> '_wmcs_store_currencies', //ID needs to be different to form field name otherwise woo will just overwrite our custom save with the values posted.
			'type' 	=> 'wmcs_store_currencies',
			'title'	=> '',
			'desc'	=> __( 'Additional currencies that you want in your store. Customers whose local currency is defined below will be shown prices in their local currency instead of the base currency.<br />
							If a customers currency is not defined below, then prices will be shown in the base currency.', 'woocommerce' ),
			'tip'	=> ''
		],
		
		[
            'type' => 'sectionend',
            'id' => 'additional_currencies'
        ]
	];	
	
	if ($raw) { // return a flat array with all options without their sections
		static $raw_options = null;
		
		if (is_null($raw_options)) {
			$raw_options = array();
			foreach ($options as $option) {
				$raw_options = array_merge($raw_options, $option);
			}
		}
		
		return $raw_options;
	}
			
	return $options;
}
