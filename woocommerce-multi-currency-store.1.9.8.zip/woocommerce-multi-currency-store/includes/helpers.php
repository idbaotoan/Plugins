<?php 

namespace CodeNinjas\WMCS\Helpers;

/**
 *  Add the full path to the plugins directory if it isn't already included in the path
 *  
 *  @param	string	$path	Path to add plugin directory path to
 *  @return string
 *
 *  @since  1.9.8
 */
function pluginDirPath($path = '')
{
    if(strpos($path, WP_PLUGIN_DIR) === 0){
        return $path;
    }

    return \trailingslashit(WP_PLUGIN_DIR) . $path;
}

/**
 * Check the current request type
 * 
 * @param	string	$string	The request tyoe to check
 * @return	bool
 *
 *  @since  1.9.8
 */
function isRequest($type)
{
    switch($type) {
        case 'admin':
            return \is_admin();
        case 'ajax':
            return defined('DOING_AJAX');
        case 'cron':
            return defined('DOING_CRON');
        case 'frontend':
            return (!\is_admin() || defined('DOING_AJAX')) && !defined('DOING_CRON');
    }
}


/**
 *  Add admin notice
 * 
 *  @param  string  $type
 *  @param  string  $notice
 *  @return	bool
 *
 *  @since  1.9.8
 */
function addAdminNotice($type, $notice)
{
    add_action('admin_notices', function() use ($type, $notice){
        echo "<div class='notice notice-{$type}'><p>{$notice}</p></div>";
    });
}


/**
 *  Determine if string if Json or not
 *
 *  @params string  $string
 *
 *  @since  1.9.3
 */
function isJson($str)
{
    @json_decode($str);
    
    return (json_last_error() === JSON_ERROR_NONE);
}
