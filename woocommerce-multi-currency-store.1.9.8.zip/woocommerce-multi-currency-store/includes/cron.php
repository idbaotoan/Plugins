<?php

namespace CodeNinjas\WMCS\Cron;

use CodeNinjas\WMCS;
use CodeNinjas\WMCS\Currency;

add_action('wmcs_cron_check_exchange_rates', __NAMESPACE__ . '\run');
add_action('wmcs_after_init', __NAMESPACE__ . '\init');
add_action('wmcs_deactivate', __NAMESPACE__ . '\removeCron');

add_filter('cron_schedules', __NAMESPACE__ . '\addCronSchedules');


/**
 *  Register cron if it hasn't already been registered
 *  
 *  @since	1.2.7
 */
function init()
{
	if (!wp_next_scheduled('wmcs_cron_check_exchange_rates')) {
		addCron();
	}
}


/**
 *  Unregister cron interval on deactivate
 *  
 *  @since	1.2.7
 */
function removeCron()
{
	$timestamp = wp_next_scheduled('wmcs_cron_check_exchange_rates');
	if($timestamp){
		wp_unschedule_event($timestamp, 'wmcs_cron_check_exchange_rates');
	}
}


/**
 *  Add our custom schedules
 *  
 *  @param	array	$schedules	Current schedules
 *  @return	array
 *  @since	1.2.7
 */
function addCronSchedules($schedules)
{
	$wmcs_schedules = getSchedules();
	foreach($wmcs_schedules as $schedule_id => $schedule_info){
		$schedules[$schedule_id] = $schedule_info;
	}
	
	return $schedules;
}


/**
 *  Schedule the cron
 *  
 *  @param	string	$schedule	Schedule to set
 *  @since	1.9
 */
function addCron($schedule = 'wmcs_daily')
{
	wp_schedule_event(time() + 60, $schedule, 'wmcs_cron_check_exchange_rates'); 
}


/**
 *  Reschedule the cron
 *  
 *  @param	string	$schedule	Schedule to set
 *  @since	1.9
 */
function reScheduleCron($schedule = 'wmcs_daily')
{
	removeCron();
	addCron($schedule);
}


/**
 *  Return cutom schedules
 *
 *  @since	1.9
 */
function getSchedules()
{
	return array(
		'wmcs_1min' => array( //DENUG ONLY
			'interval' => 60,
			'display' => __('Every 1 mins', 'woocommerce')
		),
		'wmcs_5min' => array(
			'interval' => 60 * 5,
			'display' => __('Every 5 mins', 'woocommerce')
		),
		'wmcs_10min' => array(
			'interval' => 60 * 10,
			'display' => __('Every 10 mins', 'woocommerce')
		),
		'wmcs_15min' => array(
			'interval' => 60 * 15,
			'display' => __('Every 15 mins', 'woocommerce')
		),
		'wmcs_30min' => array(
			'interval' => 60 * 30,
			'display' => __('Every 30 mins', 'woocommerce')
		),
		'wmcs_hour' => array(
			'interval' => 60 * 60,
			'display' => __('Every hour', 'woocommerce')
		),
		'wmcs_3hour' => array(
			'interval' => 60 * 60 * 3,
			'display' => __('Every 3 hours', 'woocommerce')
		),
		'wmcs_6hour' => array(
			'interval' => 60 * 60 * 6,
			'display' => __('Every 6 hours', 'woocommerce')
		),
		'wmcs_12hour' => array(
			'interval' => 60 * 60 * 12,
			'display' => __('Every 12 hours', 'woocommerce')
		),
		'wmcs_daily' => array(
			'interval' => 60 * 60 * 24,
			'display' => __('Every Day', 'woocommerce')
		),
	);
}

/**
 *  Cron run
 *  
 *  @since	1.9
 */
function run()
{
    $source = Currency\getSource();
    if ($source !== 'custom') {
        WMCS\Log('info', 'Cron running...');
        $source->getRates();
    }
}