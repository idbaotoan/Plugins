<?php

namespace CodeNinjas\WMCS\Currency;

use CodeNinjas\WMCS;
use CodeNinjas\WMCS\Helpers;
use CodeNinjas\WMCS\Settings;


/**
 *  Get the base currency
 *  
 *  @return string
 *  @since	1.9
 */
function getBase()
{
	return \get_option('woocommerce_currency');
}


/**
 *  Get the selected source
 *  
 *  @param	string	$source		The source to getBase
 *  @return	object
 */
function getSource($source = '')
{
	if (!$source) {
		$source = Settings\getOption('wmcs_exchange_rate_source');
	}

	if ($source == 'custom') {
        return $source;
    }
    
    $source = 'CodeNinjas\\WMCS\\Classes\\' . $source;
	
	return new $source();
}


/**
 *  Get all sources
 *
 *  @param  bool    $raw
    @return array
 */
function getAllSources($raw = false)
{
	$sources = array('ExchangeRateAPI', 'OpenExchangeRates', 'CurrencyLayer', 'EuropeanCentralBank');
	
	if ($raw) {
        return $sources;
    }

	$return = array();
	foreach ($sources as $source) {
		$return[] = getSource($source);
	}
	
	return $return;
}


/**
 *  Get the currencies and its options that have been added to the store
 *  
 *  @return array
 *  @since  1.9
 */
function getStoreCurrencies()
{
	return Settings\getOption('wmcs_store_currencies', []);
}


/**
 *  Check if currency has been added to the store
 *  
 *  @return bool
 *  @since  1.9.8
 */
function isCurrencyInStore($currency)
{
    $storeCurrencies = getStoreCurrencies();
    
    return array_key_exists($currency, $storeCurrencies);
}

/**
 *  Get an individual rate
 *  
 *  @return int
 *  @since	1.9
 */
function getRate($currency)
{
	$store_currencies = getStoreCurrencies();
	
	// Check if rate source (global or for this currency) is set to custom
	if (array_key_exists($currency, $store_currencies)) {
		$source = getSource();
		if ($source === 'custom' || $store_currencies[$currency]['exchange_rate_type'] == 'custom') {
			return !empty($store_currencies[$currency]['exchange_rate_value']) ? $store_currencies[$currency]['exchange_rate_value'] : 1;
		}
	}
	
	$rates = getRates();
	
	return array_key_exists($currency, $rates) ? $rates[$currency] : 1; // Return 1 if no rate found (i.e. price will stay the same)
}


/**
 *  Get all rates
 *  
 *  @return array
 *  @since	1.9
 */
function getRates()
{
	$data = Settings\getOption('wmcs_live_exchange_rates', array());
	
	return isset($data['rates']) ? $data['rates'] : array();
}


/**
 *  Set an individual currency rate
 *  
 *  @since	1.9
 */
function setRate($currency, $rate)
{
	$rates = getRates();
	
    $rates[$currency] = $rate;
	setRates($rates);
}


/**
 *  Save the exchange rates
 *  
 *  @since	1.9
 */
function setRates($rates)
{
	if ($rates) {
		$data = Settings\getOption('wmcs_live_exchange_rates');
		$data['rates'] = $rates;
		
		\update_option('wmcs_live_exchange_rates', $data);
	}
}


/**
 *  Set last checked data
 *  
 *  @param	bool	$success	If check was successful
 *  @param	int		$time		timestamp 
 *  @since	1.9
 */
function setLastChecked($success, $time = null)
{
	$data = Settings\getOption('wmcs_live_exchange_rates');
	
	$data['status'] = $success ? 'success' : 'failed';
	$data['last_checked'] = is_null($time) ? time() : $time;
	
	\update_option('wmcs_live_exchange_rates', $data);
}


/**
 *  Get last checked details - status and time
 *  
 *  @return	array
 *  @since	1.9
 */
function getLastChecked()
{
	$data = Settings\getOption('wmcs_live_exchange_rates');
	
	return array(
		'status' => isset($data['status']) ? $data['status'] : '',
		'last_checked' => $data['last_checked']
	);
}


/**
 * Get the customers currency based on their country (from their IP address)
 *
 * @return  string  
 * @since   1.0.0
 */
function getCustomersCurrency()
{	
	$base_currency = getBase();
	
	if (Helpers\isRequest('admin') && !Helpers\isRequest('ajax')) {
        return $base_currency;
    }
	
    $currency = WMCS\getCookie();
    
	if (!$currency) {
		$currency = $base_currency;
	}
	
	$currency = apply_filters('wmcs_filter_customers_currency', $currency);
	
	return $currency;
}


/**
 * Get the customers currency data
 *
 * @return  string  
 * @since   1.0.0
 */
function getCustomersCurrencyData() {
	
	$customers_currency = getCustomersCurrency();
	$store_currencies = getStoreCurrencies();
	
    if ($customers_currency) {
		if (array_key_exists($customers_currency, $store_currencies)) {
			return $store_currencies[$customers_currency];
		}
	}
	
	return false;
}


/**
 * Convert price to the currency given
 *
 * @return  string  
 * @since   1.0.0
 */
function convertPrice($price, $currency = '')
{
	if ($price == '') {
        return $price;
    }
	
    // Get currency
	if (!$currency) {
        $currency = getCustomersCurrency(); 
    }
    
    // Return if currency is base
	if ($currency == getBase()) {
        return $price; 
    }
		
	$exchange_rate = getRate($currency); 
	
	$converted_price = $price * $exchange_rate;
	
	//We need to format the price with number of decimals and rounding now (and not only in the frontend) 
    // so that when the price is passed to payment, its correct
	$currency_data = getCustomersCurrencyData();
	if ($currency_data) {
		$decimals = $currency_data['decimal_places'];
		$converted_price = number_format( $converted_price, $decimals, '.', '' );
		
		$rounding_type = $currency_data['rounding_type'];
		$rounding_to = $currency_data['rounding_to'];
		
        if ($rounding_type != 'none') {
			if ($rounding_type == 'up') {
				$converted_price = round($converted_price, $rounding_to, PHP_ROUND_HALF_UP);
			}
			else {
				$converted_price = round($converted_price, $rounding_to, PHP_ROUND_HALF_DOWN);
			}
		}
	}
	
	return $converted_price;
}

function getCurrencyByCountry($countryCode)
{
    $mappings = countryCurrencyMappings();
    
    if (array_key_exists($countryCode, $mappings)) {
        return $mappings[$countryCode];
    }
    
    return false;
}
 
function countryCurrencyMappings()
{	
	$mappings = array(
		'NZ' => 'NZD', 'CK' => 'NZD', 'NU' => 'NZD', 'PN' => 'NZD', 'TK' => 'NZD', 'AU' => 'AUD', 'CX' => 'AUD', 'CC' => 'AUD', 'HM' => 'AUD', 'KI' => 'AUD',
		'NR' => 'AUD', 'NF' => 'AUD', 'TV' => 'AUD', 'AS' => 'EUR', 'AD' => 'EUR', 'AT' => 'EUR', 'BE' => 'EUR','FI' => 'EUR',  'FR' => 'EUR', 'GF' => 'EUR',
		'TF' => 'EUR', 'DE' => 'EUR', 'GR' => 'EUR', 'GP' => 'EUR', 'IE' => 'EUR', 'IT' => 'EUR', 'LU' => 'EUR', 'MQ' => 'EUR', 'YT' => 'EUR', 'MC' => 'EUR',
		'NL' => 'EUR', 'PT' => 'EUR', 'RE' => 'EUR', 'WS' => 'EUR', 'SM' => 'EUR', 'SI' => 'EUR', 'ES' => 'EUR', 'VA' => 'EUR', 'GS' => 'GBP', 'GB' => 'GBP',
		'JE' => 'GBP', 'IO' => 'USD', 'GU' => 'USD', 'MH' => 'USD', 'FM' => 'USD', 'MP' => 'USD', 'PW' => 'USD', 'PR' => 'USD', 'TC' => 'USD', 'US' => 'USD',
		'UM' => 'USD', 'VG' => 'USD', 'VI' => 'USD', 'HK' => 'HKD', 'CA' => 'CAD', 'JP' => 'JPY', 'AF' => 'AFN', 'AL' => 'ALL', 'DZ' => 'DZD', 'AI' => 'XCD',
		'AG' => 'XCD', 'DM' => 'XCD', 'GD' => 'XCD', 'MS' => 'XCD', 'KN' => 'XCD', 'LC' => 'XCD', 'VC' => 'XCD', 'AR' => 'ARS', 'AM' => 'AMD', 'AW' => 'ANG',
		'AN' => 'ANG', 'AZ' => 'AZN', 'BS' => 'BSD', 'BH' => 'BHD', 'BD' => 'BDT', 'BB' => 'BBD', 'BY' => 'BYR', 'BZ' => 'BZD', 'BJ' => 'XOF', 'BF' => 'XOF',
		'GW' => 'XOF', 'CI' => 'XOF', 'ML' => 'XOF', 'NE' => 'XOF', 'SN' => 'XOF', 'TG' => 'XOF', 'BM' => 'BMD', 'BT' => 'INR', 'IN' => 'INR', 'BO' => 'BOB',
		'BW' => 'BWP', 'BV' => 'NOK', 'NO' => 'NOK', 'SJ' => 'NOK', 'BR' => 'BRL', 'BN' => 'BND', 'BG' => 'BGN', 'BI' => 'BIF', 'KH' => 'KHR', 'CM' => 'XAF',
		'CF' => 'XAF', 'TD' => 'XAF', 'CG' => 'XAF', 'GQ' => 'XAF', 'GA' => 'XAF', 'CV' => 'CVE', 'KY' => 'KYD', 'CL' => 'CLP', 'CN' => 'CNY', 'CO' => 'COP',
		'KM' => 'KMF', 'CD' => 'CDF', 'CR' => 'CRC', 'HR' => 'HRK', 'CU' => 'CUP', 'CY' => 'CYP', 'CZ' => 'CZK', 'DK' => 'DKK', 'FO' => 'DKK', 'GL' => 'DKK',
		'DJ' => 'DJF', 'DO' => 'DOP', 'TP' => 'IDR', 'ID' => 'IDR', 'EC' => 'ECS', 'EG' => 'EGP', 'SV' => 'SVC', 'ER' => 'ETB', 'ET' => 'ETB', 'EE' => 'EEK',
		'FK' => 'FKP', 'FJ' => 'FJD', 'PF' => 'XPF', 'NC' => 'XPF', 'WF' => 'XPF', 'GM' => 'GMD', 'GE' => 'GEL', 'GI' => 'GIP', 'GT' => 'GTQ', 'GN' => 'GNF',
		'GY' => 'GYD', 'HT' => 'HTG', 'HN' => 'HNL', 'HU' => 'HUF', 'IS' => 'ISK', 'IR' => 'IRR', 'IQ' => 'IQD', 'IL' => 'ILS', 'JM' => 'JMD', 'JO' => 'JOD',
		'KZ' => 'KZT', 'KE' => 'KES', 'KP' => 'KPW', 'KR' => 'KRW', 'KW' => 'KWD', 'KG' => 'KGS', 'LA' => 'LAK', 'LV' => 'LVL', 'LB' => 'LBP', 'LS' => 'LSL',
		'LR' => 'LRD', 'LY' => 'LYD', 'LI' => 'CHF', 'CH' => 'CHF', 'LT' => 'LTL', 'MO' => 'MOP', 'MK' => 'MKD', 'MG' => 'MGA', 'MW' => 'MWK', 'MY' => 'MYR',
		'MV' => 'MVR', 'MT' => 'MTL', 'MR' => 'MRO', 'MU' => 'MUR', 'MX' => 'MXN', 'MD' => 'MDL', 'MN' => 'MNT', 'MA' => 'MAD', 'EH' => 'MAD', 'MZ' => 'MZN',
		'MM' => 'MMK', 'NA' => 'NAD', 'NP' => 'NPR', 'NI' => 'NIO', 'NG' => 'NGN', 'OM' => 'OMR', 'PK' => 'PKR', 'PA' => 'PAB', 'PG' => 'PGK', 'PY' => 'PYG',
		'PE' => 'PEN', 'PH' => 'PHP', 'PL' => 'PLN', 'QA' => 'QAR', 'RO' => 'RON', 'RU' => 'RUB', 'RW' => 'RWF', 'ST' => 'STD', 'SA' => 'SAR', 'SC' => 'SCR',
		'SL' => 'SLL', 'SG' => 'SGD', 'SK' => 'EUR', 'SB' => 'SBD', 'SO' => 'SOS', 'ZA' => 'ZAR', 'LK' => 'LKR', 'SD' => 'SDG', 'SR' => 'SRD', 'SZ' => 'SZL',
		'SE' => 'SEK', 'SY' => 'SYP', 'TW' => 'TWD', 'TJ' => 'TJS', 'TZ' => 'TZS', 'TH' => 'THB', 'TO' => 'TOP', 'TT' => 'TTD', 'TN' => 'TND', 'TR' => 'TRY',
		'TM' => 'TMT', 'UG' => 'UGX', 'UA' => 'UAH', 'AE' => 'AED', 'UY' => 'UYU', 'UZ' => 'UZS', 'VU' => 'VUV', 'VE' => 'VEF', 'VN' => 'VND', 'YE' => 'YER',
		'ZM' => 'ZMK', 'ZW' => 'ZWD', 'AX' => 'EUR', 'AO' => 'AOA', 'AQ' => 'AQD', 'BA' => 'BAM', 'CD' => 'CDF', 'GH' => 'GHS', 'GG' => 'GGP', 'IM' => 'GBP',
		'LA' => 'LAK', 'MO' => 'MOP', 'ME' => 'EUR', 'PS' => 'JOD', 'BL' => 'EUR', 'SH' => 'GBP', 'MF' => 'ANG', 'PM' => 'EUR', 'RS' => 'RSD', 'USAF' => 'USD'
	);
	
	return $mappings;
}