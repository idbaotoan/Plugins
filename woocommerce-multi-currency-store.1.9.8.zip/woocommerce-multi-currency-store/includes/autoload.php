<?php

spl_autoload_register(function($class)
{
    if (strpos($class, 'CodeNinjas\WMCS') !== 0) {
        return;
    }
    
    $classes = [
        // Abstracts
        'Api' => WMCS_DIR . '/classes/abstracts/Api.php',
        
        // APIs
        'CurrencyLayer' => WMCS_DIR . '/classes/apis/CurrencyLayer.php',
        'EuropeanCentralBank' => WMCS_DIR . '/classes/apis/EuropeanCentralBank.php',
        'ExchangeRateAPI' => WMCS_DIR . '/classes/apis/ExchangeRateApi.php',
        'OpenExchangeRates' => WMCS_DIR . '/classes/apis/OpenExchangeRates.php',
        'Yahoo' => WMCS_DIR . '/classes/apis/Yahoo.php',
        
        // Widgets
        'CurrencySwitcherWidget' => WMCS_DIR . '/classes/widgets/CurrencySwitcherWidget.php',
    ];
    
    $class = explode('\\', $class);
    $className = $class[count($class) - 1];
    
    if (array_key_exists($className, $classes)) {
        include_once $classes[$className];
    }
});