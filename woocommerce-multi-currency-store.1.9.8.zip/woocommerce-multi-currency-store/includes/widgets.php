<?php

namespace CodeNinjas\WMCS\Widgets;


add_action('widgets_init', __NAMESPACE__ . '\registerWidgets');

/**
 *  Register widgets_init
 *  
 *  @since  1.0
 *  @action widgets_init
 */
function registerWidgets()
{
	register_widget('\CodeNinjas\WMCS\Classes\CurrencySwitcherWidget');
}
