<?php

namespace CodeNinjas\WMCS\Frontend;

use CodeNinjas\WMCS;
use CodeNinjas\WMCS\Settings;
use CodeNinjas\WMCS\Currency;

add_action('wmcs_after_init', __NAMESPACE__ . '\initCookie');
add_action('wp_loaded', __NAMESPACE__ . '\changeCurrency');

add_filter('woocommerce_currency', __NAMESPACE__ . '\filterWoocommerceCurrency');
add_filter('pre_option_woocommerce_price_decimal_sep', __NAMESPACE__ . '\filterWoocommerceDecimalSep');
add_filter('pre_option_woocommerce_price_thousand_sep', __NAMESPACE__ . '\filterWoocommerceThousandSep');
add_filter('pre_option_woocommerce_price_num_decimals', __NAMESPACE__ . '\filterWoocommerceNumDecimals');
add_filter('woocommerce_price_format', __NAMESPACE__ . '\filterWoocommercePriceFormat');
add_filter('raw_woocommerce_price', __NAMESPACE__ . '\filterRawWoocommercePrice');


/**
 *  Set the cookie with the users currency if it isn't set yet
 *  
 *  @since  1.9.7
 */
function initCookie()
{
    if (isset($_COOKIE[WMCS_CURRENCY_COOKIE_NAME])) {
        return;
    }
    
    $currency = Currency\getBase();
        
    if (Settings\getOption('wmcs_enable_geoip')) {

        $geoip = \WC_Geolocation::geolocate_ip();
                    
        if (isset($geoip['country']) && !empty($geoip['country'])) {
            $countryCode = $geoip['country'];
            $countryCurrency = Currency\getCurrencyByCountry($countryCode);
            
            if ($countryCurrency && Currency\isCurrencyInStore($countryCurrency)) {
                $currency = $countryCurrency;
            }
        }
    }

    WMCS\setCookie($currency);
}


/**
 * Filter Woocommerces currency with custom currency
 *
 * @var     string  $currency	Stores base currency
 * @return  string  Custom currency or stores if no currency set
 *
 * @since	   1.0
 * @filter  woocommerce_currency 
 */
function filterWoocommerceCurrency($currency)
{
	$customersCurrency = Currency\getCustomersCurrencyData();
	if($customersCurrency){
		return $customersCurrency['currency_code'];
	}
	
	return $currency;
}


/**
 * Filter Woocommerces decimal separator with custom currency's
 *
 * @params  string  $separator
 * @return  string	
 *
 * @since	   1.1
 * @filter  pre_option_woocommerce_price_decimal_sep
 */
function filterWoocommerceDecimalSep($separator)
{
    $customersCurrency = Currency\getCustomersCurrencyData();
    if($customersCurrency){
        return $customersCurrency['decimal_separator'];
    }
	
	return $separator;
}


/**
 * Filter Woocommerces thousands separator with custom currency's
 *
 * @params  string  $separator
 * @return  string
 *
 * @since	    1.1
 * @filter  pre_option_woocommerce_price_thousand_sep
 */
function filterWoocommerceThousandSep($separator)
{
    $customersCurrency = Currency\getCustomersCurrencyData();
    if($customersCurrency){
        return $customersCurrency['thousand_separator'];
    }
	
	return $separator;
}


/**
 * Filter Woocommerces number of decimal places with custom currency's
 *
 * @params  string  $position
 * @return  string
 *
 * @since	   1.1
 * $filter  pre_option_woocommerce_price_num_decimals
 */
function filterWoocommerceNumDecimals($decimalPlaces)
{
    $customersCurrency = Currency\getCustomersCurrencyData();
    if($customersCurrency){
        return $customersCurrency['decimal_places'];
    }
	
	return $decimalPlaces;
}


/**
 * Filter Woocommerces price format
 *
 * @params  string  $format
 * @return  string
 *
 * @since	   1.1
 * $filter  woocommerce_price_format
 */
function filterWoocommercePriceFormat($format)
{
	$customersCurrency = Currency\getCustomersCurrencyData();
	if($customersCurrency){
		$format = $customersCurrency['price_format'];
		
		//price - %2$s in wc_price
		$format = str_replace('[price]', '%2$s', $format);
		//currency_symbol - %1$s in wc_price
		$format = str_replace('[currency_symbol]', '%1$s', $format);
		//currency_code
		$format = str_replace('[currency_code]', $customersCurrency['currency_code'], $format);
		
		return $format;
	}
	
	return $format;
}


/**
 * Filter raw price to apply rounding
 *
 * @params  float  $price
 * @return  float
 *
 * @since	   1.1
 * $filter  raw_woocommerce_price
 */
function filterRawWoocommercePrice($price)
{
    $customersCurrency = Currency\getCustomersCurrencyData();
    if ($customersCurrency) {
        $roundingType = $customersCurrency['rounding_type'];
        $roundingTo = $customersCurrency['rounding_to'];
        
        switch ($roundingType) {
            case 'up':
                return round($price, $roundingTo, PHP_ROUND_HALF_UP);
            case 'down':
                return round($price, $rounding_to, PHP_ROUND_HALF_DOWN);
        }
    }
    
    return $price;
}


/**
 * Change the currency of the store to whatever has been passed. 
 * Used in the currency switcher widget
 *
 * @since   1.0
 * @action  wp_loaded
 */
function changeCurrency()
{
    if (!isset($_GET['wmcs_set_currency'])) {
        return;
    }
    	
    $newCurrency = $_GET['wmcs_set_currency'];
	
    if (!Currency\isCurrencyInStore($newCurrency)) {
        $newCurrency = Currency\getBase();
    }
    
    WMCS\setCookie($newCurrency);
    
    //recalculate/recreate cart totals/widget
    WC()->session->cart = WC()->cart->get_cart_for_session();
    WC()->cart->calculate_totals();
    
    wp_redirect(remove_query_arg('wmcs_set_currency'));
    exit;	
}
