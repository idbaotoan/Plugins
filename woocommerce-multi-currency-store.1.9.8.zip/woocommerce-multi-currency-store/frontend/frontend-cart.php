<?php

namespace CodeNinjas\WMCS\Frontend\Cart;

use CodeNinjas\WMCS\Currency;

add_filter('woocommerce_shipping_free_shipping_is_available', __NAMESPACE__ . '\checkFreeShippingAvailability', 10, 3);
add_filter('woocommerce_coupon_get_amount', __NAMESPACE__ . '\convertCouponAmount', 10, 2);
add_filter('woocommerce_package_rates', __NAMESPACE__ . '\convertShippingRates', 10, 2);

/**
 * Check is free shipping is still available after converting the min amount to the select currency
 * 
 * @param   bool    $available
 * @param   object  $package
 * @param	   object  $instance
 *
 * @since	   1.9.4
 * @filter  woocommerce_shipping_free_shipping_is_available
 */
function checkFreeShippingAvailability($available, $package, $instance)
{
	$subtotal = $package['cart_subtotal'];
	$converted_min_amount = Currency\convertPrice($instance->min_amount);
	if ($subtotal < $converted_min_amount) {
		$available = false;
	}
	
	return $available;
}


/**
 *  Convert the coupon amount to select currency
 *  
 *  @param     int      $value
 *  @param     object   $instance
 *  @return    float
 *
 *  @since1     1.9.4
 *  @filter     woocommerce_coupon_get_amount
 */
function convertCouponAmount($value, $instance)
{
    if ($instance->get_discount_type() == 'percent') {
        return $value;
    }

	return Currency\convertPrice($value);
}


/**
 *  Covert shipping rates
 *  
 *  @param     array    $rates
 *  @param     object   $package
 *  @return    array
 *
 *  @since1     1.9.4
 *  @filter     woocommerce_package_rates
 */
function convertShippingRates($rates, $package)
{
	foreach ($rates as $id => $rate) {
		$instance = \WC_Shipping_Zones::get_shipping_method(1); // Get the methods instance
		
		/**
		 *  Only convert the cost if the cost is no a formula i.e. just a value
		 *  If the cost is a formula, Woocommerce will calculate it based on the cart values
		 *  which have already been converted
		 */
		if (strpos($instance->cost, '[fee') === false &&
			strpos($instance->cost, '[cost') === false &&
			strpos($instance->cost, '[qty') === false) {
				$rates[$id]->cost = Currency\convertPrice($rate->cost);
		}
	}
	
	return $rates;
}
