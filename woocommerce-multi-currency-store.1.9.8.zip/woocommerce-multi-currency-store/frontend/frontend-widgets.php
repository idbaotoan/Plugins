<?php

namespace CodeNinjas\WMCS\Frontend\Widgets;

use CodeNinjas\WMCS\Currency;

add_action('woocommerce_product_query_meta_query', __NAMESPACE__ . '\removePriceFilterQuery', 10, 2);

add_filter('woocommerce_price_filter_widget_min_amount', __NAMESPACE__ . '\convertPriceFilterWidgetMinValue');
add_filter('woocommerce_price_filter_widget_max_amount', __NAMESPACE__ . '\convertPriceFilterWidgetMaxValue');

/**
 *  Convert the min price on Woocommerces Price Filter widget
 *  
 *  @param  float   $amount
 *  @return float
 *
 *  @since  1.2.7
 *  @filter woocommerce_price_filter_widget_min_amount
 */
function convertPriceFilterWidgetMinValue($amount)
{
	return floor(Currency\convertPrice($amount));
}


/**
 *  Convert the max price on Woocommerces Price Filter widget
 *  
 *  @param  float   $amount
 *  @return float
 *
 *  @since  1.2.7
 *  @filter woocommerce_price_filter_widget_max_amount
 */
function convertPriceFilterWidgetMaxValue($amount)
{
	return ceil(Currency\convertPrice($amount));
}


/**
 * Remove the price filter meta query if we're not viewing the base currency
 * We'll run our custom query to get the post IDs for this currency and add that post__in value to get the correct products
 * 
 * @param 	array	$meta_query
 * @param 	object	$WC_Query
 * @return 	array
 * @since	1.2.7
 */
function removePriceFilterQuery($meta_query, $WC_Query)
{
	$base_currency = get_option('woocommerce_currency');
	$visitors_currency = Currency\getCustomersCurrency();
	if ($visitors_currency == $base_currency) {
        return $meta_query;
    }
    
    if (isset($_GET['min_price']) || isset($_GET['min_price'])) {
        $meta_query['price_filter'] = array();
        add_filter('loop_shop_post_in', __NAMESPACE__ . '\filterProductsByCurrencyPrices');
    }
    
    return $meta_query;
}



/**
 * Get all the products whose currency price is in the price filter range
 * If there is no currency price (i.e. _USD_price) we'll need to calculate the converted price using _price
 * However, even though the calculated price be in the range, an actual price entered may be outside of the range
 * So we'll need to get the 2 lists separately and compare them to get the actual products in the range
 *
 *  @param  array   $post_in
 *  @return array
 *
 *  @since  1.2.7
 *  @filter loop_shop_post_in
 */
function filterProductsByCurrencyPrices($post_in)
{
    global $wpdb;
    
    $currency = Currency\getCustomersCurrency();
    $min = $_GET['min_price'];
    $max = $_GET['max_price'];
    
    //get the products that have prices entered in this currency that are in the price filters range
    $sql = "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_{$currency}_price' AND meta_value BETWEEN $min AND $max";
    $products_with_prices = $wpdb->get_col($sql);
    
    //get the products whose calculated price falls in the price filters range but who do not have a entered price
    $exchange_rate = Currency\getRate($currency);
    $sql = "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_price' AND meta_value * {$exchange_rate} BETWEEN $min AND $max";
    if ($products_with_prices) {
        $sql .= " AND post_id NOT IN (".implode(',', $products_with_prices).")";
    }
    $products_calculated_prices = $wpdb->get_col($sql);
    
    //all product ids in this price range
    $product_ids = array_merge($products_with_prices, $products_calculated_prices);
    
    //merge this $post_in incase something is passed in
    return array_merge($post_in, $product_ids);
}
