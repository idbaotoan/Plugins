<?php

namespace CodeNinjas\WMCS\Frontend\Product;

use CodeNinjas\WMCS\Currency;
use CodeNinjas\WMCS\Settings;

add_filter('woocommerce_product_get_price', __NAMESPACE__ . '\filterProductPrice', 10, 2);
add_filter('woocommerce_product_get_regular_price', __NAMESPACE__ . '\filterProductRegularPrice', 10, 2);
add_filter('woocommerce_product_get_sale_price', __NAMESPACE__ . '\filterProductSalePrice', 10, 2);

add_filter('woocommerce_product_variation_get_price', __NAMESPACE__ . '\filterProductPrice', 10, 2);
add_filter('woocommerce_product_variation_get_regular_price', __NAMESPACE__ . '\filterProductRegularPrice', 10, 2);
add_filter('woocommerce_product_variation_get_sale_price', __NAMESPACE__ . '\filterProductSalePrice', 10, 2);

add_filter('woocommerce_variation_prices', __NAMESPACE__ . '\filterVeriationPrices', 10, 3);


/**
 *  Filter the products price and return the selected currencies price if its not the base currency
 *  
 *  @param  string  $price
 *  @param  object  $product
 *  
 *  @since  1.9.8
 *  @filter woocommerce_product_get_price
 */
function filterProductPrice($price, $product)
{
    return getProductPrice($product->get_id(), 'price', $price);
}


/**
 *  Filter the products regular price and return the selected currencies price if its not the base currency
 *  
 *  @param  string  $price
 *  @param  object  $product
 *  
 *  @since  1.9.8
 *  @filter woocommerce_product_get_regular_price
 */
function filterProductRegularPrice($price, $product)
{
    return getProductPrice($product->get_id(), 'regular_price', $price);
}


/**
 *  Filter the products sale price and return the selected currencies price if its not the base currency
 *  
 *  @param  string  $price
 *  @param  object  $product
 *  
 *  @since  1.9.8
 *  @filter woocommerce_product_get_sale_price
 */
function filterProductSalePrice($price, $product)
{
    return getProductPrice($product->get_id(), 'sale_price', $price);
}


/**
 *  Filter variations prices array and replace prices is custom/converted prices
 *  
 *  @param  array   $prices
 *  @param  object  $product
 *  @param  bool    $forDisplay
 *  
 *  @since  1.9.8
 *  @filter woocommerce_variation_prices
 */
function filterVeriationPrices($prices, $product, $forDisplay)
{    
    foreach ($prices as $priceType => $pricesArray) {
        $metaKey = '_' . $currency .'_' . $priceType;
        
        foreach ($pricesArray as $productId => $productPrice) {
            $prices[$priceType][$productId] = getProductPrice($productId, $priceType, $productPrice);
        }
    }
    
    return $prices;
}


/**
 *  Get the price set for this currency or convert the price
 *  
 *  @param  string  $metaKey
 *  @param  string  $price
 *  @param  object  $product
 *  
 *  @since  1.9.8
 */
function getProductPrice($productId, $metaKey, $price)
{
    $baseCurrency = Currency\getBase();
    $currency = Currency\getCustomersCurrency();
    
    if ($currency == $baseCurrency) {
        return $price;
    }
    
    
    // Get custom price for this currency
    $metaKey = '_' . $currency .'_' . $metaKey;
    if ($currencyPrice = \get_post_meta($productId, $metaKey, true)) {
        return $currencyPrice;
    }
    
    // Convert the current price
    return Currency\convertPrice($price);
}
