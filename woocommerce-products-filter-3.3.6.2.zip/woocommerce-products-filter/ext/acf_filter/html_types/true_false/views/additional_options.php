<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');
?>
<div id="woof-modal-content-<?php echo esc_attr($key) ?>" style="display: none;">
    <div class="woof-form-element-container">
        <div class="woof-name-description">
            <span><?php esc_html_e('No data', 'woocommerce-products-filter') ?></span>
        </div>
    </div> 
</div>

