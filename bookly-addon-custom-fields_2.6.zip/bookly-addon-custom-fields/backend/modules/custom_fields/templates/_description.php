<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="form-group">
    <div class="form-row">
        <div class="col-md-8">
            <textarea class="bookly-js-description form-control" type="text" placeholder="<?php esc_attr_e( 'Enter a description', 'bookly' ) ?>"></textarea>
        </div>
    </div>
</div>