/*
* Author: Travis - Mediaplus
*/
(function ($) {
	'use strict';
	jQuery(document).ready(function ($) {
		if($('body').width()>=1025){
			var header = $(".header-main");
			$('#site-header .elementor-top-section').css('height',$('#site-header .elementor-top-section').height());
			var sticky = header.offset().top + header.height();
			$(window).scroll(function() {
				if (window.pageYOffset > sticky) {
					header.addClass("elementor-sticky--effects");
				} else {
					header.removeClass("elementor-sticky--effects");
				}
			});
		}
		if($('.user-login-overdue')[0]){
		   	$('.jobsearch-open-signin-tab').trigger('click');
		}
		$(document).on('click', 'body:not(.jobsearch_candidate) .jobsearch-applyjob-btn', function(e){
			e.preventDefault();
			alert("Please Register or Sign in as a Job Seeker to apply for the job.");
		});
		if($('.jobsearch-employer-dashboard-nav')[0]){
			var currentURL = window.location.href;
		   $('.jobsearch-employer-dashboard-nav ul li').each(function(){
			   if($(this).find('a').attr('href') == currentURL){
				   $(this).addClass('active');
			   }
		   });
		 }
		$('form.jobsearch-banner-search').attr('action', window.location.href+'jobs-listing/');
		//Slider for jobs of company type
		//Slider for jobs of company type
		$('.jobs-listing.teck_startup').slick({ 
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: false,
            infinite: true,
            autoplay: false,
            rows: 0,
            prevArrow: '<span class="ab-carousel-btn prev-item">‹</span>',
            nextArrow: '<span class="ab-carousel-btn next-item ">›</span>',
            
            responsive: [
             {
                 breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                 }
             },
            {
                breakpoint: 576,
                settings: {
                     slidesToShow: 1,
                 }
            }
            ]
        });
        $('.jobs-listing.global_companies').slick({ 
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: false,
            infinite: true,
            autoplay: false,
            rows: 0,
            prevArrow: '<span class="ab-carousel-btn prev-item">‹</span>',
            nextArrow: '<span class="ab-carousel-btn next-item ">›</span>',
            
            responsive: [
             {
                 breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                 }
             },
            {
                breakpoint: 576,
                settings: {
                     slidesToShow: 1,
                 }
            }
            ]
        });
        $('.jobs-listing.local_corporates').slick({ 
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: false,
            infinite: true,
            autoplay: false,
            rows: 0,
            prevArrow: '<span class="ab-carousel-btn prev-item">‹</span>',
            nextArrow: '<span class="ab-carousel-btn next-item ">›</span>',
            
            responsive: [
             {
                 breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                 }
             },
            {
                breakpoint: 576,
                settings: {
                     slidesToShow: 1,
                 }
            }
            ]
        });
        $('.jobs-listing.small_medium_emterpries').slick({ 
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: true,
            dots: false,
            infinite: true,
            autoplay: false,
            rows: 0,
            prevArrow: '<span class="ab-carousel-btn prev-item">‹</span>',
            nextArrow: '<span class="ab-carousel-btn next-item ">›</span>',
            
            responsive: [
             {
                 breakpoint: 1024,
                  settings: {
                    slidesToShow: 2,
                 }
             },
            {
                breakpoint: 576,
                settings: {
                     slidesToShow: 1,
                 }
            }
            ]
        });
		
		MyLibrary.ab_MyCarousel('.candidate_portfolio', '.candidate_portfolio .grid', 5, 1, true, true, true, true, false, false, false, '', 2, true, false, 2, true, false);
		$('.listin-filters-sidebar .jobsearch-filter-responsive-wrap:not(.job-alerts-sec)').wrapAll('<div class="wrap-items"><div class="list-items"></div></div>'); 
		$( document ).on( 'elementor/popup/show', () => {
// 			if(MyLibrary.getCookie('job_alerts') == 'true'){
// 				$('.elementor-popup-modal').addClass('hide-popup');
// 			}
			
			//added by jon
			if(jQuery(".wpcf7-form").length < 1){
				wpcf7.init(jQuery(".wpcf7-form"));   
				
			}
			
// 			for(var i = 0; i < jQuery(".wpcf7-form").length ; i++)    {
// 				wpcf7.init(jQuery(".wpcf7-form")[i]);   
// 			}
			
			
// 			$('.wpcf7').on( 'wpcf7mailsent', function( event ) {
// 				$('.job-alert-form').hide();
// 				$('.job-alert-success').show();
// 				MyLibrary.setCookie('job_alerts','true')
// 			} );
			var industry = $('.options-popup .industry').html();
			$('.job-alerts select[name="industry"]').append(industry);
			var job_type = $('.options-popup .job-type').html();
			$('.job-alerts select[name="job_function"]').append(job_type);
			var location = $('.options-popup .location').html();
			$('.job-alerts select[name="location"]').append(location);
		});
		$('body.single-job .jobsearch-candcover-uplodholdr .jobsearch-fileUpload').append('<a href="javascript:void(0);" class="jobsearch-cv-manager-link jobsearch-deluser-coverfile custom-remove-cv-css" data-id="'+$('input[name="cover_file_item"]').val()+'"><i class="jobsearch-icon jobsearch-rubbish"></i>Remove CV</a>');
		setTimeout(function() { 
			$('.jobsearch-banner-search input[placeholder="Select Sector"]').attr('placeholder','Job Function');
		}, 100);
		$('.block.salary .content p').text($('.block.salary .content p').text().replaceAll('.',','));

		$('.buynew-plans-list tbody tr:nth-child(3)').insertBefore('.buynew-plans-list tbody tr:nth-child(2)');
		if($('.listin-filters-sidebar')[0]){
			$('.jobsearch-filter-responsive-wrap').each(function(){
				if($(this).find('.jobsearch-click-btn').text() == 'Skills'){
					$(this).find('.jobsearch-click-btn').text('Skills Level');
				}
			});
		}

		//added by jon changed ' '=>''
		$('input.local-search').val('');
		$('.local-search').keyup( function(){
			var key = $(this).val();
			if(key){
				key = key.toLowerCase();
				$(this).parent().find('ul li').filter(function(){
					$(this).toggle($(this).text().toLowerCase().indexOf(key) > -1);
				});
			}
			else{
				$(this).parent().find('li').show();
			}
		});
		$('.select-country-wrap input').keyup( function(){
			var key = $(this).val();
			if(key){
				key = key.toLowerCase();
				$(this).parent().find('.select-country .option').filter(function(){
					$(this).toggle($(this).text().toLowerCase().indexOf(key) > -1);
				});
			}
			else{
				$(this).parent().find('.option').show();
			}
		});
		$(document).on('click','.jobsearch-icon.jobsearch-multimedia', function(){
			$(this).toggleClass('active');
			if($(this).hasClass('active')){
				$(this).parent().find('input').attr('type', 'text');
			}
			else{
				$(this).parent().find('input').attr('type', 'password');
			}

		});
		
		if($('#job-posting-form')[0] && $('li.technical-skills')[0]){
			var technical_skills_html = $('li.technical-skills')[0].outerHTML;
			$('li.technical-skills').remove();
			$('.append-skills').after(technical_skills_html);
			var technical_skills_html = $('li.none-technical-skills')[0].outerHTML;
			$('li.none-technical-skills').remove();
			$('.append-skills').after(technical_skills_html);

			var job_apply_type = $('li.job-apply-type')[0].outerHTML;
			$('li.job-apply-type').remove();
			$('.custom_fields_skillid .jobsearch-employer-profile-form').append(job_apply_type);

			var job_apply_external_url = $('#job-apply-external-url')[0].outerHTML;
			$('#job-apply-external-url').remove();
			$('.custom_fields_skillid .jobsearch-employer-profile-form').append(job_apply_external_url);
		}
		$(document).on('keyup','input[name="new_pass"], input[name="re_new_pass"]', function(){
			var new_pass = $('input[name="new_pass"]').val();
			var re_new_pass = $('input[name="re_new_pass"]').val();
			if(new_pass && re_new_pass){
				if(new_pass != re_new_pass){
					$('.match').remove();
					$('.jobsearch-user-form').append('<p class="match">Password does not match</p>');
				}else{
					$('.match').remove();
				}
				
			}
		});
		//
		
		// Set a Cookie
		function setCookie(cname, cvalue, exdays) {
			const d = new Date();
			d.setTime(d.getTime() + (exdays*24*60*60*1000));
			let expires = "expires="+ d.toUTCString();
			document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
		}
		// getcookie
		function getCookie(cname) {
			let name = cname + "=";
			let decodedCookie = decodeURIComponent(document.cookie);
			let ca = decodedCookie.split(';');
			for(let i = 0; i <ca.length; i++) {
				let c = ca[i];
				while (c.charAt(0) == ' ') {
					c = c.substring(1);
				}
				if (c.indexOf(name) == 0) {
					return c.substring(name.length, c.length);
				}
			}
			return "";
		}
		var job_ids = [];
		$(document).on('click','.for-send-email .close', function(e){
			e.preventDefault();
			$('.for-send-email').removeClass('active');
		});
		$(document).on('click','.add-to-email', function(e){
			e.preventDefault();
			var job_id = $(this).data('id');
			if(getCookie('job_ids')){
				job_ids = $.unique(getCookie('job_ids').split(','));
			}
			job_ids.push(job_id);
			setCookie('job_ids', job_ids, 30);
			$(this).parent().find('.for-send-email').addClass('active');
			console.log(getCookie('job_ids'));
		});
		$(document).on('click','.send-to-email', function(e){
			e.preventDefault();
			var email = $(this).parents('.send-email').find('.add-to-email').data('email');
			var filterData = {
			  	action: 'send_list_jobs_to_email', // Action này sẽ được xử lý bởi một action trong functions.php
			  	job_ids: getCookie('job_ids'), // Lấy giá trị tìm kiếm từ input
			  	email: email,
			  };
			  $.ajax({
			  	url: ajaxurl, // ajaxurl là biến WordPress cung cấp
			  	type: 'POST',
			  	data: filterData,
			  	beforeSend: function() {
			  		$('.loader').show();
			  	},
			  	success: function(response) {
			  		$('.loader').hide();
			  		$('.mess').text(response);
			  		$('.mess').show();

			  	},
			  	error: function(xhr, ajaxOptions, thrownError) {
					// Hiển thị thông báo lỗi nếu có lỗi xảy ra
			  	}
			  });
			});
		if($('.return-to-shop')[0]){
			$('.button.wc-backward').text('Return to your dashboard');
			$('.button.wc-backward').attr('href', $('.elementor-widget-theme-site-logo a').attr('href')+'/user-dashboard/' );
		}
		var countries = [
			"Afghanistan",
			"Albania",
			"Algeria",
			"Andorra",
			"Angola",
			"Antigua and Barbuda",
			"Argentina",
			"Armenia",
			"Australia",
			"Austria",
			"Azerbaijan",
			"Bahamas",
			"Bahrain",
			"Bangladesh",
			"Barbados",
			"Belarus",
			"Belgium",
			"Belize",
			"Benin",
			"Bhutan",
			"Bolivia",
			"Bosnia and Herzegovina",
			"Botswana",
			"Brazil",
			"Brunei",
			"Bulgaria",
			"Burkina Faso",
			"Burundi",
			"Cabo Verde",
			"Cambodia",
			"Cameroon",
			"Canada",
			"Central African Republic",
			"Chad",
			"Chile",
			"China",
			"Colombia",
			"Comoros",
			"Congo",
			"Costa Rica",
			"Cote d'Ivoire",
			"Croatia",
			"Cuba",
			"Cyprus",
			"Czech Republic",
			"Denmark",
			"Djibouti",
			"Dominica",
			"Dominican Republic",
			"East Timor",
			"Ecuador",
			"Egypt",
			"El Salvador",
			"Equatorial Guinea",
			"Eritrea",
			"Estonia",
			"Eswatini",
			"Ethiopia",
			"Fiji",
			"Finland",
			"France",
			"Gabon",
			"Gambia",
			"Georgia",
			"Germany",
			"Ghana",
			"Greece",
			"Grenada",
			"Guatemala",
			"Guinea",
			"Guinea-Bissau",
			"Guyana",
			"Haiti",
			"Honduras",
			"Hungary",
			"Iceland",
			"India",
			"Indonesia",
			"Iran",
			"Iraq",
			"Ireland",
			"Israel",
			"Italy",
			"Jamaica",
			"Japan",
			"Jordan",
			"Kazakhstan",
			"Kenya",
			"Kiribati",
			"Korea, North",
			"Korea, South",
			"Kosovo",
			"Kuwait",
			"Kyrgyzstan",
			"Laos",
			"Latvia",
			"Lebanon",
			"Lesotho",
			"Liberia",
			"Libya",
			"Liechtenstein",
			"Lithuania",
			"Luxembourg",
			"Macedonia",
			"Madagascar",
			"Malawi",
			"Malaysia",
			"Maldives",
			"Mali",
			"Malta",
			"Marshall Islands",
			"Mauritania",
			"Mauritius",
			"Mexico",
			"Micronesia",
			"Moldova",
			"Monaco",
			"Mongolia",
			"Montenegro",
			"Morocco",
			"Mozambique",
			"Myanmar",
			"Namibia",
			"Nauru",
			"Nepal",
			"Netherlands",
			"New Zealand",
			"Nicaragua",
			"Niger",
			"Nigeria",
			"Norway",
			"Oman",
			"Pakistan",
			"Palau",
			"Panama",
			"Papua New Guinea",
			"Paraguay",
			"Peru",
			"Philippines",
			"Poland",
			"Portugal",
			"Qatar",
			"Romania",
			"Russia",
			"Rwanda",
			"Saint Kitts and Nevis",
			"Saint Lucia",
			"Saint Vincent and the Grenadines",
			"Samoa",
			"San Marino",
			"Sao Tome and Principe",
			"Saudi Arabia",
			"Senegal",
			"Serbia",
			"Seychelles",
			"Sierra Leone",
			"Singapore",
			"Slovakia",
			"Slovenia",
			"Solomon Islands",
			"Somalia",
			"South Africa",
			"South Sudan",
			"Spain",
			"Sri Lanka",
			"Sudan",
			"Suriname",
			"Sweden",
			"Switzerland",
			"Syria",
			"Taiwan",
			"Tajikistan",
			"Tanzania",
			"Thailand",
			"Togo",
			"Tonga",
			"Trinidad and Tobago",
			"Tunisia",
			"Turkey",
			"Turkmenistan",
			"Tuvalu",
			"Uganda",
			"Ukraine",
			"United Arab Emirates",
			"United Kingdom",
			"United States",
			"Uruguay",
			"Uzbekistan",
			"Vanuatu",
			"Vatican City",
			"Venezuela",
			"Vietnam",
			"Yemen",
			"Zambia",
			"Zimbabwe",
			];
		var selectCountry = $(".select-country");
		$.each(countries, function(index, country) {
			selectCountry.append('<div class="option" data-value="' + country + '">' + country + '</div>');
		});
		$(document).on('click','.submit-wrap .jobsearch-employer-profile-submit',function(e){
			//e.preventDefault();
			$('input[name="status"]').val($(this).attr('name'));
			$("#job-posting-form").submit();
		});
		$(document).on('click','.submit-wrap .back-to-draf-folder',function(e){
			e.preventDefault();
			window.location.href = $(this).attr('redirect_url');
		});
		if($('textarea[name="cand_cover_letter"]')[0]){
			//added by jon
// 		   var html = '<div class="editor-length" data-max="800"  style="padding: 15px 0;"><label>Please do not exceed 800 characters</label><div class="counter-wrap"><span>Length: </span><span class="counter">0</span></div</div><span class="field-error"></span>';
		   var html = '<div class="editor-length" data-max="800"  style="padding: 15px 0; font-size:14px;"><label>Please do not exceed 800 characters</label><div class="counter-wrap"><span class="counter">0 characters remaining</span></div</div><span class="field-error"></span>';
			$('textarea[name="cand_cover_letter"]').after(html);
			var visual_editor_char_limit = 800;
			var html_editor_char_limit = 800;
// 			var char_limit_warning = "Stop! You are exceeding 800 characters!";
			var editor_content = $('textarea[name="cand_cover_letter"]').val();
// 			$('.counter').text(editor_content.length);
			$('.counter').text(800 - editor_content.length + ' characters remaining');
			$('textarea[name="cand_cover_letter"]').keyup(function(){
// 				$('.counter').text($(this).val().length);
				$('.counter').text(800 - $(this).val().length + ' characters remaining');
// 				$('.editor-length label').text('Please do not exceed 5,000 characters');
				$('.editor-length label').css('color','#333');
				if($(this).val().length >  html_editor_char_limit){
// 					$('.editor-length label').text(char_limit_warning);
// 					$('.editor-length label').css('color','red');
					$('.counter').css('color','red');
					$('.counter-wrap').css('color','red');
				}
				else {
// 					$('.editor-length label').text('Please do not exceed 800 characters');
// 					$('.editor-length label').css('color','#333');
					$('.counter').css('color','#333');
					$('.counter-wrap').css('color','#333');
				}
			});
		}
		
	});
	mdp_editor_validate_limit_text('#wp-user_bio-wrap','#user_bio');
	 function mdp_editor_validate_limit_text(wrap,selector){
		if( $(wrap)[0]){
			var html = '<div class="editor-length" data-max="3000"><label></label><div class="counter-wrap"><span> </span><span class="counter">0</span></div</div><span class="field-error"></span>';
			$(wrap).append(html);
			var visual_editor_char_limit = 3000;
			var html_editor_char_limit = 3000;
			var char_limit_warning = "Stop! You are exceeding 3,000 characters!";
			var counter_value = 0;
			window.onload = function () {
				// are we using visual editor?
				var visual = (typeof tinyMCE != "undefined") && tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()?true:false;
				var editor_content = tinyMCE.activeEditor.getContent().replace(/(<[a-zA-Z\/][^<>]*>|\[([^\]]+)\])/ig,'');
				$('.counter').text((visual_editor_char_limit - editor_content.length)+' characters remaining');
				tinyMCE.activeEditor.on('keyup', function(ed,e) {
					editor_content = this.getContent().replace(/(<[a-zA-Z\/][^<>]*>|\[([^\]]+)\])/ig,'');
					counter_value = visual_editor_char_limit - editor_content.length;
					$('.counter').text(counter_value+' characters remaining');
// 					$('.editor-length label').text('Please do not exceed 3,000 characters');
					$('.editor-length label').text('');
// 					$('.editor-length label').css('color','#333');
					if ( editor_content.length > visual_editor_char_limit ) {

// 						$('.editor-length label').text(char_limit_warning);
// 						$('.editor-length label').css('color','red');
						$('.editor-length label').text('You have exceeded 3000 characters.');
						$('.editor-length label').css('color','red');
// 						$('.counter').text(char_limit_warning);
						$('.counter').css('color','red');
						

					} else {
// 						$('.editor-length label').text('Please do not exceed 3,000 characters');
// 						$('.editor-length label').css('color','#333');
						$('.editor-length label').text('');
						$('.counter').text(counter_value+' characters remaining');
						$('.counter').css('color','#333');
					}

				});

				// do we have html editor?
				if($(selector).length){
					$(selector).keyup(function(){
						$('.counter').text($(this).val().length);
						$('.editor-length label').text('Please do not exceed 3,000 characters');
						$('.editor-length label').css('color','#333');
						if($(this).val().length >  html_editor_char_limit){
// 							$('.editor-length label').text(char_limit_warning);
							$('.counter').text(counter_value+' characters remaining');
							$('.counter').css('color','red');
							$('.editor-length label').text('You have exceeded 3000 characters.');
							$('.editor-length label').css('color','red');
						}
						else {
							$('.editor-length label').text('');
							$('.editor-length label').css('color','#333');
							$('.counter').text(counter_value+' characters remaining');
							$('.counter').css('color','#333');
						}
					});

				}
			}
		}
	
	 }
	
	$(document).ready(function() {
        //added by jon april 2024
        function updateSignUpText() {
            var reg_user_role = $('input[name="pt_user_role"]:checked').val();
            if (reg_user_role == 'jobsearch_candidate') {
                $('.sign-up-class').html('Sign up to apply for jobs');
            } else if (reg_user_role == 'jobsearch_employer') {
                $('.sign-up-class').html('Sign up as a Recruiter to post jobs');
            }
        }

        // Attach the function to the change event of the radio buttons
        $('input[name="pt_user_role"]').change(updateSignUpText);

        // Initialize the text on page load
        updateSignUpText();
		
    });
	
	/*$('ul[data-key="company_type"] li').click(function() {
        // Define a boolean to check if the clicked item is already active
        var isActive = $(this).hasClass('active');
		var to_remove = [];
		
        // Check if the clicked <li> is 'All Employers'
        if ($(this).text().trim() === 'All Employers') {
            if (!isActive) {
                // Add 'active' class to 'All Employers' and remove from all others
                $(this).siblings().removeClass('active');
            } // If it's already active, do nothing
        }else{
			$(this).siblings().each(function() {
				if ($(this).text().trim() === 'All Employers') {
					to_remove.push(this);
				}
			});
			$(to_remove).removeClass('active');
		}
		
    });*/
	
	$(document).on('click', '.menu-item-type-custom', function() {
		$('.elementor-menu-toggle').each(function() {
			var menuToggle = $(this);
			if (menuToggle.find('.elementor-menu-toggle__icon--open').length > 0) {
				if (menuToggle.attr('aria-expanded') === 'true') {
					menuToggle.click();
				}
			}
		});
	});
	
	document.addEventListener('DOMContentLoaded', function() {
		function checkAndTriggerClick() {
			if (window.innerWidth < 480 && document.querySelector('.bp-messages-mobile-tap')) {
				document.querySelector('.bp-messages-mobile-tap').click();
				
			}
			
		}

		setTimeout(checkAndTriggerClick, 1000);
	});
	
	/*for job alert*/
	document.addEventListener('DOMContentLoaded', function() {
		// Get the modal
		var modal = document.getElementById("job-alerts-modal");

		// Get the button that opens the modal
		var btn = document.getElementById("job-alerts-button"); // Assumes there's a button with this ID

		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("job-alerts-modal-close")[0];

		// When the user clicks the button, open the modal 
		if (btn) {
			btn.onclick = function() {
				modal.style.display = "block";
				document.documentElement.style.overflow = 'hidden'; // Disable scroll on <html>
				document.documentElement.style.touchAction = 'none'; // Disable touch interactions on <html>

				document.body.style.overflow = 'hidden'; // Disable scroll on <body>
				document.body.style.userSelect = 'none'; // Disable text selection on <body>
				document.body.style.webkitUserDrag = 'none'; // Disable dragging on <body>
			}
		}

		// When the user clicks on <span> (x), close the modal
		if (span) {
			span.onclick = function() {
				if (modal) {
					modal.style.display = "none";
					document.documentElement.style.overflow = ''; // Reset scroll on <html>
					document.documentElement.style.touchAction = ''; // Reset touch interactions on <html>

					document.body.style.overflow = ''; // Reset scroll on <body>
					document.body.style.userSelect = ''; // Reset text selection on <body>
					document.body.style.webkitUserDrag = ''; // Reset dragging on <body>
				}
			}
		}

		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
				document.documentElement.style.overflow = ''; // Reset scroll on <html>
				document.documentElement.style.touchAction = ''; // Reset touch interactions on <html>

				document.body.style.overflow = ''; // Reset scroll on <body>
				document.body.style.userSelect = ''; // Reset text selection on <body>
				document.body.style.webkitUserDrag = ''; // Reset dragging on <body>
			}
		}
	});
	$(document).on('click','#job-alerts-modal div.jobsearch-select-style .filter-item-job-alert span', function(){
		$('div.jobsearch-select-style').removeClass('active');
		$(this).parents('div.jobsearch-select-style').addClass('active');
		$(this).parent().find('.job-alert-count').text($(this).parent().find('li.active').length);
	});
	$(document).on('click','#job-alerts-modal .close,.buttons-action .select', function(){
		$('div.jobsearch-select-style').removeClass('active');
		
		if($(this).closest('.jobsearch-select-style').find('li.active').length > 0){
			$(this).closest('.jobsearch-select-style').css('color', 'black');
		}else{
			$(this).closest('.jobsearch-select-style').css('color', '');
		}
	});
	$(document).on('click','.buttons-action .reset', function(){
		$(this).parents('.job-alert-select-style').find('li').removeClass('active');
		$(this).parents('.job-alert-select-style').find('.job-alert-count').text('0');
		$(this).parents('.job-alert-select-style').next().find('.job-alert-count').text('0');
		$(this).parents('.job-alert-select-style').find('input[type="hidden"]').val('');
		$(this).parents('.job-alert-select-style').find('.filter-item-job-alert > span').text($(this).parents('.job-alert-select-style').find('.filter-item-job-alert span').data('default-text'));
	});
	
	var jobAlertSwitch = document.getElementById('job-alert-notific-switch');
	if (jobAlertSwitch) {
		document.getElementById('job-alert-notific-switch').addEventListener('click', function() {
			var notificCheckbox = document.getElementById('job-alert-notific');
			var emailNotificationCheckbox = document.querySelector('input[name="job_alerts_email_notification"]');
			var saveButton = document.getElementById('save-preferences-job-alerts');

			// Add event listener for the notificCheckbox
			notificCheckbox.addEventListener('change', function() {
				emailNotificationCheckbox.checked = notificCheckbox.checked;
				saveButton.click(); 
				var loader = $('.opt-notific-lodr-custom');
				loader.html('<i class="fa fa-refresh fa-spin"></i>');
				setTimeout(function() {
					loader.html('<i class="fa fa-check"></i>');	
				}, 3500);

			});

		});
	}
	/*for job alert end*/
	$(document).on('click', '.employer-followed-already', function () {
	    var _this = $(this);
	    var uid = _this.attr('data-id');
	    var loader_con = _this.find('i');

	    loader_con.attr('class', 'fa fa-refresh fa-spin');
	    var request = $.ajax({
	        url: ajaxurl,
	        method: "POST",
	        data: {
	            'emp_id': uid,
	            'action': 'jobsearch_userdash_rem_emp_followin'
	        },
	        dataType: "json"
	    });
	    request.done(function (response) {
	        if (typeof response.success !== 'undefined' && response.success == '1') {
	            _this.parents('li').slideUp();
	            var doin_refresh = setInterval(function () {
	                window.location.reload(true);
	                clearInterval(doin_refresh);
	            }, 500);
	        }
	    });

	    request.fail(function (jqXHR, textStatus) {
	        loader_con.attr('class', 'jobsearch-icon jobsearch-rubbish');
	    });
	});
	
	$(document).on('click', '.jobsearch-pst-title a', function (e) {
	    const scrollPosition = $(window).scrollTop(); 
	    const currentUrl = window.location.href;
	    localStorage.setItem('scrollPosition', scrollPosition); 
	    localStorage.setItem('lastVisitedUrl', currentUrl); 
	});
	$(window).on('load', function () {
	    const scrollPosition = localStorage.getItem('scrollPosition');
	    const lastVisitedUrl = localStorage.getItem('lastVisitedUrl');
	    const currentUrl = window.location.href; 

	    if (lastVisitedUrl === currentUrl && scrollPosition) {
	        $(window).scrollTop(parseInt(scrollPosition));
	        localStorage.removeItem('scrollPosition'); 
	        localStorage.removeItem('lastVisitedUrl');
	    }
	});
	
	//Back to top
	$(window).on('load',function () {
		if ($('#back-to-top')[0]) {
			$(document).on('click', '#back-to-top', function (e) {
				e.preventDefault();
				$('html, body').animate({
					scrollTop: 0
				}, 700);
			});
		}
	});
	$(document).on('click', 'body:not(.logged-in) .open-register-tab-recruiter', function(e){
		e.preventDefault();
		$('.jobsearch-open-register-tab').trigger('click');
		$('.jobsearch-user-type-choose li').removeClass('active');
		$('.jobsearch-user-type-choose li:last-child').addClass('active');
		$('.jobsearch-user-form .user-employer-spec-field').show();
	});
	$(document).on('click', 'body:not(.logged-in) .open-register-tab-seeker', function(e){
		e.preventDefault();
		$('.jobsearch-open-register-tab').trigger('click');
	});
	$(document).on('click','body.logged-in .logged-in-welcome', function(){
		$('.mdp-popup.welcome').addClass('active');
	});
	$(document).on('click','.mdp-popup.welcome .close, .mdp-popup.welcome a', function(){
		$(this).parents('.welcome').removeClass('active');
	});
	
	$('.list-applicant-items').each(function(index) {
        let $list = $(this);
        let $pagination = $list.next('.pagination-wraper');
        let itemsPerPage = 5;
        let totalItems = $list.children('.applicant-item').length;
        let totalPages = Math.ceil(totalItems / itemsPerPage);
        let currentPage = 1;

        function showPage(page) {
            $list.children('.applicant-item').hide();
            $list.children('.applicant-item').slice((page - 1) * itemsPerPage, page * itemsPerPage).show();
        }

        function updatePagination() {
            let $pageNumbers = $pagination.find('.pageNumbers');
            $pageNumbers.empty();
            for (let i = 1; i <= totalPages; i++) {
                $pageNumbers.append(`<button class="page" data-page="${i}">${i}</button>`);
            }
            $pageNumbers.find('.page').removeClass('active');
            $pageNumbers.find(`.page[data-page="${currentPage}"]`).addClass('active');
        }

        $pagination.on('click', '.page', function() {
            currentPage = parseInt($(this).data('page'));
            showPage(currentPage);
            updatePagination();
        });

        $pagination.find('.prev').click(function() {
            if (currentPage > 1) {
                currentPage--;
                showPage(currentPage);
                updatePagination();
            }
        });

        $pagination.find('.next').click(function() {
            if (currentPage < totalPages) {
                currentPage++;
                showPage(currentPage);
                updatePagination();
            }
        });

        showPage(currentPage);
        updatePagination();
    });
	//Chat message
	if($('.new-chat-private a')[0]){
	   	var chat_url = $('.group-features .new-chat-private a').attr('href');
		var newMessage = $('.group-features .new-chat-private').attr('data-message');
		newMessage = encodeURIComponent(newMessage);
		var updatedUrl = chat_url.replace(/([?&]message=)[^&]*/, `$1${newMessage}`);
		$('.group-features .new-chat-private a').attr('href', updatedUrl);
	}
})(jQuery);;