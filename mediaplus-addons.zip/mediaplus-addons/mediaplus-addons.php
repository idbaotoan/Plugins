<?php
/**
* Plugin Name: MediaPlus Addons
* Description: Special features developed by Mediaplus for special projects.
* Plugin URI:  https://mediaplus.com.sg/
* Version:     1.0.0
* Author:      Travis - Mediaplus
* Author URI:  https://mediaplus.com.sg/
* Text Domain: mediaplus
* License:     GPL-2.0+
* License URI: http://www.gnu.org/licenses/gpl-2.0.txt
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

define('MDP_DIR', __DIR__ . '/');
define('MDP_URI', str_replace(['http:', 'https:'], '', plugins_url('/', __FILE__)));
/*===================================*/
/* FontEnd */
function mediaplus_enqueue_scripts() {
    // Style
    wp_enqueue_style( 'mediaplus-style', MDP_URI . 'assets/css/frontend-style.css');
    //Script
    wp_enqueue_script( 'mediaplus-script', MDP_URI . 'assets/js/frontend-scripts.js', array('jquery-core'), false, true);
}
add_action( 'wp_enqueue_scripts', 'mediaplus_enqueue_scripts' );
/*===================================*/
/* Admin */
function mediaplus_admin_enqueue_scripts() {
    wp_enqueue_style( 'mediaplus-style', MDP_URI . 'assets/css/admin-style.css');
    //Script
    wp_enqueue_script( 'mediaplus-script', MDP_URI . 'assets/js/admin-scripts.js', array('jquery-core'), false, true);
}
add_action( 'admin_enqueue_scripts', 'mediaplus_admin_enqueue_scripts' );
/*===================================*/
/* Require files */
require MDP_DIR . 'includes/functions.php';
require MDP_DIR . 'includes/features.php';
require MDP_DIR . 'includes/hooks.php';
require MDP_DIR . 'includes/shortcodes.php';