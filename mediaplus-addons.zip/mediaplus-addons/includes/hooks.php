<?php
/*
* Hooks
* Author: Travis - Mediaplus
*/
//Add ajax url
function ab_ajax_url(){
    ?>
    <script type="text/javascript">
        var ajaxurl = "<?php echo esc_url(admin_url('admin-ajax.php')); ?>";
    </script>
    <?php
}
add_action('wp_head','ab_ajax_url',999);