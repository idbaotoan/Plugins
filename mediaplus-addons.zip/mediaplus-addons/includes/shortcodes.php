<?php
/*
* Shortcodes
* Author: Travis - Mediaplus
*/