<?php
/*
* Features
* Author: Travis - Mediaplus
*/


// Format currency 
if (!function_exists('currency_format')) {
    function currency_format($number, $suffix = '') {
        if (!empty($number)) {
            return "{$suffix}".number_format($number, 0, ',', ',') ;
        }
    }
}
// Pagination
if ( ! function_exists( 'mdp_pagination' ) ) {
    function mdp_pagination( $range = 2, $current_query = '', $pages = '', $prev_icon = '‹', $next_icon = '›' ) {
        // Đảm bảo $range là số và hợp lệ
        $range = max( 1, (int) $range );
        $showitems = ( $range * 2 ) + 1;

        // Xác định trang hiện tại
        if ( empty( $current_query ) ) {
            global $paged;
            $paged = empty( $paged ) ? 1 : $paged;
        } else {
            $paged = isset( $current_query->query_vars['paged'] ) ? $current_query->query_vars['paged'] : 1;
        }

        // Xác định tổng số trang
        if ( empty( $pages ) ) {
            if ( empty( $current_query ) ) {
                global $wp_query;
                $pages = $wp_query->max_num_pages;
            } else {
                $pages = $current_query->max_num_pages;
            }
            $pages = $pages ? $pages : 1;
        }

        // Hiển thị phân trang nếu có nhiều hơn 1 trang
        if ( $pages > 1 ) { ?>
            <div class="mdp-pagination clearfix" role="navigation" aria-label="Pagination">
                <?php
                // Nút Previous
                if ( $paged > 1 ) { ?>
                    <a class="mdp-pagination-prev mdp_pagination-item" data-pag="<?php echo esc_attr( $paged - 1 ); ?>" href="<?php echo esc_url( get_pagenum_link( $paged - 1 ) ); ?>" aria-label="Previous Page">
                        <?php echo esc_html( $prev_icon ); ?>
                    </a>
                <?php }

                // Các nút số trang
                for ( $i = 1; $i <= $pages; $i++ ) {
                    // Chỉ hiển thị các trang trong phạm vi $range
                    if ( $i == 1 || $i == $pages || ( $i >= $paged - $range && $i <= $paged + $range ) ) {
                        if ( $paged === $i ) { ?>
                            <span class="current mdp_pagination-item" aria-current="page"><?php echo esc_html( $i ); ?></span>
                        <?php } else { ?>
                            <a class="inactive mdp_pagination-item" data-pag="<?php echo esc_attr( $i ); ?>" href="<?php echo esc_url( get_pagenum_link( $i ) ); ?>">
                                <?php echo esc_html( $i ); ?>
                            </a>
                        <?php }
                    } elseif ( $i == $paged - $range - 1 || $i == $paged + $range + 1 ) {
                        // Hiển thị dấu "..." nếu có khoảng cách giữa các trang
                        echo '<span class="mdp-pagination-dots">…</span>';
                    }
                }

                // Nút Next
                if ( $paged < $pages ) { ?>
                    <a class="mdp-pagination-next mdp_pagination-item" data-pag="<?php echo esc_attr( $paged + 1 ); ?>" href="<?php echo esc_url( get_pagenum_link( $paged + 1 ) ); ?>" aria-label="Next Page">
                        <?php echo esc_html( $next_icon ); ?>
                    </a>
                <?php } ?>
            </div>
        <?php }
    }
}