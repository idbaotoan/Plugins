<?php

class FacetWP_Facet_Range_List_Addon extends FacetWP_Facet
{

    function __construct() {
        $this->label = __( 'Range List', 'fwp' );
    }


    /**
     * Load the available choices
     */
    function load_values( $params ) {
        global $wpdb;

        $facet = $params['facet'];
        $from_clause  = $wpdb->prefix . 'facetwp_index f';
        $where_clause = $this->get_where_clause( $facet );

        $from_clause  = apply_filters( 'facetwp_facet_from', $from_clause, $facet );
        $where_clause = apply_filters( 'facetwp_facet_where', $where_clause, $facet );

        $sql = "
        SELECT f.facet_value, f.post_id
        FROM $from_clause
        WHERE f.facet_name = '{$facet['name']}' $where_clause";

        $results = $wpdb->get_results( $sql, ARRAY_A );
        $output  = [];

        // Build groups
        foreach ( $params['facet']['levels'] as $level => $setting ) {
            $min = $this->get_range_value( 'min', $level, 'down', $params['facet']['levels'] );
            $max = $this->get_range_value( 'max', $level, 'up', $params['facet']['levels'] );
            $auto_display = 'All';

            if ( ! empty( $min ) && ! empty( $max ) ) {
                $auto_display = $min . ' - ' . $max;
                $value = $min . '-' . $max;
            }
            elseif ( empty( $min ) && ! empty( $max ) ) {
                $auto_display = 'Up to ' . $max;
                $value = '0-' . $max;
            }
            elseif ( ! empty( $min ) && empty( $max ) ) {
                $auto_display = $min . ' and up';
                $value = $min . '+';
            }

            $display = empty( $setting['label'] ) ? $auto_display : $setting['label'];

            $output[] = [
                'counter' => $this->get_counts( $results, $min, $max ),
                'facet_value' => $value,
                'facet_display_value' => $display,
                'depth' => 0
            ];
        }

        return $output;
    }


    /**
     * Get the lowest value
     */
    function get_range_value( $type, $level, $direction, $levels ) {
        $val = null;

        if ( ! empty( $levels[ $level ][ $type ] ) ) {
            $val = $levels[ $level ][ $type ];
        }
        elseif ( $level > 0 && $level < count( $levels ) ) {
            $type = ( 'min' == $type ) ? 'max' : 'min';
            $level = ( 'up' == $direction ) ? $level + 1 : $level - 1;
            $val = $this->get_range_value( $type, $level, $direction, $levels );
        }

        return $val;
    }


    /**
     * Filter out irrelevant choices
     */
    function get_counts( $results, $start, $end ) {
        $count = 0;

        foreach ( $results as $result ) {
            if ( $result['facet_value'] >= $start ) {
                if ( is_null( $end ) || $result['facet_value'] <= $end ) {
                    $count += 1;
                }
            }
        }

        return $count;
    }


    /**
     * Generate the facet HTML
     */
    function render( $params ) {

        $output = '';
        $values = (array) $params['values'];
        $selected_values = (array) $params['selected_values'];

        foreach ( $values as $key => $result ) {
            $selected = in_array( $result['facet_value'], $selected_values ) ? ' checked' : '';
            $selected .= ( 0 == $result['counter'] && '' == $selected ) ? ' disabled' : '';
            $output .= '<div class="facetwp-radio' . $selected . '" data-value="' . esc_attr( $result['facet_value'] ) . '">';
            $output .= esc_html( $result['facet_display_value'] ) . ' <span class="facetwp-counter">(' . $result['counter'] . ')</span>';
            $output .= '</div>';
        }

        return $output;
    }


    /**
     * Filter the query based on selected values
     */
    function filter_posts( $params ) {
        global $wpdb;

        $facet = $params['facet'];
        $selected_values = $params['selected_values'];
        $selected_values = array_pop( $selected_values );
        $selected_values = explode( '-', $selected_values );
        $selected_values = array_map( 'floatval', $selected_values );

        $sql = "
        SELECT DISTINCT post_id FROM {$wpdb->prefix}facetwp_index
        WHERE facet_name = '{$facet['name']}' AND facet_value >= $selected_values[0]";

        if ( ! empty( $selected_values[1] ) ) {
            $sql .= " AND facet_value <= $selected_values[1] ";
        }

        return facetwp_sql( $sql, $facet );
    }


    /**
     * Output any front-end scripts
     */
    function front_scripts() {
        FWP()->display->assets['range-list-front.js'] = plugins_url( '', __FILE__ ) . '/assets/js/front.js';
    }


    /**
     * Output any admin scripts
     */
    function admin_scripts() {
?>

<style type="text/css">
.facet-level-row {
    padding-bottom: 10px;
}

.facet-level-row input[type="number"],
.facet-level-row input[type="text"] {
    width: 115px;
    height: 28px;
}
</style>

<script>

Vue.component('range-list', {
    props: ['facet'],
    data() {
        return {
            autofill: []
        }
    },
    template: `
    <div>
        <div class="facet-level-row" v-for="(row, index) in facet.levels">
            <input type="number" v-model="facet.levels[index].min" @input="updateLabels()" placeholder="Min Value" />
            <input type="number" v-model="facet.levels[index].max" @input="updateLabels()" placeholder="Max Value" />
            <input type="text" v-model="facet.levels[index].label" @input="maybeAutofill(index)" placeholder="Label" />
            <button @click="removeRange(index)">x</button>
        </div>
        <button @click="addRange()">Add Range</button>
    </div>
    `,
    created() {
        for (var i = 0; i < this.facet.levels.length; i++) {
            this.maybeAutofill(i);
        }
    },
    methods: {
        addRange: function() {
            this.facet.levels.push({
                min: '',
                max: '',
                label: ''
            });
            this.autofill.push(true);
        },
        removeRange: function(index) {
            Vue.delete(this.facet.levels, index);
            Vue.delete(this.autofill, index);
            this.updateLabels();
        },
        maybeAutofill: function(index) {
            var label = this.facet.levels[index].label;
            this.autofill[index] = ('' == label) ? true : false;
        },
        updateLabels: function() {
            for (var i = 0; i < this.facet.levels.length; i++) {
                if (false === this.autofill[i]) {
                    continue;
                }

                let sep = ' ';
                let min = this.facet.levels[i].min;
                let max = this.facet.levels[i].max;
                min = min.length ? parseFloat(min) : this.findLowest(i);
                max = max.length ? parseFloat(max) : this.findHighest(i);

                if ('number' === typeof min && 'number' === typeof max) {
                    sep = ' - ';
                }
                if ('string' !== typeof min || 'string' !== typeof max) {
                    this.facet.levels[i].label = min + sep + max;
                }
                else {
                    this.facet.levels[i].label = '';
                }
            }
        },
        findLowest: function(index) {
            let val = 'Up to';

            if (0 < index) {
                let lower = this.facet.levels[index-1].max;
                val = (lower.length) ? parseFloat(lower) : this.findLowest(index-1);
            }

            return val;
        },
        findHighest: function(index) {
            let val = 'and Up';

            if (index < this.facet.levels.length-1) {
                let upper = this.facet.levels[index+1].min;
                val = (upper.length) ? parseFloat(upper) : this.findHighest(index+1);
            }

            return val;
        }
    }
});

</script>
<?php
    }


    /**
     * Output admin settings HTML
     */
    function settings_html() {
        ?>
        <div class="facetwp-row">
            <div class="facetwp-col"><?php _e( 'Ranges', 'fwp' ); ?>:</div>
            <div class="facetwp-col">
                <range-list :facet="facet"></range-list>
                <input type="hidden" class="facet-levels" value="[]" />
            </div>
        </div>
        <?php
    }
}
