<?php

return [
	'title' => __( 'Ban Users', 'it-l10n-ithemes-security-pro' ),
];
