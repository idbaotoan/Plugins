# JetFormBuilder MailPoet Action
Addon for JetFormBuilder & JetEngine

# ChangeLog

## 1.0.1
* Tweak: add license manager