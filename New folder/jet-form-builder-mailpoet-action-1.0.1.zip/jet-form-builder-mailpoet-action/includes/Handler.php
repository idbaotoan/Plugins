<?php

namespace Jet_FB_MailPoet;

use JetMailPoetCore\BaseHandler;
use JetMailPoetCore\Exceptions\ApiHandlerException;
use MailPoet\API\API;

class Handler extends BaseHandler {

	private $mailpoet;

	public function ajax_action(): string {
		return 'jet_form_builder_get_mailpoet_data';
	}

	public function required_ajax_args() {
		return array();
	}

	/**
	 * @throws ApiHandlerException
	 */
	public function api() {
		if ( ! $this->mailpoet ) {
			try {
				$this->mailpoet = API::MP( 'v1' );
			} catch ( \Exception $e ) {
				throw new ApiHandlerException( $e->getMessage() );
			}
		}

		return $this->mailpoet;
	}

	/**
	 * @return array
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		$lists = $this->prepare_lists( $this->api()->getLists() );
		$fields = $this->prepare_fields( $this->api()->getSubscriberFields() );

		return array(
			'lists'  => $lists,
			'fields' => $fields,
		);
	}


	public function prepare_fields( $fields ) {
		$new_fields = array();

		foreach ( $fields as $field ) {
			$new_fields[ $field['id'] ] = array(
				'label'    => $field['name'],
				'required' => (bool) $field['params']['required'],
			);
		}

		return $new_fields;

	}

	public function prepare_lists( $lists ) {
		$new_lists = array();

		foreach ( $lists as $list ) {
			if ( isset( $list['deleted_at'] ) && $list['deleted_at'] ) {
				continue;
			}
			$new_lists[] = array(
				'label' => $list['name'],
				'value' => $list['id'],
				'desc'  => $list['description']
			);
		}

		return $new_lists;
	}


}