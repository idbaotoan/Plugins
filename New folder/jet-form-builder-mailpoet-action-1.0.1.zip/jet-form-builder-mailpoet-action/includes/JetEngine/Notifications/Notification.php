<?php


namespace Jet_FB_MailPoet\JetEngine\Notifications;


use Jet_FB_MailPoet\BaseAction;
use JetMailPoetCore\JetEngine\SmartBaseNotification;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Notification extends SmartBaseNotification {

	use BaseAction;

}

