import { getLocalizedFullPack } from "@/source";

const { source, label, help } = getLocalizedFullPack;
const { __ } = wp.i18n;

const {
		  TextControl,
		  BaseControl,
		  SelectControl,
		  ToggleControl,
		  RadioControl,
	  } = wp.components;

const {
		  useState,
		  useEffect,
	  } = wp.element;

const {
		  addAction,
		  getFormFieldsBlocks,
		  globalTab,
		  Tools: { withPlaceholder },
	  } = JetFBActions;

const {
		  ActionFieldsMap,
		  WrapperRequiredControl,
		  RequestLoadingButton,
		  ValidateButton,
		  PlaceholderMessage,
	  } = JetFBComponents;

const {
		  useSuccessNotice,
	  } = JetFBHooks;

const currentTab = globalTab( { slug: 'hubspot' } );

addAction( 'hubspot', function HubSpotAction( {
												  settings,
												  onChange,
												  onChangeSetting,
												  getMapField,
												  setMapField,
											  } ) {
	const onValidApiKey = ( { data } ) => {
		onChange( {
			...settings,
			response: data,
			isValidAPI: true,
		} );
	};

	const [ formFieldsList ] = useState( () => {
		return getFormFieldsBlocks( [], '--' );
	}, [] );

	const onInvalidApiKey = () => {
		onChangeSetting( false, 'isValidAPI' );
	};

	const apiKey = () => settings.use_global ? currentTab.api_key : settings.api_key;
	const showApiKey = ( ! settings.use_global && ! settings.auth_type || 'api_key' === settings.auth_type );

	const ajaxArgs = {
		action: source.action,
		auth_type: settings.auth_type,
		api_key: settings.api_key,
		use_global: settings.use_global,
		namespace: 'jfb',
	};

	function validButton() {
		return <ValidateButton
			initialValid={ settings.isValidAPI }
			ajaxArgs={ ajaxArgs }
			label={ settings.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }
			onValid={ onValidApiKey }
			onInvalid={ onInvalidApiKey }
		/>;
	}

	function apiHelp() {
		return <div className='margin-bottom--small'>{ help( 'api_key_link_prefix' ) } <a
			href={ help( 'api_key_link' ) }>{ help( 'api_key_link_suffix' ) }</a>
		</div>;
	}

	return <>
		<ToggleControl
			key={ 'use_global' }
			label={ label( 'use_global' ) }
			checked={ settings.use_global }
			onChange={ use_global => {
				onChangeSetting( Boolean( use_global ), 'use_global' )
			} }
		/>
		{ settings.use_global && <BaseControl
			label={ label( 'auth_type' ) }
			key={ 'base_auth_type' }
		>
			<div className='jet-control-clear-full jet-d-flex-between'>
				<RadioControl
					key={ 'auth_type' }
					selected={ settings.auth_type }
					onChange={ val => onChangeSetting( val, 'auth_type' ) }
					options={ source.auth_type }
				/>
				{ validButton() }
			</div>
		</BaseControl> }
		{ ( ! settings.use_global ) && <>
			<BaseControl
				label={ label( 'api_key' ) }
				key={ 'base_auth_type' }
			>
				<div className='jet-control-clear-full jet-d-flex-between'>
					<TextControl
						key='api_key'
						disabled={ settings.use_global }
						value={ apiKey() }
						onChange={ newVal => {
							onChangeSetting( newVal, 'api_key' )
						} }
					/>
					{ validButton() }
				</div>
			</BaseControl>
			{ apiHelp() }
		</> }
		{ ( settings.use_global && showApiKey ) && <>
			<TextControl
				key='api_key'
				label={ label( 'api_key' ) }
				disabled={ settings.use_global }
				value={ apiKey() }
				onChange={ newVal => {
					onChangeSetting( newVal, 'api_key' )
				} }
			/>
			{ apiHelp() }
		</> }
		{ settings.isValidAPI && <>
			<SelectControl
				label={ label( 'associatedcompanyid' ) }
				labelPosition="side"
				value={ settings.associatedcompanyid }
				onChange={ newVal => onChangeSetting( newVal, 'associatedcompanyid' ) }
				options={ withPlaceholder( settings.response.associatedcompanyid ) }
			/>
			<SelectControl
				label={ label( 'hubspot_owner_id' ) }
				labelPosition="side"
				value={ settings.hubspot_owner_id }
				onChange={ newVal => onChangeSetting( newVal, 'hubspot_owner_id' ) }
				options={ withPlaceholder( settings.response.hubspot_owner_id ) }
			/>
			<SelectControl
				label={ label( 'lifecyclestage' ) }
				labelPosition="side"
				value={ settings.lifecyclestage }
				onChange={ newVal => onChangeSetting( newVal, 'lifecyclestage' ) }
				options={ withPlaceholder( settings.response.lifecyclestage ) }
			/>
			<ActionFieldsMap
				label={ label( 'fields_map' ) }
				fields={ Object.entries( settings.response.fields ) }
			>
				{ ( { fieldId, fieldData, index } ) => <WrapperRequiredControl
					field={ [ fieldId, fieldData ] }
				>
					<SelectControl
						key={ fieldId + index }
						value={ getMapField( { name: fieldId } ) }
						onChange={ value => setMapField( { nameField: fieldId, value } ) }
						options={ formFieldsList }
					/>
				</WrapperRequiredControl> }
			</ActionFieldsMap>
		</> }
	</>;
} );
