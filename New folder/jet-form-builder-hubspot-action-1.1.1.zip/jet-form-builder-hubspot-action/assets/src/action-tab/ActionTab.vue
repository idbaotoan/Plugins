<template>
	<div>
		<cx-vui-input
			:type="hiddenKeys.api_key ? 'password' : 'text'"
			:label="label.api_key"
			:wrapper-css="[ 'equalwidth', 'with-link-inside' ]"
			:description='help.api_key'
			size="fullwidth"
			v-model="current.api_key"
		>
			<cx-vui-button
				size="link"
				button-style="link-accent"
				@click="toggleHiddenKey( 'api_key' )"
			>
				<template #label>
					<div>
						<svg v-if="hiddenKeys.api_key" xmlns="http://www.w3.org/2000/svg" width="24"
							 height="24"
							 viewBox="0 0 24 24">
							<path
								d="M15 12c0 1.654-1.346 3-3 3s-3-1.346-3-3 1.346-3 3-3 3 1.346 3 3zm9-.449s-4.252 8.449-11.985 8.449c-7.18 0-12.015-8.449-12.015-8.449s4.446-7.551 12.015-7.551c7.694 0 11.985 7.551 11.985 7.551zm-7 .449c0-2.757-2.243-5-5-5s-5 2.243-5 5 2.243 5 5 5 5-2.243 5-5z"/>
						</svg>
						<svg v-else xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
							<path
								d="M11.885 14.988l3.104-3.098.011.11c0 1.654-1.346 3-3 3l-.115-.012zm8.048-8.032l-3.274 3.268c.212.554.341 1.149.341 1.776 0 2.757-2.243 5-5 5-.631 0-1.229-.13-1.785-.344l-2.377 2.372c1.276.588 2.671.972 4.177.972 7.733 0 11.985-8.449 11.985-8.449s-1.415-2.478-4.067-4.595zm1.431-3.536l-18.619 18.58-1.382-1.422 3.455-3.447c-3.022-2.45-4.818-5.58-4.818-5.58s4.446-7.551 12.015-7.551c1.825 0 3.456.426 4.886 1.075l3.081-3.075 1.382 1.42zm-13.751 10.922l1.519-1.515c-.077-.264-.132-.538-.132-.827 0-1.654 1.346-3 3-3 .291 0 .567.055.833.134l1.518-1.515c-.704-.382-1.496-.619-2.351-.619-2.757 0-5 2.243-5 5 0 .852.235 1.641.613 2.342z"/>
						</svg>
					</div>
				</template>
			</cx-vui-button>
		</cx-vui-input>
		<cx-vui-switcher
			:label="label.use_oauth"
			:wrapper-css="[ 'equalwidth' ]"
			:description="help.use_oauth"
			v-model="current.use_oauth"
		></cx-vui-switcher>
		<template v-if="current.use_oauth">
			<cx-vui-input
				:label="label.redirect_base"
				:description="help.redirect_base"
				:wrapper-css="[ 'equalwidth', 'with-button' ]"
				size="fullwidth"
				:value="current.redirect_base"
				ref="redirectBase"
			>
				<cx-vui-button
					button-style="accent-border"
					size="mini"
					@click="onCopy"
				>
					<template #label>
						<span>Copy</span>
					</template>
				</cx-vui-button>
			</cx-vui-input>

			<cx-vui-input
				:type="hiddenKeys.client_secret ? 'password' : 'text'"
				:label="label.client_secret"
				:wrapper-css="[ 'equalwidth', 'with-link-inside' ]"
				:description="help.client_secret"
				size="fullwidth"
				v-model="current.client_secret"
			>
				<cx-vui-button
					size="link"
					button-style="link-accent"
					@click="toggleHiddenKey( 'client_secret' )"
				>
					<template #label>
						<div>
							<svg v-if="hiddenKeys.client_secret" xmlns="http://www.w3.org/2000/svg" width="24"
								 height="24"
								 viewBox="0 0 24 24">
								<path
									d="M15 12c0 1.654-1.346 3-3 3s-3-1.346-3-3 1.346-3 3-3 3 1.346 3 3zm9-.449s-4.252 8.449-11.985 8.449c-7.18 0-12.015-8.449-12.015-8.449s4.446-7.551 12.015-7.551c7.694 0 11.985 7.551 11.985 7.551zm-7 .449c0-2.757-2.243-5-5-5s-5 2.243-5 5 2.243 5 5 5 5-2.243 5-5z"/>
							</svg>
							<svg v-else xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
								<path
									d="M11.885 14.988l3.104-3.098.011.11c0 1.654-1.346 3-3 3l-.115-.012zm8.048-8.032l-3.274 3.268c.212.554.341 1.149.341 1.776 0 2.757-2.243 5-5 5-.631 0-1.229-.13-1.785-.344l-2.377 2.372c1.276.588 2.671.972 4.177.972 7.733 0 11.985-8.449 11.985-8.449s-1.415-2.478-4.067-4.595zm1.431-3.536l-18.619 18.58-1.382-1.422 3.455-3.447c-3.022-2.45-4.818-5.58-4.818-5.58s4.446-7.551 12.015-7.551c1.825 0 3.456.426 4.886 1.075l3.081-3.075 1.382 1.42zm-13.751 10.922l1.519-1.515c-.077-.264-.132-.538-.132-.827 0-1.654 1.346-3 3-3 .291 0 .567.055.833.134l1.518-1.515c-.704-.382-1.496-.619-2.351-.619-2.757 0-5 2.243-5 5 0 .852.235 1.641.613 2.342z"/>
							</svg>
						</div>
					</template>
				</cx-vui-button>
			</cx-vui-input>
			<cx-vui-input
				:label="label.redirect_uri"
				:description="help.redirect_uri"
				:wrapper-css="[ 'equalwidth' ]"
				size="fullwidth"
				@input="onChangeRedirectUri"
				:value="current.redirect_uri"
			/>
			<cx-vui-component-wrapper
				:label="label.redirect_btn"
				:description="help.redirect_btn"
				:wrapper-css="[ 'equalwidth' ]"
			>
				<cx-vui-button
					button-style="accent-border"
					:custom-css="authorizeButton"
					size="mini"
					tag-name="a"
					:url="current.redirect_uri"
					target="_blank"
				>
					<template #label>
						<span>{{ current.is_auth ? 'You are already logged in' : 'Authorize' }}</span>
					</template>
				</cx-vui-button>
			</cx-vui-component-wrapper>

		</template>
	</div>
</template>

<style>

.cx-vui-component__meta {
	justify-content: center;
}

.cx-vui-component--with-button {
	background-color: aliceblue;
}

.cx-vui-component--with-button .cx-vui-component__control {
	display: flex;
	justify-content: space-between;
	flex-direction: row-reverse;
}

.cx-vui-component--with-button .cx-vui-component__control input {
	flex: 0.98;
	background-color: white;
}

.cx-vui-component--with-link-inside .cx-vui-component__control {
	position: relative;
}

.cx-vui-component--with-link-inside .cx-vui-component__control button {
	position: absolute;
	right: 6px;
	top: 5px;
}

.cx-vui-component--with-link-inside .cx-vui-component__control button svg {
	transform: none;
}

</style>

<script>
import {
	help,
	label,
} from "./source";

export default {
	name: 'hubspot',
	props: {
		incoming: {
			type: Object,
			default() {
				return {};
			},
		},
	},
	data() {
		return {
			label, help,
			current: {},
			hiddenKeys: {
				client_secret: true,
				api_key: true,
			},
		};
	},
	computed: {
		authorizeButton() {
			return this.current.is_auth ? 'is-auth' : '';
		},
	},
	created() {
		this.current = JSON.parse( JSON.stringify( this.incoming ) );
	},
	methods: {
		toggleHiddenKey( keyName ) {
			this.$set( this.hiddenKeys, keyName, ! this.hiddenKeys[ keyName ] );
		},
		onCopy() {
			const component = this.$refs.redirectBase;
			const input = component.$el.querySelector( 'input' );
			input.select();

			const is_copy = document.execCommand( 'copy' );

			input.setSelectionRange( 0, 0 );

			this.$CXNotice.add( {
				message: is_copy ? 'Copied!' : 'Failed copy.',
				type: is_copy ? 'success' : 'error',
				duration: 2000,
			} );
		},
		getRequestOnSave() {
			return {
				data: this.current,
			};
		},
		onChangeRedirectUri( value ) {
			const clientIdMatches = value.match( /client_id=[\d\w-]+/gi );

			if ( clientIdMatches?.length ) {
				this.$set( this.current, 'client_id', clientIdMatches[ 0 ].split( 'client_id=' )[ 1 ] );
			} else {
				this.$set( this.current, 'client_id', '' );
			}

			if ( ! value ) {
				this.$set( this.current, 'redirect_uri', '' );

				return;
			}

			let [ domain, query ] = this.current.redirect_base.split( '?' );

			query = encodeURIComponent( '?' + query );
			value = value.replace( this.current.redirect_base, domain + query );

			this.$set( this.current, 'redirect_uri', value );
		},
	},
}

</script>