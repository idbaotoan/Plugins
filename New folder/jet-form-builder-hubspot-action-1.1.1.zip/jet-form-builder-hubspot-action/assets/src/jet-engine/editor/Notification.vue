<template>
	<div class="jet-fb-hubspot-notification">
		<JetFormEditorRow :label="label( 'use_global' )">
			<input type="checkbox" v-model="instance.use_global"/>
		</JetFormEditorRow>
		<JetFormEditorRow
			:label="label( 'auth_type' )"
			v-if="instance.use_global"
			help-class="jet-row-without-opacity"
		>
			<div
				v-for="({ value, label }) in source.auth_type"
				:key="value"
			>
				<input
					v-model="instance.auth_type"
					type="radio"
					:value="value"
					:id="`hubspot_auth_type_${value}`"
				/>
				<label
					:for="`hubspot_auth_type_${value}`"
				>
					{{ label }}
				</label>
			</div>
			<template #helpSide>
				<button
					type="button"
					class="button button-default button-large jet-form-validate-button"
					:class="{
						'loading': isLoading,
						'is-valid': true === instance.isValidAPI && ! isLoading,
						'is-invalid': false === instance.isValidAPI && ! isLoading
					}"
					@click="validateAPI"
				>
					<i class="dashicons"></i>
					{{ instance.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }}
				</button>
			</template>
		</JetFormEditorRow>
		<JetFormEditorRow
			:label="label( 'auth_type' )"
			v-if="!instance.use_global"
			help-class="jet-row-without-opacity"
		>
			<input
				type="text"
				@input="setField( $event.target.value, 'api_key' )"
				:disabled="instance.use_global"
				:value="getApiKey()"
			/>
			<template #helpSide>
				<button
					type="button"
					class="button button-default button-large jet-form-validate-button"
					:class="{
						'loading': isLoading,
						'is-valid': true === instance.isValidAPI && ! isLoading,
						'is-invalid': false === instance.isValidAPI && ! isLoading
					}"
					@click="validateAPI"
				>
					<i class="dashicons"></i>
					{{ instance.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }}
				</button>
			</template>
		</JetFormEditorRow>
		<JetFormEditorRow :label="label( 'api_key' )" v-if="instance.use_global && showApiKey">
			<input
				type="text"
				@input="setField( $event.target.value, 'api_key' )"
				:disabled="instance.use_global"
				:value="getApiKey()"
			>
			<template #helpControl>
				{{ help( 'api_key_link_prefix' ) }}
				<a :href="help( 'api_key_link' )" target="_blank">{{ help( 'api_key_link_suffix' ) }}</a>
			</template>
		</JetFormEditorRow>

		<template v-if="instance.isValidAPI">
			<JetFormEditorRow :label="label( 'associatedcompanyid' )">
				<select v-model="instance.associatedcompanyid">
					<option value="">--</option>
					<option v-for="({ value, label }) in instance.response.associatedcompanyid" :value="value">
						{{ label }}
					</option>
				</select>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'hubspot_owner_id' )">
				<select v-model="instance.hubspot_owner_id">
					<option value="">--</option>
					<option v-for="({ value, label }) in instance.response.hubspot_owner_id" :value="value">
						{{ label }}
					</option>
				</select>
			</JetFormEditorRow>
			<JetFormEditorRow :label="label( 'lifecyclestage' )">
				<select v-model="instance.lifecyclestage">
					<option value="">--</option>
					<option v-for="({ value, label }) in instance.response.lifecyclestage" :value="value">
						{{ label }}
					</option>
				</select>
			</JetFormEditorRow>
			<div class="jet-form-editor__row">
				<div class="jet-form-editor__row-label">{{ label( 'fields_map' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__row-notice">{{ help( 'fields_map' ) }}</div>
					<div class="jet-form-editor__row-fields">
						<div class="jet-form-editor__row-map"
							 v-for="( fieldData, fieldId ) in instance.response.fields">
                <span>{{ fieldData.label }} <span class="jet-form-editor-required"
												  v-if="fieldData.required">*</span></span>
							<select @input="changeFieldMap( $event.target.value, fieldId )"
									:value="getFieldMap( fieldId )">
								<option value="">--</option>
								<option v-for="field in fields" :value="field">{{ field }}</option>
							</select>
						</div>
					</div>
				</div>
			</div>
		</template>
	</div>
</template>

<style>
.jet-row-without-opacity {
	opacity: 1;
	margin-left: 2em;
}
</style>

<script>
import { getLocalizedFullPack } from '@/source'
import { JetFormEditorRow } from "jfb-editor"

const { source, label, help } = getLocalizedFullPack;
const globalKey = JEBookingFormNotifications.globalTab( 'hubspot' );

export default {
	name: 'hubspot',
	components: {
		JetFormEditorRow,
	},
	props: {
		value: Object,
		fields: Array,
		jsonSource: Array,
	},
	data: function() {
		return {
			instance: {},
			isLoading: false,
			requestProcessing: '',
			response: {},
			source: source,
		};
	},
	created: function() {
		this.instance = this.value || {};
	},
	watch: {
		instance( newResponse ) {
			this.$emit( 'input', newResponse );
		},
	},
	computed: {
		showApiKey() {
			return ( ! this.instance.use_global && ! this.instance.auth_type || 'api_key' === this.instance.auth_type );
		},
	},

	methods: {
		label: attr => label( attr ),
		help: attr => help( attr ),

		validateAPI: function() {
			const self = this;

			self.$set( self, 'isLoading', true );

			self.requestAPI()
				.always( () => {
					self.$set( self, 'isLoading', false );
				} );

		},
		requestAPI: function() {
			const self = this;

			return ( jQuery.ajax( {
				url: ajaxurl,
				type: 'POST',
				data: {
					action: source.action,
					api_key: self.instance.api_key,
					auth_type: self.instance.auth_type,
					use_global: self.instance.use_global,
					namespace: 'jef',
				},
			} ).done( response => {
				if ( response.success ) {
					this.setField( true, 'isValidAPI' );
					this.setField( response.data, 'response' );
				} else {
					this.setField( false, 'isValidAPI' );
				}
			} ) );
		},
		setField: function( value, key ) {
			this.$set( this.instance, key, value );
			this.$emit( 'input', this.instance );
		},
		getMailerLiteData: function() {
			const self = this;

			self.requestAPI();
		},
		changeFieldMap: function( value, key ) {
			if ( ! this.instance.fields_map ) {
				this.$set( this.instance, 'fields_map', {} );
			}
			this.$set( this.instance.fields_map, key, value );
			this.setField( this.instance.fields_map, 'fields_map' );
		},
		getFieldMap: function( key ) {
			return this.instance.fields_map && this.instance.fields_map[ key ] ? this.instance.fields_map[ key ] : '';
		},
		getApiKey: function() {
			return this.instance.use_global ? globalKey.api_key : this.instance.api_key;
		},
	},

}
</script>