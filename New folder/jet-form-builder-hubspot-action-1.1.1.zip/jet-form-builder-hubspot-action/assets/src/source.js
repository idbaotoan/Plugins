import { Actions } from "jfb-editor";

const { __ } = wp.i18n;

const getLocalizedFullPack = new Actions.EditorData( 'hubspot' )
	.setLabels( {
		api_key: __( 'API Key', 'jet-form-builder-hubspot-action' ),
		validate_api_key: __( 'Send Request', 'jet-form-builder-hubspot-action' ),
		retry_request: __( 'Retry request', 'jet-form-builder-hubspot-action' ),
		associatedcompanyid: __( 'Associated company', 'jet-form-builder-hubspot-action' ),
		hubspot_owner_id: __( 'Contact owner', 'jet-form-builder-hubspot-action' ),
		lifecyclestage: __( 'Lifecycle stage', 'jet-form-builder-hubspot-action' ),
		fields_map: __( 'Fields Map', 'jet-form-builder-hubspot-action' ),
		use_global: __( 'Use Global Settings', 'jet-form-builder-hubspot-action' ),
		auth_type: __( 'Authorization Type', 'jet-form-builder-hubspot-action' ),
	} )
	.setHelp( {
		api_key_link_prefix: __( 'How to obtain your HubSpot API Key? More info', 'jet-form-builder-hubspot-action' ),
		api_key_link_suffix: __( 'here', 'jet-form-builder-hubspot-action' ),
		api_key_link: 'https://knowledge.hubspot.com/integrations/how-do-i-get-my-hubspot-api-key',
		fields_map: __( 'Set form fields names to to get user data from', 'jet-form-builder-hubspot-action' ),
	} )
	.setGatewayAttrs( [
		"tag_id",
	] )
	.setSource( {
		action: 'jet_form_builder_get_hubspot_data',
		auth_type: [
			{
				value: 'api_key',
				label: __( 'API Key', 'jet-form-builder-hubspot-action' ),
			},
			{
				value: 'oauth',
				label: __( 'OAuth 2.0', 'jet-form-builder-hubspot-action' ),
			},
		],
	} )
	.exportAll();

export { getLocalizedFullPack };