<?php

namespace Jet_FB_HubSpot;

use HubSpot\Client\Crm\Owners\Model\PublicOwner;
use HubSpot\Client\Crm\Properties\ApiException;
use HubSpot\Client\Crm\Properties\Model\Option;
use HubSpot\Discovery\Discovery;
use HubSpot\Factory;
use Jet_Engine\Modules\Forms\Tabs\Tab_Manager;
use Jet_FB_HubSpot\JetEngine\OAuth\Handler as JEHandler;
use Jet_FB_HubSpot\JetFormBuilder\OAuth\Handler as JFBHandler;
use Jet_Form_Builder\Admin\Tabs_Handlers\Tab_Handler_Manager;
use JetHubSpotCore\BaseHandler;
use JetHubSpotCore\Exceptions\ApiHandlerException;

class Handler extends BaseHandler {

	private $hubspot;
	public $auth_type;

	public function ajax_action(): string {
		return 'jet_form_builder_get_hubspot_data';
	}

	/**
	 * @return Discovery
	 * @throws ApiHandlerException
	 */
	public function hubspot() {
		if ( ! $this->hubspot ) {
			$this->hubspot = $this->create_api_handler();
		}

		return $this->hubspot;
	}

	/**
	 * @return Discovery
	 * @throws ApiHandlerException
	 */
	private function create_api_handler() {
		$type       = $this->get_arg( 'auth_type' );
		$use_global = $this->get_arg( 'use_global' );

		if ( ! $use_global || 'oauth' !== $type ) {
			$api_key = $this->get_api_key( $use_global );

			if ( ! $api_key ) {
				throw new ApiHandlerException( "Please input your API Key:" . var_export( $this->request_args, true ) );
			}

			return Factory::createWithApiKey( $api_key );
		}

		try {
			$token = $this->get_access_token();
		} catch ( HubSpotOAuthException $exception ) {
			throw new ApiHandlerException( $exception->getMessage() );
		}

		if ( ! $token ) {
			throw new ApiHandlerException( 'Please authorize your App' );
		}

		return Factory::createWithAccessToken( $token );
	}

	private function get_api_key( $use_global = false ) {
		if ( ! $use_global ) {
			return $this->get_arg( 'api_key' );
		}

		switch ( $this->get_arg( 'namespace' ) ) {
			case 'jfb':
				$options = Tab_Handler_Manager::instance()->options( 'hubspot' );

				return isset( $options['api_key'] ) ? $options['api_key'] : false;
			case 'jef':
				$options = Tab_Manager::instance()->options( 'hubspot' );

				return isset( $options['api_key'] ) ? $options['api_key'] : false;
		}

		return false;
	}

	/**
	 * @return array|false|mixed
	 * @throws HubSpotOAuthException
	 */
	private function get_access_token() {
		if ( ! $this->get_arg( 'use_global' ) ) {
			throw new HubSpotOAuthException( 'Arg `use_global` is not enabled' );
		}

		switch ( $this->get_arg( 'namespace' ) ) {
			case 'jfb':
				return JFBHandler::instance()->refresh_and_get_access_token();
			case 'jef':
				return JEHandler::instance()->refresh_and_get_access_token();
		}

		throw new HubSpotOAuthException( 'Undefined arg: `namespace`' );
	}

	public function required_ajax_args() {
		return array_merge( parent::required_ajax_args(), array(
			'auth_type'  => array(),
			'namespace'  => array(),
			'use_global' => array(
				'sanitize_func' => function ( $value ) {
					return 'true' === $value;
				}
			)
		) );
	}

	public function properties_insert() {
		return array(
			'email',
			'firstname',
			'lastname',
			'phone',
			'website',
			'associatedcompanyid',
			'hubspot_owner_id',
			'lifecyclestage',
		);
	}

	/**
	 * @return mixed
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		return array(
			'associatedcompanyid' => $this->get_all_companies(),
			'hubspot_owner_id'    => $this->get_owners(),
			'lifecyclestage'      => $this->get_property_options( 'lifecyclestage' ),
			'fields'              => array(
				'email'     => array(
					'label'    => __( 'Email', 'jet-form-builder-hubspot-action' ),
					'required' => true
				),
				'firstname' => array(
					'label' => __( 'First Name', 'jet-form-builder-hubspot-action' ),
				),
				'lastname'  => array(
					'label' => __( 'Last Name', 'jet-form-builder-hubspot-action' ),
				),
				'phone'     => array(
					'label' => __( 'Phone', 'jet-form-builder-hubspot-action' ),
				),
				'website'   => array(
					'label' => __( 'Website', 'jet-form-builder-hubspot-action' ),
				),
			),
		);
	}

	private function company_properties() {
		return array(
			'value' => 'hs_object_id',
			'label' => 'name'
		);
	}

	private function get_all_companies() {
		$companies          = $this->hubspot()->crm()->companies()->getAll( 'name' );
		$prepared_companies = array();

		list( 'value' => $value, 'label' => $label ) = $this->company_properties();

		foreach ( $companies as $company ) {
			$properties = $company->getProperties();

			if ( empty( $properties[ $value ] ) || empty( $properties[ $label ] ) ) {
				continue;
			}
			$prepared_companies[] = array(
				'value' => $properties[ $value ],
				'label' => $properties[ $label ],
			);
		}

		return $prepared_companies;
	}

	/**
	 * @param $property_name
	 *
	 * @return Option[]
	 * @throws ApiHandlerException
	 */
	private function get_property_options( $property_name ) {
		$response = array();
		try {
			$options = $this->hubspot()
			                ->crm()
			                ->properties()
			                ->coreApi()
			                ->getByName( 'contact', $property_name )
			                ->getOptions();

		} catch ( ApiException $exception ) {
			throw new ApiHandlerException( $exception->getMessage() );
		}

		foreach ( $options as $option ) {
			$response[] = array(
				'value' => $option->getValue(),
				'label' => $option->getLabel()
			);
		}

		return $response;
	}

	private function get_owners() {
		$response = array();
		$owners   = $this->hubspot()->crm()->owners()->getAll();

		foreach ( $owners as $owner ) {
			/** @var $owner PublicOwner */

			$response[] = array(
				'value' => $owner->getId(),
				'label' => $owner->getEmail(),
			);
		}

		return $response;
	}

}