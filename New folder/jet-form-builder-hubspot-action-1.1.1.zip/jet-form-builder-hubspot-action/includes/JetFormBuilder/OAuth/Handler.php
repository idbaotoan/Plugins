<?php


namespace Jet_FB_HubSpot\JetFormBuilder\OAuth;


use Jet_FB_HubSpot\OAuthHandler;
use Jet_Form_Builder\Admin\Tabs_Handlers\Tab_Handler_Manager;

final class Handler extends OAuthHandler {

	public static $instance = null;

	public function get_action() {
		return 'jet_fb_hubspot_oauth';
	}

	public function get_option_name() {
		return Tab_Handler_Manager::instance()->tab( 'hubspot' )->option_name();
	}

	public function get_options() {
		return Tab_Handler_Manager::instance()->options( 'hubspot' );
	}

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new static();
		}

		return self::$instance;
	}

	private function __construct() {
	}
}