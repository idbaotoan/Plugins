<?php


namespace Jet_FB_HubSpot\JetEngine\Tabs;


use JetHubSpotCore\JetEngine\RegisterFormTabs;

class ManagerTabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new ActionTab()
		);
	}

	public function plugin_version_compare() {
		return '2.8.3';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}

}