<?php
/**
 * Pagination item content
 */

?>
<div class="jet-filters-pagination__dots">&hellip;</div>