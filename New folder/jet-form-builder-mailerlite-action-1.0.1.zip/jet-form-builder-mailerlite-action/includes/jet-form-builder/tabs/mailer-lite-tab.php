<?php


namespace Jet_FB_MailerLite\Jet_Form_Builder\Tabs;


use Jet_FB_MailerLite\Mailer_Lite_Tab_Trait;
use Jet_FB_MailerLite\Plugin;
use Jet_Form_Builder\Admin\Tabs_Handlers\Base_Handler;

class Mailer_Lite_Tab extends Base_Handler {

	use Mailer_Lite_Tab_Trait;

	public function before_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug . "-{$this->slug()}",
			Plugin::instance()->plugin_url( 'assets/js/builder.admin.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}
}