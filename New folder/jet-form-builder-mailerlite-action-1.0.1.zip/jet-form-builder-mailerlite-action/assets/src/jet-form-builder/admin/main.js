import * as mailerLiteTab from '@/mailer-lite-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.fb.register.settings-page.tabs', 'jet-form-builder', tabs => {
	tabs.push( mailerLiteTab );

	return tabs;
} );