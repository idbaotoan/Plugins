<?php

namespace Jet_FB_Schedule_Forms;

use Jet_FB_Schedule_Forms\Jet_Form_Builder;

if ( ! defined( 'WPINC' ) ) {
	die();
}

class Plugin {
	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $slug = 'jet-form-builder-schedule-forms';

	public function __construct() {
		$this->register_autoloader();
		$this->init_components();
	}

	public function init_components() {
		Jet_Form_Builder\Plugin_Manager::register();
		Jet_Form_Builder\Prevent_Form_Submit::register();
		new Jet_Form_Builder\Prevent_Form_Render();
		new Jet_Form_Builder\Style_Manager();
		new Elementor_Style_Manager();

		Jet_Engine\Schedule_Meta_Box::register();
		Jet_Engine\Prevent_Form_Submit::register();
		new Jet_Engine\Prevent_Form_Render();

		$can_init_license = (
			is_admin()
			&& function_exists( 'jet_form_builder' )
			&& array_key_exists( 'addons_manager', get_object_vars( jet_form_builder() ) )
		);

		if ( $can_init_license ) {
			require $this->plugin_dir( 'includes/class-jfb-license-manager.php' );

			new \JFB_License_Manager();
		}
	}

	/**
	 * Register autoloader.
	 */
	public function register_autoloader() {
		require JET_FB_SCHEDULE_FORMS_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	public function get_version() {
		return JET_FB_SCHEDULE_FORMS_VERSION;
	}

	public function plugin_url( $path ) {
		return JET_FB_SCHEDULE_FORMS_URL . $path;
	}

	public function plugin_dir( $path = '' ) {
		return JET_FB_SCHEDULE_FORMS_PATH . $path;
	}

	public function get_template_path( $template ) {
		$path = JET_FB_SCHEDULE_FORMS_PATH . 'templates' . DIRECTORY_SEPARATOR;

		return ( $path . $template . '.php' );
	}


	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Plugin An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

Plugin::instance();