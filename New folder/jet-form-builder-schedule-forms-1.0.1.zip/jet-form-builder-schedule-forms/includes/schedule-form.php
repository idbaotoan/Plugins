<?php


namespace Jet_FB_Schedule_Forms;


use Jet_FB_Schedule_Forms\Jet_Engine\Schedule_Meta_Box;

class Schedule_Form {

	const TYPE_PENDING = 'pending';
	const TYPE_EXPIRED = 'expired';
	const PLUGIN_META_KEY = '_jf_schedule_form';

	public static $settings = null;

	const DEFAULT_MESSAGES = array(
		self::TYPE_PENDING => 'Pending message',
		self::TYPE_EXPIRED => 'Expired message',
	);

	public static function get_jfb_settings( $form_id ) {
		if ( is_null( self::$settings ) ) {
			self::$settings = jet_form_builder()->post_type->get_form_meta( self::PLUGIN_META_KEY, $form_id );
		}

		return self::$settings;
	}

	public static function get_jef_settings( $form_id ) {
		if ( is_null( self::$settings ) ) {
			self::$settings = self::get_form_schedule( $form_id );
		}

		return self::$settings;
	}


	/**
	 * Returns gatewyas config for current form
	 *
	 * @param  [type] $post_id [description]
	 *
	 * @return [type]          [description]
	 */
	public static function get_form_schedule( $form_id = 0 ) {
		if ( ! $form_id ) {
			$form_id = get_the_ID();
		}
		$meta = get_post_meta( $form_id, self::PLUGIN_META_KEY, true );

		return $meta ? json_decode( $meta, true ) : array();
	}


	public static function get_message( $type ) {
		$attr = $type . '_message';

		return ( empty( self::$settings[ $attr ] ) ? self::DEFAULT_MESSAGES[ $type ] : self::$settings[ $attr ] );
	}

	public static function get_schedule_type() {
		if ( (
			     empty( self::$settings['enable'] )
			     || false === self::$settings['enable']
		     )
		     || (
			     empty( self::$settings['from_date'] )
			     && empty( self::$settings['to_date'] )
		     )
		) {
			return false;
		}
		$current_time = current_time( 'timestamp' );
		$from_date    = strtotime( self::$settings['from_date'] );
		$to_date      = strtotime( self::$settings['to_date'] );

		if ( $from_date && $current_time < $from_date ) {
			return Schedule_Form::TYPE_PENDING;
		}

		if ( $to_date && $current_time > $to_date ) {
			return Schedule_Form::TYPE_EXPIRED;
		}

		return false;
	}

	public static function clear() {
		self::$settings = null;
	}
}