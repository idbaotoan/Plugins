<?php


namespace Jet_FB_Schedule_Forms\Jet_Form_Builder;


use Jet_FB_Schedule_Forms\Prevent_Render_Base;
use Jet_FB_Schedule_Forms\Schedule_Form;
use JetScheduleFormsCore\JetFormBuilder\PreventFormRender;

class Prevent_Form_Render extends PreventFormRender {

	use Prevent_Render_Base;

	public function render_form( $form_id, $attrs, $prev_content = false ) {
		Schedule_Form::get_jfb_settings( $form_id );

		$response = $prev_content ? $prev_content : $this->maybe_render_schedule_message();
		Schedule_Form::clear();

		return $response;
	}

}