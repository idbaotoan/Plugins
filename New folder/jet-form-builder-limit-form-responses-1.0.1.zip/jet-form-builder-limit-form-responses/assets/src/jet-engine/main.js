import {
	labels,
	help,
	options
} from "../source";

new Vue( {
	el: '#jet-limit-form-responses',
	data: {
		options,
		meta: {
			enable: false,
			limit: '',
			closed_message: '',
			error_message: '',
			restrict_users: false,
			restrict_by: '',
			guest_message: '',
			restricted_message: ''
		},
	},
	created() {
		this.meta = { ...this.meta, ...window.JetLimitFormResponses.meta };
	},
	methods: {
		label: function ( attr ) {
			return labels[ attr ];
		},
		help: function ( attr ) {
			return help[ attr ];
		},
		withPrefix: function ( suffix = '' ) {
			return `_jf_limit_responses${ suffix }`;
		},
		fieldName: function ( ...names ) {
			return this.withPrefix( names.map( name => `[${ name }]` ).join( '' ) );
		},
		uniqId: function ( name ) {
			return this.withPrefix( `__${ name }` );
		}
	},
} );