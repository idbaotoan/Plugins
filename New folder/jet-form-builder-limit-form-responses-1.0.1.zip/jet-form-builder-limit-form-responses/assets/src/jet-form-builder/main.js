import * as limit from "./plugins/limit"

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.fb.register.plugin.jf-actions-panel.after', 'jet-form-builder', plugins => {
	plugins.push( limit );

	return plugins;
} );
