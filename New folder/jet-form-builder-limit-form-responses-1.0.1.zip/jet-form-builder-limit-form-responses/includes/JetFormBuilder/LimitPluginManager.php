<?php


namespace Jet_FB_Limit_Form_Responses\JetFormBuilder;

use Jet_FB_Limit_Form_Responses\LimitResponses;
use Jet_FB_Limit_Form_Responses\Plugin;
use JetLimitResponsesCore\JetFormBuilder\PluginManager;

class LimitPluginManager extends PluginManager {

	public function plugin_version_compare(): string {
		return '1.2.0';
	}

	public function before_init_editor_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/builder.bundle.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function meta_data() {
		return array(
			LimitResponses::PLUGIN_META_KEY => array()
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Limit Form Responses</b> needs <b>JetFormBuilder</b> update.',
			'jet-form-builder-limit-form-responses'
		) );
	}

	public function on_base_need_install() {
	}
}