<?php


namespace Jet_FB_Limit_Form_Responses;


trait PreventSubmitTrait {

	use PreventFormTrait;

	public function get_message_type_on_general_limit() {
		return LimitResponses::ERROR_MESSAGE;
	}

	public function get_message_type_on_restrict_limit() {
		return LimitResponses::ERROR_MESSAGE;
	}

}