<?php

namespace Jet_FB_Limit_Form_Responses\Exceptions;

use JetLimitResponsesCore\Exceptions\BaseHandlerException;

class LimitException extends BaseHandlerException {

}