<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;


use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;
use Jet_FB_Limit_Form_Responses\LimitResponses;

class LoggedUser extends RestrictTypeBase {

	private $user_meta;
	private $user_id;

	public function get_id() {
		return 'user';
	}

	/**
	 * @inheritDoc
	 * @throws LimitException
	 */
	public function count_submissions( $settings, $form_id ) {
		$this->set_user_meta( $form_id );
		$this->user_meta[ $form_id ] = isset( $this->user_meta[ $form_id ] ) ? $this->user_meta[ $form_id ] : 0;

		return $this->user_meta[ $form_id ];
	}

	public function increment_submissions( $settings, $form_id ) {
		$this->user_meta[ $form_id ] ++;

		return $this->update_user_meta();
	}

	private function get_user_id_or_throw() {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			throw new LimitException( LimitResponses::GUEST_MESSAGE );
		}

		return $user_id;
	}

	private function get_meta_data( $user_id, $form_id ) {
		$metadata = get_user_meta( $user_id, LimitResponses::PLUGIN_META_KEY, true );

		return $metadata ? json_decode( $metadata, true ) : array(
			$form_id => 0
		);
	}

	/**
	 * @param $form_id
	 *
	 * @throws LimitException
	 */
	private function set_user_meta( $form_id ) {
		$this->user_id   = $this->get_user_id_or_throw();
		$this->user_meta = $this->get_meta_data( $this->user_id, $form_id );
	}

	private function update_user_meta() {
		return update_user_meta(
			$this->user_id,
			LimitResponses::PLUGIN_META_KEY,
			json_encode( $this->user_meta )
		);
	}

}