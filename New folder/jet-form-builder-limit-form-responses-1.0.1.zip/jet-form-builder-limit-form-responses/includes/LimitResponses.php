<?php


namespace Jet_FB_Limit_Form_Responses;

use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Cookie;
use Jet_FB_Limit_Form_Responses\RestrictTypes\General;
use Jet_FB_Limit_Form_Responses\RestrictTypes\IPAddress;
use Jet_FB_Limit_Form_Responses\RestrictTypes\LoggedUser;
use Jet_FB_Limit_Form_Responses\RestrictTypes\RestrictTypeBase;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Session;
use JetLimitResponsesCore\Common\MetaQuery;

class LimitResponses {

	const PLUGIN_META_KEY = '_jf_limit_responses';
	const PLUGIN_META_COUNTER_KEY = '_jf_limit_responses_counters';

	const CLOSED_MESSAGE = 'closed_message';
	const ERROR_MESSAGE = 'error_message';
	const GUEST_MESSAGE = 'guest_message';
	const RESTRICT_MESSAGE = 'restricted_message';

	private $settings = null;
	private $counters = null;
	private $_restrict_types = array();
	private $_restrict_by = 'id_address';
	private $_form_id = 0;

	private static $instance;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
	public static function clear() {
		self::$instance = null;
	}

	private function __construct() {
		$this->register_restrict_user_types();
	}

	private function user_restrict_types() {
		return apply_filters( 'jet-fb/limit-form-responses/register/restrict-user-types', array(
			new IPAddress(),
			new LoggedUser(),
			new Cookie(),
			new Session(),
		) );
	}

	public function get_settings( $form_id = 0 ) {
		if ( is_null( $this->settings ) ) {
			$this->settings = MetaQuery::get_json_meta( array(
				'id'  => (int) $form_id,
				'key' => LimitResponses::PLUGIN_META_KEY,
			) );
		}

		return $this->settings;
	}

	public function get_counters( $form_id = 0 ) {
		if ( is_null( $this->counters ) ) {
			$this->counters = MetaQuery::get_json_meta( array(
				'id'  => (int) $form_id,
				'key' => LimitResponses::PLUGIN_META_COUNTER_KEY,
			) );
		}

		return $this->counters;
	}

	public function is_enable_restrict_users() {
		return ( isset( $this->settings['restrict_users'] ) && $this->settings['restrict_users'] );
	}

	public function has_reached_restrict_limit( $type, $form_id, $run_increment ) {
		$this->save_form_id( $form_id );
		$this->get_settings( $form_id );

		$this->register_restrict_user_types();

		if ( $this->is_enable_restrict_users() ) {
			$this->set_restrict_instance();

			if ( $this->isset_restrict_instance() && $this->get_restrict_instance()->is_reached_limit( $run_increment ) ) {
				throw new LimitException( $type, $this->settings );
			}

		}

		return false;
	}

	public function has_reached_general_limit( $type, $form_id, $run_increment ) {
		$this->get_settings( $form_id );
		$this->save_form_id( $form_id );

		if ( isset( $this->settings['enable'] ) && $this->settings['enable'] ) {
			$is_reached = ( new General() )->is_reached_limit( $run_increment );

			if ( $is_reached ) {
				throw new LimitException( $type, $this->settings );
			}
		}

		return false;
	}

	private function save_form_id( $form_id ) {
		$this->_form_id = $form_id;
	}

	public function form_id() {
		return $this->_form_id;
	}

	private function register_restrict_user_types() {
		$types = $this->user_restrict_types();

		foreach ( $types as $type ) {
			$this->_restrict_types[ $type->get_id() ] = $type;
		}
	}

	private function set_restrict_instance() {
		if ( isset( $this->settings['restrict_by'] ) && $this->settings['restrict_by'] ) {
			$this->_restrict_by = $this->settings['restrict_by'];
		}
	}

	private function isset_restrict_instance() {
		return (
			isset( $this->_restrict_types[ $this->_restrict_by ] )
			&& $this->_restrict_types[ $this->_restrict_by ] instanceof RestrictTypeBase
		);
	}

	private function get_restrict_instance() {
		return $this->_restrict_types[ $this->_restrict_by ];
	}

	public function get_message_by_type( $type ) {
		$defaults = array(
			self::GUEST_MESSAGE    => 'Please log in to submit the form',
			self::ERROR_MESSAGE    => 'This form can no longer accept your request, sorry',
			self::RESTRICT_MESSAGE => 'You have already submitted a request from this form',
			self::CLOSED_MESSAGE   => 'This form is no longer available'
		);

		if ( isset( $this->settings[ $type ] ) && $this->settings[ $type ] ) {
			return $this->settings[ $type ];
		}

		return $defaults[ $type ];
	}

}