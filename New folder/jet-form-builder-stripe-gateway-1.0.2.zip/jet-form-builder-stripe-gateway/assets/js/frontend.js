( function ( $ ) {
	const getUrlParams = ( { url = '' } = {} ) => {
		let sourceUrl = decodeURIComponent( url ? url : window.location.href );
		const urlParts = sourceUrl.split( '?' );

		if ( ! urlParts[ 1 ] || ! urlParts[ 1 ].length ) {
			return {};
		}
		const arrParams = urlParts[ 1 ].split( '&' );
		const response = {};

		arrParams.forEach( param => {
			const [ key, value = '' ] = param.split( '=' );
			response[ key ] = value;
		} );

		return response;
	};

	const stripeRedirectToCheckout = requestParams => {
		console.log( requestParams );
		if ( requestParams.stripe_session_id && requestParams.stripe_public_key ) {
			const stripe = new Stripe( requestParams.stripe_public_key );

			stripe.redirectToCheckout( { sessionId: requestParams.stripe_session_id } );
		}
	}

	stripeRedirectToCheckout( getUrlParams() );

	$( document ).on( 'jet-form-builder/ajax/on-success', ( event, response ) => stripeRedirectToCheckout( response ) );
	$( document ).on( 'jet-engine/form/ajax/on-success', ( event, response ) => stripeRedirectToCheckout( response ) );

} )( jQuery )