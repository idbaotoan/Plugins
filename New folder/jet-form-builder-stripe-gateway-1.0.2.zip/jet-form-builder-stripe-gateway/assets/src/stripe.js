const { __ } = wp.i18n;

const {
		  TextControl,
		  ToggleControl
	  } = wp.components;

const {
		  registerGateway,
		  gatewayLabel,
		  globalTab,
	  } = JetFBActions;

const label = gatewayLabel( 'stripe' );
const currentTab = globalTab( { slug: 'stripe' } );

registerGateway( 'stripe', function Stripe( {
												setValueInObject,
												getNotifications,
											} ) {

	const setSetting = ( key, value ) => {
		setValueInObject( 'stripe', key, value );
	};
	const getSetting = ( key ) => {
		return getNotifications( 'stripe', key, '' );
	};

	const isGlobal = getNotifications( 'stripe', 'use_global', false );

	const getManualOrGlobal = key => {
		return isGlobal
			? currentTab[ key ]
			: getSetting( key );
	};

	return <>
		<ToggleControl
			key={ 'use_global' }
			label={ label( 'use_global' ) }
			checked={ getSetting( 'use_global' ) }
			onChange={ newVal => setSetting( 'use_global', newVal ) }
		/>
		<TextControl
			label={ label( 'public' ) }
			key='paypal_public_setting'
			value={ getManualOrGlobal( 'public' ) }
			onChange={ newVal => setSetting( 'public', newVal ) }
			disabled={ isGlobal }
		/>
		<TextControl
			label={ label( 'secret' ) }
			key='paypal_secret_setting'
			value={ getManualOrGlobal( 'secret' ) }
			onChange={ newVal => setSetting( 'secret', newVal ) }
			disabled={ isGlobal }
		/>
		<TextControl
			label={ label( 'currency' ) }
			key='paypal_currency_code_setting'
			value={ getSetting( 'currency' ) }
			onChange={ newVal => setSetting( 'currency', newVal ) }
		/>
	</>;
} );