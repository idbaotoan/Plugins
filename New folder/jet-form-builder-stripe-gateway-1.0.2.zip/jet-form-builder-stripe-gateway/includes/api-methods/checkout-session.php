<?php


namespace Jet_FB_Stripe_Gateway\Api_Methods;


class Checkout_Session extends Base_Api_Method {

	public function method_name() {
		return 'v1/checkout/sessions';
	}

}