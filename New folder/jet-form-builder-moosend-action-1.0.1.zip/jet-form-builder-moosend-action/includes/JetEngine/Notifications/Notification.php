<?php


namespace Jet_FB_MooSend\JetEngine\Notifications;


use Jet_FB_MooSend\BaseAction;
use Jet_FB_MooSend\Plugin;
use JetMooSendCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use BaseAction;

}