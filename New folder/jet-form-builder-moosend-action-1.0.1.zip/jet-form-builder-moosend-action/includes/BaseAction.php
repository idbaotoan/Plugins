<?php


namespace Jet_FB_MooSend;


use JetMooSendCore\Exceptions\BaseHandlerException;
use JetMooSendCore\JetFormBuilder\ActionCompatibility;

trait BaseAction {

	use ActionCompatibility;

	public function get_name() {
		return __( 'Moosend', 'jet-form-builder-moosend-action' );
	}

	public function get_id() {
		return 'moosend';
	}

	/**
	 * @param $api_key
	 *
	 * @return mixed
	 */
	public function api_handler( $api_key = '' ): Handler {
		return Handler::instance()->api_key( $api_key );
	}

	/**
	 * Run a hook notification
	 *
	 * @return void
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$settings = $this->getSettingsWithGlobal();

		if ( empty( $settings['api_key'] ) || empty( $settings['mailing_list'] ) ) {
			throw new BaseHandlerException( 'internal_error' );
		}
		$handler    = $this->api_handler( $settings['api_key'] );
		$fields_map = $this->prepare_fields_map( $settings );

		if ( isset( $fields_map['Email'] ) && $fields_map['Email'] ) {
			$endpoint = sprintf( 'subscribers/%s/view.json', $settings['mailing_list'] );

			$find_subscribers = $handler->request( $endpoint, array(
				'body' => array(
					'Email' => $fields_map['Email']
				)
			) );

			if ( isset( $find_subscribers['Context'] ) && isset( $find_subscribers['Context']['Email'] ) ) {
				$message = $this->parseDynamicException(
					'error',
					apply_filters(
						'jet-fb-moosend-action/action/email-exists-message',
						sprintf( __( 'The subscriber %s already exists.' ), $find_subscribers['Context']['Email'] )
					)
				);

				throw new BaseHandlerException( $message );
			}
		}
		$endpoint = sprintf( 'subscribers/%s/subscribe.json', $settings['mailing_list'] );

		$request_args = array(
			'method' => 'POST',
			'body'   => $fields_map,
		);

		$response = $handler->request( $endpoint, $request_args );

		if ( $response['Error'] ) {
			throw new BaseHandlerException( $this->parseDynamicException( 'error', $response['Error'] ) );
		}
	}

	/**
	 * @param $settings
	 *
	 * @return array
	 * @throws BaseHandlerException
	 */
	public function prepare_fields_map( $settings ) {
		$request  = $this->getRequestData();
		$response = array();

		if ( ! isset( $settings['fields_map'] ) || ! $settings['fields_map'] ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		if ( isset( $settings['double_opt_in'] ) && $settings['double_opt_in'] ) {
			$response['HasExternalDoubleOptIn'] = true;
		}

		foreach ( $settings['fields_map'] as $param => $field ) {
			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			if ( in_array( $param, array( 'Email', 'Name' ) ) ) {
				$response[ $param ] = $request[ $field ];
			} else {
				$response['CustomFields'][] = "$param={$request[ $field ]}";
			}
		}

		return $response;
	}

}