<?php

namespace Jet_FB_MooSend\JetFormBuilder\Tabs;


use JetMooSendCore\JetFormBuilder\RegisterFormTabs;

class ManagerTabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new ActionTab()
		);
	}

	public function plugin_version_compare() {
		return '1.2.2';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}
}