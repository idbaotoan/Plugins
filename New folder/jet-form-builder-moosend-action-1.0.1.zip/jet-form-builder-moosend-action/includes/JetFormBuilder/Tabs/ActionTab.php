<?php


namespace Jet_FB_MooSend\JetFormBuilder\Tabs;


use Jet_FB_MooSend\ActionTabTrait;
use Jet_FB_MooSend\Plugin;
use Jet_Form_Builder\Admin\Tabs_Handlers\Base_Handler;

class ActionTab extends Base_Handler {

	use ActionTabTrait;

	public function before_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug . "-{$this->slug()}",
			Plugin::instance()->plugin_url( 'assets/js/builder.admin.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}
}