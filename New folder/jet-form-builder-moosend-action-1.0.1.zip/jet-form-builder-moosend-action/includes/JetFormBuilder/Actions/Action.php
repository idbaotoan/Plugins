<?php

namespace Jet_FB_MooSend\JetFormBuilder\Actions;

use Jet_FB_MooSend\BaseAction;
use JetMooSendCore\JetFormBuilder\SmartBaseAction;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Base_Type class
 */
class Action extends SmartBaseAction {

	use BaseAction;

	protected function getGlobalSettingsKeys() {
		return array(
			'api_key' => ''
		);
	}
}


