<?php
/**
 * Plugin Name: JetFormBuilder Moosend Action
 * Plugin URI:  https://jetformbuilder.com/addons/moosend/
 * Description: A form extension to effectively manage subscribers and automate email marketing.
 * Version:     1.0.1
 * Author:      Crocoblock
 * Author URI:  https://crocoblock.com/
 * Text Domain: jet-form-builder-moosend-action
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_FB_MOOSEND_ACTION_VERSION', '1.0.1' );

define( 'JET_FB_MOOSEND_ACTION__FILE__', __FILE__ );
define( 'JET_FB_MOOSEND_ACTION_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'JET_FB_MOOSEND_ACTION_PATH', plugin_dir_path( __FILE__ ) );
define( 'JET_FB_MOOSEND_ACTION_URL', plugins_url( '/', __FILE__ ) );

require 'vendor/autoload.php';

add_action( 'plugins_loaded', function () {

	if ( ! version_compare( PHP_VERSION, '7.0.0', '>=' ) ) {
		add_action( 'admin_notices', function () {
			$class   = 'notice notice-error';
			$message = __(
				'<b>Error:</b> <b>JetFormBuilder Moosend Action</b> plugin requires a PHP version ">= 7.0"',
				'jet-form-builder-moosend-action'
			);
			printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) );
		} );

		return;
	}
	require JET_FB_MOOSEND_ACTION_PATH . 'includes/plugin.php';
}, 100 );

