import { Actions } from "jfb-editor";
import { helpLink } from './help';

const { __ } = wp.i18n;

const getLocalizedFullPack = new Actions.EditorData( 'moosend' )
.setLabels( {
	api_key: __( 'API Key' ),
	validate_api_key: __( 'Validate API Key' ),
	retry_request: __( 'Retry request' ),
	double_opt_in: __( 'Double Opt-In' ),
	mailing_list: __( 'Mailing Lists' ),
	fields_map: __( 'Fields Map' ),
	use_global: __( 'Use Global Settings' )
} )
.setHelp( {
	...helpLink,
	fields_map: __( 'Set form fields names to to get user data from' ),
} )
.setGatewayAttrs( [
	"tag_id"
] )
.setSource( {
	action: 'jet_form_builder_get_moosend_data',
} )
.exportAll();

export { getLocalizedFullPack };