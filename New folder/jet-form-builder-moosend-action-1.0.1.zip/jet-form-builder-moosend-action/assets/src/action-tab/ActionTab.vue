<template>
	<cx-vui-input
		:label="label.api_key"
		:wrapper-css="[ 'equalwidth' ]"
		:description='`${ help.help_prefix } <a href="${ help.help_link }" target="_blank">${ help.help_suffix}</a>`'
		:size="'fullwidth'"
		v-model="api_key"
	/>
</template>
<script>
import {
	help,
	label,
} from "./source";

export default {
	name: 'moosend',
	props: {
		incoming: {
			type: Object,
			default() {
				return {};
			},
		},
	},
	data() {
		return {
			label, help,
			api_key: '',
		};
	},
	created() {
		this.api_key = this.incoming.api_key || ''
	},
	methods: {
		getRequestOnSave() {
			return {
				data: {
					api_key: this.api_key,
				},
			};
		},
	},
}

</script>