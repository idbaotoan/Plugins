import * as actionTab from '@/action-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.fb.register.settings-page.tabs', 'jet-form-builder', tabs => {
	tabs.push( actionTab );

	return tabs;
} );