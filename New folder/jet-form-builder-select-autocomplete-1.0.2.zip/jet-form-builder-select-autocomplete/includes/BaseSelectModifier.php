<?php


namespace Jet_FB_SelectAutocomplete;

use Jet_Form_Builder\Blocks\Render\Base as BaseRender;

/**
 * @method BaseRender|\Jet_Engine_Booking_Forms_Builder getClass()
 *
 * Trait BaseSelectModifier
 * @package Jet_FB_SelectAutocomplete
 */
trait BaseSelectModifier {

	public function onRender(): array {
		$args = $this->getArgs();

		if ( ! isset( $args['autocomplete_enable'] ) || ! $args['autocomplete_enable'] ) {
			return $args;
		}
		if ( isset( $args['autocomplete_via_ajax'] ) && $args['autocomplete_via_ajax'] ) {
			$this->getClass()->add_attribute( 'data-ajax--url', esc_url( admin_url( 'admin-ajax.php' ) ) );
		}
		if ( isset( $args['autocomplete_minimumInputLength'] ) ) {
			$this->getClass()->add_attribute( 'data-minimum-input-length', $args['autocomplete_minimumInputLength'] );
		}
		if ( isset( $args['placeholder'] ) && $args['placeholder'] ) {
			$this->getClass()->add_attribute( 'data-placeholder', $args['placeholder'] );
		}

		$this->getClass()->add_attribute( 'class', 'jet-select-autocomplete' );

		wp_enqueue_script(
			Plugin::instance()->slug . '-select2-lib',
			Plugin::instance()->plugin_url( 'assets/lib/js/select2.min.js' ),
			array( 'jquery', 'wp-hooks' ),
			'4.0.13',
			true
		);
		wp_enqueue_style(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/lib/css/select2.min.css' ),
			array(),
			'4.0.13'
		);

		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/js/frontend.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);

		return $args;
	}


}