<?php


namespace Jet_FB_SelectAutocomplete;


abstract class BaseAjaxHandler {

	protected $search;
	protected $form_id;
	protected $field_name;

	abstract public function type(): string;

	abstract public function get_field_options(): array;

	public function __construct() {
		$action = "jet_forms_select_autocomplete__{$this->type()}";

		add_action( "wp_ajax_{$action}", array( $this, 'on_request' ) );
		add_action( "wp_ajax_nopriv_{$action}", array( $this, 'on_request' ) );
	}

	public function on_request() {
		$this->form_id    = absint( $_POST['formId'] );
		$this->field_name = esc_attr( $_POST['fieldName'] );
		$this->search     = isset( $_POST['term'] ) ? sanitize_text_field( trim( $_POST['term'] ) ) : '';

		$options = $this->get_field_options();

		if ( ! $this->search ) {
			wp_send_json_success(
				array_values( array_map( array( $this, 'prepare_options' ), $options ) )
			);
		}

		$filtered_options = array_filter( $options, array( $this, 'filter_options' ) );

		wp_send_json_success(
			array_values( array_map( array( $this, 'prepare_options' ), $filtered_options ) )
		);
	}


	public function filter_options( $option ) {
		$haystack = apply_filters( 'jet-forms/select-autocomplete', $option['value'] . $option['label'], $option );

		return ( false !== mb_stripos( $haystack, wp_unslash( $this->search ) ) );
	}

	public function prepare_options( $option ) {
		return array(
			'id'   => $option['value'],
			'text' => $option['label']
		);
	}

}