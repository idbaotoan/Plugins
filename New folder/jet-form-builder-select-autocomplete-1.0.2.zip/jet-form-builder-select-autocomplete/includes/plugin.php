<?php

namespace Jet_FB_SelectAutocomplete;

use Jet_FB_SelectAutocomplete\JetFormBuilder\AjaxHandler as JFBAjaxHandler;
use Jet_FB_SelectAutocomplete\JetEngine\AjaxHandler as JEAjaxHandler;
use Jet_FB_SelectAutocomplete\JetFormBuilder\SelectModifier as JFBSelectModifier;
use Jet_FB_SelectAutocomplete\JetEngine\SelectModifier as JESelectModifier;

if ( ! defined( 'WPINC' ) ) {
	die();
}

class Plugin {
	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $slug = 'jet-form-builder-select-autocomplete';

	public function __construct() {
		JFBSelectModifier::register();
		JESelectModifier::register();

		new JFBAjaxHandler();
		new JEAjaxHandler();

		$can_init_license = (
			is_admin()
			&& function_exists( 'jet_form_builder' )
			&& array_key_exists( 'addons_manager', get_object_vars( jet_form_builder() ) )
		);

		if ( $can_init_license ) {
			require $this->plugin_dir( 'includes/class-jfb-license-manager.php' );

			new \JFB_License_Manager();
		}
	}

	public function get_version() {
		return JET_FB_SELECT_AUTOCOMPLETE_VERSION;
	}

	public function plugin_url( $path ) {
		return JET_FB_SELECT_AUTOCOMPLETE_URL . $path;
	}

	public function plugin_dir( $path = '' ) {
		return JET_FB_SELECT_AUTOCOMPLETE_PATH . $path;
	}

	public function get_template_path( $template ) {
		$path = JET_FB_SELECT_AUTOCOMPLETE_PATH . 'templates' . DIRECTORY_SEPARATOR;

		return ( $path . $template . '.php' );
	}


	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Plugin An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

Plugin::instance();