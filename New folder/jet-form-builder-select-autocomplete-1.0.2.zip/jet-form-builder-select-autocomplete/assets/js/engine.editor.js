/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./jet-engine/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../node_modules/babel-loader/lib/index.js!../node_modules/vue-loader/lib/index.js?!./jet-engine/Modifier.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************!*\
  !*** ../node_modules/babel-loader/lib!../node_modules/vue-loader/lib??vue-loader-options!./jet-engine/Modifier.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var jfb_editor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jfb-editor */ "../node_modules/jfb-editor/src/main.js");
/* harmony import */ var _source__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../source */ "./source.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'modify_select',
  components: {
    JetFormEditorRow: jfb_editor__WEBPACK_IMPORTED_MODULE_0__["JetFormEditorRow"]
  },
  props: ['value'],
  data: function data() {
    return {
      response: {},
      autocomplete_enable: _source__WEBPACK_IMPORTED_MODULE_1__["default"].autocomplete_enable,
      autocomplete_via_ajax: _source__WEBPACK_IMPORTED_MODULE_1__["default"].autocomplete_via_ajax,
      autocomplete_minimumInputLength: _source__WEBPACK_IMPORTED_MODULE_1__["default"].autocomplete_minimumInputLength
    };
  },
  created: function created() {
    this.response = _objectSpread(_objectSpread({}, this.response), this.value);
  },
  watch: {
    response: function response(newResponse) {
      this.$emit('input', newResponse);
    }
  },
  methods: {}
});

/***/ }),

/***/ "../node_modules/jfb-editor/src/actions/EditorData.js":
/*!************************************************************!*\
  !*** ../node_modules/jfb-editor/src/actions/EditorData.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
class EditorData {
	constructor( type, label ) {
		this.type = type;
		this.label = label;
		this.source = {};
		this.__labels = {};
		this.__help_messages = {};
		this.__gateway_attrs = {};
		this.__messages = {};
	}

	setSource( config ) {
		this.source = config;

		return this;
	}

	setLabels( config ) {
		this.__labels = config;

		return this;
	}

	setHelp( config ) {
		this.__help_messages = config;

		return this;
	}

	setGatewayAttrs( config ) {
		this.__gateway_attrs = config;

		return this;
	}

	setMessages( config ) {
		this.__messages = config;

		return this;
	}

	exportAll() {
		if ( ! ( 'jetFormActionTypes' in window ) ) {
			window.jetFormActionTypes = [];
		}

		const source = this.source;
		const label = this.exportLabels();
		const help = this.exportHelp();
		const gatewayAttrs = this.exportGatewayAttrs();
		const messages = this.exportMessages();

		const exportObj =  { source, label, help, messages, gatewayAttrs }

		window.jetFormActionTypes.push( {
			id: this.type,
			name: this.label,
			...exportObj
		} );

		return exportObj;
	}


	exportLabels() {
		return this.getLocalizedWithFunc( '__labels', '[Empty Label]' );
	};

	exportHelp() {
		return this.getLocalizedWithFunc( '__help_messages' );
	};

	exportGatewayAttrs() {
		return this.getLocalizedWithFunc( '__gateway_attrs', [] );
	};

	exportMessages() {
		return this.getLocalizedWithFunc( '__messages', {} );
	};

	getLocalizedWithFunc( objectKey, ifEmptyReturn = '' ) {

		let action = false;

		if ( objectKey in this ) {
			action = this[ objectKey ];
		}

		if ( ! action ) {
			return () => ifEmptyReturn;
		}

		return attr => {
			if ( attr ) {
				return ( action[ attr ] ? action[ attr ] : ifEmptyReturn );
			}
			else {
				return action;
			}
		};
	};
}

/* harmony default export */ __webpack_exports__["default"] = (EditorData);

/***/ }),

/***/ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue":
/*!*************************************************************************!*\
  !*** ../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./JetFormEditorRow.vue?vue&type=template&id=076e38b6& */ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6&");
/* harmony import */ var _JetFormEditorRow_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JetFormEditorRow.vue?vue&type=script&lang=js& */ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../vue-loader/lib/runtime/componentNormalizer.js */ "../node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _JetFormEditorRow_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************!*\
  !*** ../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vue_loader_lib_index_js_vue_loader_options_JetFormEditorRow_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../vue-loader/lib??vue-loader-options!./JetFormEditorRow.vue?vue&type=script&lang=js& */ "../node_modules/vue-loader/lib/index.js?!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_vue_loader_lib_index_js_vue_loader_options_JetFormEditorRow_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6&":
/*!********************************************************************************************************!*\
  !*** ../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6& ***!
  \********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _vue_loader_lib_loaders_templateLoader_js_vue_loader_options_vue_loader_lib_index_js_vue_loader_options_JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../vue-loader/lib??vue-loader-options!./JetFormEditorRow.vue?vue&type=template&id=076e38b6& */ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _vue_loader_lib_loaders_templateLoader_js_vue_loader_options_vue_loader_lib_index_js_vue_loader_options_JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _vue_loader_lib_loaders_templateLoader_js_vue_loader_options_vue_loader_lib_index_js_vue_loader_options_JetFormEditorRow_vue_vue_type_template_id_076e38b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "../node_modules/jfb-editor/src/main.js":
/*!**********************************************!*\
  !*** ../node_modules/jfb-editor/src/main.js ***!
  \**********************************************/
/*! exports provided: Actions, JetFormEditorRow */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Actions", function() { return Actions; });
/* harmony import */ var _actions_EditorData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./actions/EditorData */ "../node_modules/jfb-editor/src/actions/EditorData.js");
/* harmony import */ var _engine_editor_JetFormEditorRow__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./engine-editor/JetFormEditorRow */ "../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "JetFormEditorRow", function() { return _engine_editor_JetFormEditorRow__WEBPACK_IMPORTED_MODULE_1__["default"]; });




const Actions = { EditorData: _actions_EditorData__WEBPACK_IMPORTED_MODULE_0__["default"] };



/***/ }),

/***/ "../node_modules/vue-loader/lib/index.js?!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************!*\
  !*** ../node_modules/vue-loader/lib??vue-loader-options!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
	name: 'jet-form-editor-row',
	props: {
		label: {
			type: String,
			default: ''
		},
		labelClass: {
			type: String,
			default: ''
		},
		helpClass: {
			type: String,
			default: ''
		},
		controlClass: {
			type: String,
			default: ''
		},
	},
	computed: {
		labelClassObject() {
			return this.getClass( 'defaultLabelClass', 'labelClass' )
		},
		helpClassObject() {
			return this.getClass( 'defaultHelpClass', 'helpClass' )
		},
		controlClassObject() {
			return this.getClass( 'defaultControlClass', 'controlClass' )
		}
	},
	data() {
		return {
			defaultLabelClass: 'jet-form-editor__row-label',
			defaultHelpClass: 'jet-form-editor__row-notice',
			defaultControlClass: 'jet-form-editor__row-control',
		}
	},
	methods: {
		getClass( defaultKey, propKey ) {
			return {
				[ `${ this[ defaultKey ] } ${ this[ propKey ] }` ]: this[ propKey ],
				[ this[ defaultKey ] ]: ! this[ propKey ]
			};
		}
	}
});


/***/ }),

/***/ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6&":
/*!****************************************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../node_modules/vue-loader/lib??vue-loader-options!../node_modules/jfb-editor/src/engine-editor/JetFormEditorRow.vue?vue&type=template&id=076e38b6& ***!
  \****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "jet-form-editor__row" }, [
    _c("div", { class: _vm.labelClassObject }, [
      _vm._v("\n\t\t" + _vm._s(_vm.label) + "\n\t\t"),
      this.$slots.helpLabel
        ? _c("div", { class: _vm.helpClassObject }, [_vm._t("helpLabel")], 2)
        : _vm._e()
    ]),
    _vm._v(" "),
    _c(
      "div",
      { class: _vm.controlClassObject },
      [
        _vm._t("default"),
        _vm._v(" "),
        this.$slots.helpControl
          ? _c(
              "div",
              { class: _vm.helpClassObject },
              [_vm._t("helpControl")],
              2
            )
          : _vm._e()
      ],
      2
    ),
    _vm._v(" "),
    this.$slots.helpSide
      ? _c(
          "div",
          { class: _vm.helpClassObject },
          [_vm._v("\n\t\t    "), _vm._t("helpSide")],
          2
        )
      : _vm._e()
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c&":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../node_modules/vue-loader/lib??vue-loader-options!./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c& ***!
  \************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "select-autocomplete" },
    [
      _c(
        "JetFormEditorRow",
        {
          attrs: { label: _vm.autocomplete_enable.label },
          scopedSlots: _vm._u([
            {
              key: "helpSide",
              fn: function() {
                return [_vm._v(_vm._s(_vm.autocomplete_enable.help))]
              },
              proxy: true
            }
          ])
        },
        [
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.response.autocomplete_enable,
                expression: "response.autocomplete_enable"
              }
            ],
            attrs: { type: "checkbox" },
            domProps: {
              checked: Array.isArray(_vm.response.autocomplete_enable)
                ? _vm._i(_vm.response.autocomplete_enable, null) > -1
                : _vm.response.autocomplete_enable
            },
            on: {
              change: function($event) {
                var $$a = _vm.response.autocomplete_enable,
                  $$el = $event.target,
                  $$c = $$el.checked ? true : false
                if (Array.isArray($$a)) {
                  var $$v = null,
                    $$i = _vm._i($$a, $$v)
                  if ($$el.checked) {
                    $$i < 0 &&
                      _vm.$set(
                        _vm.response,
                        "autocomplete_enable",
                        $$a.concat([$$v])
                      )
                  } else {
                    $$i > -1 &&
                      _vm.$set(
                        _vm.response,
                        "autocomplete_enable",
                        $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                      )
                  }
                } else {
                  _vm.$set(_vm.response, "autocomplete_enable", $$c)
                }
              }
            }
          })
        ]
      ),
      _vm._v(" "),
      _vm.response.autocomplete_enable
        ? _c(
            "JetFormEditorRow",
            { attrs: { label: _vm.autocomplete_via_ajax.label } },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.response.autocomplete_via_ajax,
                    expression: "response.autocomplete_via_ajax"
                  }
                ],
                attrs: { type: "checkbox" },
                domProps: {
                  checked: Array.isArray(_vm.response.autocomplete_via_ajax)
                    ? _vm._i(_vm.response.autocomplete_via_ajax, null) > -1
                    : _vm.response.autocomplete_via_ajax
                },
                on: {
                  change: function($event) {
                    var $$a = _vm.response.autocomplete_via_ajax,
                      $$el = $event.target,
                      $$c = $$el.checked ? true : false
                    if (Array.isArray($$a)) {
                      var $$v = null,
                        $$i = _vm._i($$a, $$v)
                      if ($$el.checked) {
                        $$i < 0 &&
                          _vm.$set(
                            _vm.response,
                            "autocomplete_via_ajax",
                            $$a.concat([$$v])
                          )
                      } else {
                        $$i > -1 &&
                          _vm.$set(
                            _vm.response,
                            "autocomplete_via_ajax",
                            $$a.slice(0, $$i).concat($$a.slice($$i + 1))
                          )
                      }
                    } else {
                      _vm.$set(_vm.response, "autocomplete_via_ajax", $$c)
                    }
                  }
                }
              })
            ]
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.response.autocomplete_enable
        ? _c(
            "JetFormEditorRow",
            {
              attrs: { label: _vm.autocomplete_minimumInputLength.label },
              scopedSlots: _vm._u(
                [
                  {
                    key: "helpControl",
                    fn: function() {
                      return [
                        _vm._v(_vm._s(_vm.autocomplete_minimumInputLength.help))
                      ]
                    },
                    proxy: true
                  }
                ],
                null,
                false,
                3132697884
              )
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.response.autocomplete_minimumInputLength,
                    expression: "response.autocomplete_minimumInputLength"
                  }
                ],
                attrs: { type: "number" },
                domProps: {
                  value: _vm.response.autocomplete_minimumInputLength
                },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.$set(
                      _vm.response,
                      "autocomplete_minimumInputLength",
                      $event.target.value
                    )
                  }
                }
              })
            ]
          )
        : _vm._e()
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "../node_modules/vue-loader/lib/runtime/componentNormalizer.js":
/*!*********************************************************************!*\
  !*** ../node_modules/vue-loader/lib/runtime/componentNormalizer.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return normalizeComponent; });
/* globals __VUE_SSR_CONTEXT__ */

// IMPORTANT: Do NOT use ES2015 features in this file (except for modules).
// This module is a runtime utility for cleaner component module output and will
// be included in the final webpack user bundle.

function normalizeComponent (
  scriptExports,
  render,
  staticRenderFns,
  functionalTemplate,
  injectStyles,
  scopeId,
  moduleIdentifier, /* server only */
  shadowMode /* vue-cli only */
) {
  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (render) {
    options.render = render
    options.staticRenderFns = staticRenderFns
    options._compiled = true
  }

  // functional template
  if (functionalTemplate) {
    options.functional = true
  }

  // scopedId
  if (scopeId) {
    options._scopeId = 'data-v-' + scopeId
  }

  var hook
  if (moduleIdentifier) { // server build
    hook = function (context) {
      // 2.3 injection
      context =
        context || // cached call
        (this.$vnode && this.$vnode.ssrContext) || // stateful
        (this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) // functional
      // 2.2 with runInNewContext: true
      if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
        context = __VUE_SSR_CONTEXT__
      }
      // inject component styles
      if (injectStyles) {
        injectStyles.call(this, context)
      }
      // register component module identifier for async chunk inferrence
      if (context && context._registeredComponents) {
        context._registeredComponents.add(moduleIdentifier)
      }
    }
    // used by ssr in case component is cached and beforeCreate
    // never gets called
    options._ssrRegister = hook
  } else if (injectStyles) {
    hook = shadowMode
      ? function () {
        injectStyles.call(
          this,
          (options.functional ? this.parent : this).$root.$options.shadowRoot
        )
      }
      : injectStyles
  }

  if (hook) {
    if (options.functional) {
      // for template-only hot-reload because in that case the render fn doesn't
      // go through the normalizer
      options._injectStyles = hook
      // register for functional component in vue file
      var originalRender = options.render
      options.render = function renderWithStyleInjection (h, context) {
        hook.call(context)
        return originalRender(h, context)
      }
    } else {
      // inject component registration as beforeCreate hook
      var existing = options.beforeCreate
      options.beforeCreate = existing
        ? [].concat(existing, hook)
        : [hook]
    }
  }

  return {
    exports: scriptExports,
    options: options
  }
}


/***/ }),

/***/ "./jet-engine/Modifier.vue":
/*!*********************************!*\
  !*** ./jet-engine/Modifier.vue ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Modifier.vue?vue&type=template&id=8048ca5c& */ "./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c&");
/* harmony import */ var _Modifier_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Modifier.vue?vue&type=script&lang=js& */ "./jet-engine/Modifier.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "../node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Modifier_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "jet-engine/Modifier.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./jet-engine/Modifier.vue?vue&type=script&lang=js&":
/*!**********************************************************!*\
  !*** ./jet-engine/Modifier.vue?vue&type=script&lang=js& ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Modifier_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib??vue-loader-options!./Modifier.vue?vue&type=script&lang=js& */ "../node_modules/babel-loader/lib/index.js!../node_modules/vue-loader/lib/index.js?!./jet-engine/Modifier.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Modifier_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c&":
/*!****************************************************************!*\
  !*** ./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c& ***!
  \****************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/vue-loader/lib??vue-loader-options!./Modifier.vue?vue&type=template&id=8048ca5c& */ "../node_modules/vue-loader/lib/loaders/templateLoader.js?!../node_modules/vue-loader/lib/index.js?!./jet-engine/Modifier.vue?vue&type=template&id=8048ca5c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Modifier_vue_vue_type_template_id_8048ca5c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./jet-engine/main.js":
/*!****************************!*\
  !*** ./jet-engine/main.js ***!
  \****************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Modifier_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Modifier.vue */ "./jet-engine/Modifier.vue");

var addFilter = wp.hooks.addFilter;
addFilter('jet.engine.register.fields', 'jet-engine', function (fields) {
  fields.push(_Modifier_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);
  return fields;
});

/***/ }),

/***/ "./source.js":
/*!*******************!*\
  !*** ./source.js ***!
  \*******************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var __ = wp.i18n.__;
/* harmony default export */ __webpack_exports__["default"] = ({
  autocomplete_enable: {
    label: __('Use Autocomplete'),
    help: __('Adding a text box to search among options', 'jet-form-builder-select-autocomplete')
  },
  autocomplete_via_ajax: {
    label: __('Loading via AJAX')
  },
  autocomplete_minimumInputLength: {
    label: __('Minimum input length'),
    help: __('Number of characters required to perform a search', 'jet-form-builder-select-autocomplete')
  }
});

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5naW5lLmVkaXRvci5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly8vTW9kaWZpZXIudnVlIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvamZiLWVkaXRvci9zcmMvYWN0aW9ucy9FZGl0b3JEYXRhLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvamZiLWVkaXRvci9zcmMvZW5naW5lLWVkaXRvci9KZXRGb3JtRWRpdG9yUm93LnZ1ZSIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2pmYi1lZGl0b3Ivc3JjL2VuZ2luZS1lZGl0b3IvSmV0Rm9ybUVkaXRvclJvdy52dWU/NGMwOSIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2pmYi1lZGl0b3Ivc3JjL2VuZ2luZS1lZGl0b3IvSmV0Rm9ybUVkaXRvclJvdy52dWU/NWNkYyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL2pmYi1lZGl0b3Ivc3JjL21haW4uanMiLCJ3ZWJwYWNrOi8vL0pldEZvcm1FZGl0b3JSb3cudnVlIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvamZiLWVkaXRvci9zcmMvZW5naW5lLWVkaXRvci9KZXRGb3JtRWRpdG9yUm93LnZ1ZT9mN2E5Iiwid2VicGFjazovLy8uL2pldC1lbmdpbmUvTW9kaWZpZXIudnVlP2Y1NDIiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanMiLCJ3ZWJwYWNrOi8vLy4vamV0LWVuZ2luZS9Nb2RpZmllci52dWUiLCJ3ZWJwYWNrOi8vLy4vamV0LWVuZ2luZS9Nb2RpZmllci52dWU/NjljMCIsIndlYnBhY2s6Ly8vLi9qZXQtZW5naW5lL01vZGlmaWVyLnZ1ZT82N2QwIiwid2VicGFjazovLy8uL2pldC1lbmdpbmUvbWFpbi5qcyIsIndlYnBhY2s6Ly8vLi9zb3VyY2UuanMiXSwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9qZXQtZW5naW5lL21haW4uanNcIik7XG4iLCI8dGVtcGxhdGU+XHJcblx0PGRpdiBjbGFzcz1cInNlbGVjdC1hdXRvY29tcGxldGVcIj5cclxuXHRcdDxKZXRGb3JtRWRpdG9yUm93IDpsYWJlbD1cImF1dG9jb21wbGV0ZV9lbmFibGUubGFiZWxcIj5cclxuXHRcdFx0PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIHYtbW9kZWw9XCJyZXNwb25zZS5hdXRvY29tcGxldGVfZW5hYmxlXCI+XHJcblx0XHRcdDx0ZW1wbGF0ZSB2LXNsb3Q6aGVscFNpZGU+e3sgYXV0b2NvbXBsZXRlX2VuYWJsZS5oZWxwIH19PC90ZW1wbGF0ZT5cclxuXHRcdDwvSmV0Rm9ybUVkaXRvclJvdz5cclxuXHRcdDxKZXRGb3JtRWRpdG9yUm93IDpsYWJlbD1cImF1dG9jb21wbGV0ZV92aWFfYWpheC5sYWJlbFwiIHYtaWY9XCJyZXNwb25zZS5hdXRvY29tcGxldGVfZW5hYmxlXCI+XHJcblx0XHRcdDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiB2LW1vZGVsPVwicmVzcG9uc2UuYXV0b2NvbXBsZXRlX3ZpYV9hamF4XCI+XHJcblx0XHQ8L0pldEZvcm1FZGl0b3JSb3c+XHJcblx0XHQ8SmV0Rm9ybUVkaXRvclJvdyA6bGFiZWw9XCJhdXRvY29tcGxldGVfbWluaW11bUlucHV0TGVuZ3RoLmxhYmVsXCIgdi1pZj1cInJlc3BvbnNlLmF1dG9jb21wbGV0ZV9lbmFibGVcIj5cclxuXHRcdFx0PGlucHV0IHR5cGU9XCJudW1iZXJcIiB2LW1vZGVsPVwicmVzcG9uc2UuYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aFwiPlxyXG5cdFx0XHQ8dGVtcGxhdGUgdi1zbG90OmhlbHBDb250cm9sPnt7IGF1dG9jb21wbGV0ZV9taW5pbXVtSW5wdXRMZW5ndGguaGVscCB9fTwvdGVtcGxhdGU+XHJcblx0XHQ8L0pldEZvcm1FZGl0b3JSb3c+XHJcblx0PC9kaXY+XHJcbjwvdGVtcGxhdGU+XHJcblxyXG48c2NyaXB0PlxyXG5pbXBvcnQgeyBKZXRGb3JtRWRpdG9yUm93IH0gZnJvbSAnamZiLWVkaXRvcic7XHJcbmltcG9ydCBzb3VyY2UgZnJvbSAnLi4vc291cmNlJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHtcclxuXHRuYW1lOiAgICAgICAnbW9kaWZ5X3NlbGVjdCcsXHJcblx0Y29tcG9uZW50czoge1xyXG5cdFx0SmV0Rm9ybUVkaXRvclJvdyxcclxuXHR9LFxyXG5cdHByb3BzOiAgICAgIFsgJ3ZhbHVlJyBdLFxyXG5cdGRhdGEoKSB7XHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRyZXNwb25zZTogICAgICAgICAgICAgICAgICAgICAgICB7fSxcclxuXHRcdFx0YXV0b2NvbXBsZXRlX2VuYWJsZTogICAgICAgICAgICAgc291cmNlLmF1dG9jb21wbGV0ZV9lbmFibGUsXHJcblx0XHRcdGF1dG9jb21wbGV0ZV92aWFfYWpheDogICAgICAgICAgIHNvdXJjZS5hdXRvY29tcGxldGVfdmlhX2FqYXgsXHJcblx0XHRcdGF1dG9jb21wbGV0ZV9taW5pbXVtSW5wdXRMZW5ndGg6IHNvdXJjZS5hdXRvY29tcGxldGVfbWluaW11bUlucHV0TGVuZ3RoLFxyXG5cdFx0fVxyXG5cdH0sXHJcblx0Y3JlYXRlZCgpIHtcclxuXHRcdHRoaXMucmVzcG9uc2UgPSB7IC4uLnRoaXMucmVzcG9uc2UsIC4uLnRoaXMudmFsdWUgfTtcclxuXHR9LFxyXG5cdHdhdGNoOiAgICAgIHtcclxuXHRcdHJlc3BvbnNlKCBuZXdSZXNwb25zZSApIHtcclxuXHRcdFx0dGhpcy4kZW1pdCggJ2lucHV0JywgbmV3UmVzcG9uc2UgKTtcclxuXHRcdH0sXHJcblx0fSxcclxuXHRtZXRob2RzOiAgICB7fSxcclxufVxyXG5cclxuPC9zY3JpcHQ+IiwiY2xhc3MgRWRpdG9yRGF0YSB7XHJcblx0Y29uc3RydWN0b3IoIHR5cGUsIGxhYmVsICkge1xyXG5cdFx0dGhpcy50eXBlID0gdHlwZTtcclxuXHRcdHRoaXMubGFiZWwgPSBsYWJlbDtcclxuXHRcdHRoaXMuc291cmNlID0ge307XHJcblx0XHR0aGlzLl9fbGFiZWxzID0ge307XHJcblx0XHR0aGlzLl9faGVscF9tZXNzYWdlcyA9IHt9O1xyXG5cdFx0dGhpcy5fX2dhdGV3YXlfYXR0cnMgPSB7fTtcclxuXHRcdHRoaXMuX19tZXNzYWdlcyA9IHt9O1xyXG5cdH1cclxuXHJcblx0c2V0U291cmNlKCBjb25maWcgKSB7XHJcblx0XHR0aGlzLnNvdXJjZSA9IGNvbmZpZztcclxuXHJcblx0XHRyZXR1cm4gdGhpcztcclxuXHR9XHJcblxyXG5cdHNldExhYmVscyggY29uZmlnICkge1xyXG5cdFx0dGhpcy5fX2xhYmVscyA9IGNvbmZpZztcclxuXHJcblx0XHRyZXR1cm4gdGhpcztcclxuXHR9XHJcblxyXG5cdHNldEhlbHAoIGNvbmZpZyApIHtcclxuXHRcdHRoaXMuX19oZWxwX21lc3NhZ2VzID0gY29uZmlnO1xyXG5cclxuXHRcdHJldHVybiB0aGlzO1xyXG5cdH1cclxuXHJcblx0c2V0R2F0ZXdheUF0dHJzKCBjb25maWcgKSB7XHJcblx0XHR0aGlzLl9fZ2F0ZXdheV9hdHRycyA9IGNvbmZpZztcclxuXHJcblx0XHRyZXR1cm4gdGhpcztcclxuXHR9XHJcblxyXG5cdHNldE1lc3NhZ2VzKCBjb25maWcgKSB7XHJcblx0XHR0aGlzLl9fbWVzc2FnZXMgPSBjb25maWc7XHJcblxyXG5cdFx0cmV0dXJuIHRoaXM7XHJcblx0fVxyXG5cclxuXHRleHBvcnRBbGwoKSB7XHJcblx0XHRpZiAoICEgKCAnamV0Rm9ybUFjdGlvblR5cGVzJyBpbiB3aW5kb3cgKSApIHtcclxuXHRcdFx0d2luZG93LmpldEZvcm1BY3Rpb25UeXBlcyA9IFtdO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IHNvdXJjZSA9IHRoaXMuc291cmNlO1xyXG5cdFx0Y29uc3QgbGFiZWwgPSB0aGlzLmV4cG9ydExhYmVscygpO1xyXG5cdFx0Y29uc3QgaGVscCA9IHRoaXMuZXhwb3J0SGVscCgpO1xyXG5cdFx0Y29uc3QgZ2F0ZXdheUF0dHJzID0gdGhpcy5leHBvcnRHYXRld2F5QXR0cnMoKTtcclxuXHRcdGNvbnN0IG1lc3NhZ2VzID0gdGhpcy5leHBvcnRNZXNzYWdlcygpO1xyXG5cclxuXHRcdGNvbnN0IGV4cG9ydE9iaiA9ICB7IHNvdXJjZSwgbGFiZWwsIGhlbHAsIG1lc3NhZ2VzLCBnYXRld2F5QXR0cnMgfVxyXG5cclxuXHRcdHdpbmRvdy5qZXRGb3JtQWN0aW9uVHlwZXMucHVzaCgge1xyXG5cdFx0XHRpZDogdGhpcy50eXBlLFxyXG5cdFx0XHRuYW1lOiB0aGlzLmxhYmVsLFxyXG5cdFx0XHQuLi5leHBvcnRPYmpcclxuXHRcdH0gKTtcclxuXHJcblx0XHRyZXR1cm4gZXhwb3J0T2JqO1xyXG5cdH1cclxuXHJcblxyXG5cdGV4cG9ydExhYmVscygpIHtcclxuXHRcdHJldHVybiB0aGlzLmdldExvY2FsaXplZFdpdGhGdW5jKCAnX19sYWJlbHMnLCAnW0VtcHR5IExhYmVsXScgKTtcclxuXHR9O1xyXG5cclxuXHRleHBvcnRIZWxwKCkge1xyXG5cdFx0cmV0dXJuIHRoaXMuZ2V0TG9jYWxpemVkV2l0aEZ1bmMoICdfX2hlbHBfbWVzc2FnZXMnICk7XHJcblx0fTtcclxuXHJcblx0ZXhwb3J0R2F0ZXdheUF0dHJzKCkge1xyXG5cdFx0cmV0dXJuIHRoaXMuZ2V0TG9jYWxpemVkV2l0aEZ1bmMoICdfX2dhdGV3YXlfYXR0cnMnLCBbXSApO1xyXG5cdH07XHJcblxyXG5cdGV4cG9ydE1lc3NhZ2VzKCkge1xyXG5cdFx0cmV0dXJuIHRoaXMuZ2V0TG9jYWxpemVkV2l0aEZ1bmMoICdfX21lc3NhZ2VzJywge30gKTtcclxuXHR9O1xyXG5cclxuXHRnZXRMb2NhbGl6ZWRXaXRoRnVuYyggb2JqZWN0S2V5LCBpZkVtcHR5UmV0dXJuID0gJycgKSB7XHJcblxyXG5cdFx0bGV0IGFjdGlvbiA9IGZhbHNlO1xyXG5cclxuXHRcdGlmICggb2JqZWN0S2V5IGluIHRoaXMgKSB7XHJcblx0XHRcdGFjdGlvbiA9IHRoaXNbIG9iamVjdEtleSBdO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICggISBhY3Rpb24gKSB7XHJcblx0XHRcdHJldHVybiAoKSA9PiBpZkVtcHR5UmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdHJldHVybiBhdHRyID0+IHtcclxuXHRcdFx0aWYgKCBhdHRyICkge1xyXG5cdFx0XHRcdHJldHVybiAoIGFjdGlvblsgYXR0ciBdID8gYWN0aW9uWyBhdHRyIF0gOiBpZkVtcHR5UmV0dXJuICk7XHJcblx0XHRcdH1cclxuXHRcdFx0ZWxzZSB7XHJcblx0XHRcdFx0cmV0dXJuIGFjdGlvbjtcclxuXHRcdFx0fVxyXG5cdFx0fTtcclxuXHR9O1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFZGl0b3JEYXRhOyIsImltcG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0gZnJvbSBcIi4vSmV0Rm9ybUVkaXRvclJvdy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MDc2ZTM4YjYmXCJcbmltcG9ydCBzY3JpcHQgZnJvbSBcIi4vSmV0Rm9ybUVkaXRvclJvdy52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9anMmXCJcbmV4cG9ydCAqIGZyb20gXCIuL0pldEZvcm1FZGl0b3JSb3cudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzJlwiXG5cblxuLyogbm9ybWFsaXplIGNvbXBvbmVudCAqL1xuaW1wb3J0IG5vcm1hbGl6ZXIgZnJvbSBcIiEuLi8uLi8uLi92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanNcIlxudmFyIGNvbXBvbmVudCA9IG5vcm1hbGl6ZXIoXG4gIHNjcmlwdCxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZhbHNlLFxuICBudWxsLFxuICBudWxsLFxuICBudWxsXG4gIFxuKVxuXG4vKiBob3QgcmVsb2FkICovXG5pZiAobW9kdWxlLmhvdCkge1xuICB2YXIgYXBpID0gcmVxdWlyZShcIkM6XFxcXE9wZW5TZXJ2ZXJcXFxcZG9tYWluc1xcXFxkZXZlbG9wLmpldFxcXFx3cC1jb250ZW50XFxcXHBsdWdpbnNcXFxcamV0LWZvcm0tYnVpbGRlci1zZWxlY3QtYXV0b2NvbXBsZXRlXFxcXGFzc2V0c1xcXFxub2RlX21vZHVsZXNcXFxcdnVlLWhvdC1yZWxvYWQtYXBpXFxcXGRpc3RcXFxcaW5kZXguanNcIilcbiAgYXBpLmluc3RhbGwocmVxdWlyZSgndnVlJykpXG4gIGlmIChhcGkuY29tcGF0aWJsZSkge1xuICAgIG1vZHVsZS5ob3QuYWNjZXB0KClcbiAgICBpZiAoIWFwaS5pc1JlY29yZGVkKCcwNzZlMzhiNicpKSB7XG4gICAgICBhcGkuY3JlYXRlUmVjb3JkKCcwNzZlMzhiNicsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH0gZWxzZSB7XG4gICAgICBhcGkucmVsb2FkKCcwNzZlMzhiNicsIGNvbXBvbmVudC5vcHRpb25zKVxuICAgIH1cbiAgICBtb2R1bGUuaG90LmFjY2VwdChcIi4vSmV0Rm9ybUVkaXRvclJvdy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MDc2ZTM4YjYmXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGFwaS5yZXJlbmRlcignMDc2ZTM4YjYnLCB7XG4gICAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgICBzdGF0aWNSZW5kZXJGbnM6IHN0YXRpY1JlbmRlckZuc1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG5jb21wb25lbnQub3B0aW9ucy5fX2ZpbGUgPSBcIm5vZGVfbW9kdWxlcy9qZmItZWRpdG9yL3NyYy9lbmdpbmUtZWRpdG9yL0pldEZvcm1FZGl0b3JSb3cudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi8uLi92dWUtbG9hZGVyL2xpYi9pbmRleC5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4vSmV0Rm9ybUVkaXRvclJvdy52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9anMmXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL0pldEZvcm1FZGl0b3JSb3cudnVlP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzJlwiIiwiZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vdnVlLWxvYWRlci9saWIvbG9hZGVycy90ZW1wbGF0ZUxvYWRlci5qcz8/dnVlLWxvYWRlci1vcHRpb25zIS4uLy4uLy4uL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9KZXRGb3JtRWRpdG9yUm93LnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0wNzZlMzhiNiZcIiIsImltcG9ydCBFZGl0b3JEYXRhIGZyb20gXCIuL2FjdGlvbnMvRWRpdG9yRGF0YVwiO1xyXG5pbXBvcnQgSmV0Rm9ybUVkaXRvclJvdyBmcm9tIFwiLi9lbmdpbmUtZWRpdG9yL0pldEZvcm1FZGl0b3JSb3dcIjtcclxuXHJcbmNvbnN0IEFjdGlvbnMgPSB7IEVkaXRvckRhdGEgfTtcclxuXHJcbmV4cG9ydCB7IEFjdGlvbnMsIEpldEZvcm1FZGl0b3JSb3cgfTsiLCI8dGVtcGxhdGU+XHJcblx0PGRpdiBjbGFzcz1cImpldC1mb3JtLWVkaXRvcl9fcm93XCI+XHJcblx0XHQ8ZGl2IDpjbGFzcz1cImxhYmVsQ2xhc3NPYmplY3RcIj5cclxuXHRcdFx0e3sgbGFiZWwgfX1cclxuXHRcdFx0PGRpdiA6Y2xhc3M9XCJoZWxwQ2xhc3NPYmplY3RcIiB2LWlmPVwidGhpcy4kc2xvdHMuaGVscExhYmVsXCI+XHJcblx0XHRcdFx0PHNsb3QgbmFtZT1cImhlbHBMYWJlbFwiPjwvc2xvdD5cclxuXHRcdFx0PC9kaXY+XHJcblx0XHQ8L2Rpdj5cclxuXHRcdDxkaXYgOmNsYXNzPVwiY29udHJvbENsYXNzT2JqZWN0XCI+XHJcblx0XHRcdDxzbG90Pjwvc2xvdD5cclxuXHRcdFx0PGRpdiA6Y2xhc3M9XCJoZWxwQ2xhc3NPYmplY3RcIiB2LWlmPVwidGhpcy4kc2xvdHMuaGVscENvbnRyb2xcIj5cclxuXHRcdFx0XHQ8c2xvdCBuYW1lPVwiaGVscENvbnRyb2xcIj48L3Nsb3Q+XHJcblx0XHRcdDwvZGl2PlxyXG5cdFx0PC9kaXY+XHJcblx0XHQ8ZGl2IDpjbGFzcz1cImhlbHBDbGFzc09iamVjdFwiIHYtaWY9XCJ0aGlzLiRzbG90cy5oZWxwU2lkZVwiPlxyXG5cdFx0XHQmbmJzcDsmbmJzcDsmbmJzcDsmbmJzcDs8c2xvdCBuYW1lPVwiaGVscFNpZGVcIj48L3Nsb3Q+XHJcblx0XHQ8L2Rpdj5cclxuXHQ8L2Rpdj5cclxuPC90ZW1wbGF0ZT5cclxuXHJcbjxzY3JpcHQ+XHJcblxyXG5leHBvcnQgZGVmYXVsdCB7XHJcblx0bmFtZTogJ2pldC1mb3JtLWVkaXRvci1yb3cnLFxyXG5cdHByb3BzOiB7XHJcblx0XHRsYWJlbDoge1xyXG5cdFx0XHR0eXBlOiBTdHJpbmcsXHJcblx0XHRcdGRlZmF1bHQ6ICcnXHJcblx0XHR9LFxyXG5cdFx0bGFiZWxDbGFzczoge1xyXG5cdFx0XHR0eXBlOiBTdHJpbmcsXHJcblx0XHRcdGRlZmF1bHQ6ICcnXHJcblx0XHR9LFxyXG5cdFx0aGVscENsYXNzOiB7XHJcblx0XHRcdHR5cGU6IFN0cmluZyxcclxuXHRcdFx0ZGVmYXVsdDogJydcclxuXHRcdH0sXHJcblx0XHRjb250cm9sQ2xhc3M6IHtcclxuXHRcdFx0dHlwZTogU3RyaW5nLFxyXG5cdFx0XHRkZWZhdWx0OiAnJ1xyXG5cdFx0fSxcclxuXHR9LFxyXG5cdGNvbXB1dGVkOiB7XHJcblx0XHRsYWJlbENsYXNzT2JqZWN0KCkge1xyXG5cdFx0XHRyZXR1cm4gdGhpcy5nZXRDbGFzcyggJ2RlZmF1bHRMYWJlbENsYXNzJywgJ2xhYmVsQ2xhc3MnIClcclxuXHRcdH0sXHJcblx0XHRoZWxwQ2xhc3NPYmplY3QoKSB7XHJcblx0XHRcdHJldHVybiB0aGlzLmdldENsYXNzKCAnZGVmYXVsdEhlbHBDbGFzcycsICdoZWxwQ2xhc3MnIClcclxuXHRcdH0sXHJcblx0XHRjb250cm9sQ2xhc3NPYmplY3QoKSB7XHJcblx0XHRcdHJldHVybiB0aGlzLmdldENsYXNzKCAnZGVmYXVsdENvbnRyb2xDbGFzcycsICdjb250cm9sQ2xhc3MnIClcclxuXHRcdH1cclxuXHR9LFxyXG5cdGRhdGEoKSB7XHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRkZWZhdWx0TGFiZWxDbGFzczogJ2pldC1mb3JtLWVkaXRvcl9fcm93LWxhYmVsJyxcclxuXHRcdFx0ZGVmYXVsdEhlbHBDbGFzczogJ2pldC1mb3JtLWVkaXRvcl9fcm93LW5vdGljZScsXHJcblx0XHRcdGRlZmF1bHRDb250cm9sQ2xhc3M6ICdqZXQtZm9ybS1lZGl0b3JfX3Jvdy1jb250cm9sJyxcclxuXHRcdH1cclxuXHR9LFxyXG5cdG1ldGhvZHM6IHtcclxuXHRcdGdldENsYXNzKCBkZWZhdWx0S2V5LCBwcm9wS2V5ICkge1xyXG5cdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdFsgYCR7IHRoaXNbIGRlZmF1bHRLZXkgXSB9ICR7IHRoaXNbIHByb3BLZXkgXSB9YCBdOiB0aGlzWyBwcm9wS2V5IF0sXHJcblx0XHRcdFx0WyB0aGlzWyBkZWZhdWx0S2V5IF0gXTogISB0aGlzWyBwcm9wS2V5IF1cclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHR9XHJcbn1cclxuPC9zY3JpcHQ+IiwidmFyIHJlbmRlciA9IGZ1bmN0aW9uKCkge1xuICB2YXIgX3ZtID0gdGhpc1xuICB2YXIgX2ggPSBfdm0uJGNyZWF0ZUVsZW1lbnRcbiAgdmFyIF9jID0gX3ZtLl9zZWxmLl9jIHx8IF9oXG4gIHJldHVybiBfYyhcImRpdlwiLCB7IHN0YXRpY0NsYXNzOiBcImpldC1mb3JtLWVkaXRvcl9fcm93XCIgfSwgW1xuICAgIF9jKFwiZGl2XCIsIHsgY2xhc3M6IF92bS5sYWJlbENsYXNzT2JqZWN0IH0sIFtcbiAgICAgIF92bS5fdihcIlxcblxcdFxcdFwiICsgX3ZtLl9zKF92bS5sYWJlbCkgKyBcIlxcblxcdFxcdFwiKSxcbiAgICAgIHRoaXMuJHNsb3RzLmhlbHBMYWJlbFxuICAgICAgICA/IF9jKFwiZGl2XCIsIHsgY2xhc3M6IF92bS5oZWxwQ2xhc3NPYmplY3QgfSwgW192bS5fdChcImhlbHBMYWJlbFwiKV0sIDIpXG4gICAgICAgIDogX3ZtLl9lKClcbiAgICBdKSxcbiAgICBfdm0uX3YoXCIgXCIpLFxuICAgIF9jKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IF92bS5jb250cm9sQ2xhc3NPYmplY3QgfSxcbiAgICAgIFtcbiAgICAgICAgX3ZtLl90KFwiZGVmYXVsdFwiKSxcbiAgICAgICAgX3ZtLl92KFwiIFwiKSxcbiAgICAgICAgdGhpcy4kc2xvdHMuaGVscENvbnRyb2xcbiAgICAgICAgICA/IF9jKFxuICAgICAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgICAgICB7IGNsYXNzOiBfdm0uaGVscENsYXNzT2JqZWN0IH0sXG4gICAgICAgICAgICAgIFtfdm0uX3QoXCJoZWxwQ29udHJvbFwiKV0sXG4gICAgICAgICAgICAgIDJcbiAgICAgICAgICAgIClcbiAgICAgICAgICA6IF92bS5fZSgpXG4gICAgICBdLFxuICAgICAgMlxuICAgICksXG4gICAgX3ZtLl92KFwiIFwiKSxcbiAgICB0aGlzLiRzbG90cy5oZWxwU2lkZVxuICAgICAgPyBfYyhcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IF92bS5oZWxwQ2xhc3NPYmplY3QgfSxcbiAgICAgICAgICBbX3ZtLl92KFwiXFxuXFx0XFx0wqDCoMKgwqBcIiksIF92bS5fdChcImhlbHBTaWRlXCIpXSxcbiAgICAgICAgICAyXG4gICAgICAgIClcbiAgICAgIDogX3ZtLl9lKClcbiAgXSlcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbXVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5cbmV4cG9ydCB7IHJlbmRlciwgc3RhdGljUmVuZGVyRm5zIH0iLCJ2YXIgcmVuZGVyID0gZnVuY3Rpb24oKSB7XG4gIHZhciBfdm0gPSB0aGlzXG4gIHZhciBfaCA9IF92bS4kY3JlYXRlRWxlbWVudFxuICB2YXIgX2MgPSBfdm0uX3NlbGYuX2MgfHwgX2hcbiAgcmV0dXJuIF9jKFxuICAgIFwiZGl2XCIsXG4gICAgeyBzdGF0aWNDbGFzczogXCJzZWxlY3QtYXV0b2NvbXBsZXRlXCIgfSxcbiAgICBbXG4gICAgICBfYyhcbiAgICAgICAgXCJKZXRGb3JtRWRpdG9yUm93XCIsXG4gICAgICAgIHtcbiAgICAgICAgICBhdHRyczogeyBsYWJlbDogX3ZtLmF1dG9jb21wbGV0ZV9lbmFibGUubGFiZWwgfSxcbiAgICAgICAgICBzY29wZWRTbG90czogX3ZtLl91KFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAga2V5OiBcImhlbHBTaWRlXCIsXG4gICAgICAgICAgICAgIGZuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gW192bS5fdihfdm0uX3MoX3ZtLmF1dG9jb21wbGV0ZV9lbmFibGUuaGVscCkpXVxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBwcm94eTogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF0pXG4gICAgICAgIH0sXG4gICAgICAgIFtcbiAgICAgICAgICBfYyhcImlucHV0XCIsIHtcbiAgICAgICAgICAgIGRpcmVjdGl2ZXM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwibW9kZWxcIixcbiAgICAgICAgICAgICAgICByYXdOYW1lOiBcInYtbW9kZWxcIixcbiAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV9lbmFibGUsXG4gICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJyZXNwb25zZS5hdXRvY29tcGxldGVfZW5hYmxlXCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGF0dHJzOiB7IHR5cGU6IFwiY2hlY2tib3hcIiB9LFxuICAgICAgICAgICAgZG9tUHJvcHM6IHtcbiAgICAgICAgICAgICAgY2hlY2tlZDogQXJyYXkuaXNBcnJheShfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX2VuYWJsZSlcbiAgICAgICAgICAgICAgICA/IF92bS5faShfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX2VuYWJsZSwgbnVsbCkgPiAtMVxuICAgICAgICAgICAgICAgIDogX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV9lbmFibGVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbjoge1xuICAgICAgICAgICAgICBjaGFuZ2U6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgIHZhciAkJGEgPSBfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX2VuYWJsZSxcbiAgICAgICAgICAgICAgICAgICQkZWwgPSAkZXZlbnQudGFyZ2V0LFxuICAgICAgICAgICAgICAgICAgJCRjID0gJCRlbC5jaGVja2VkID8gdHJ1ZSA6IGZhbHNlXG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoJCRhKSkge1xuICAgICAgICAgICAgICAgICAgdmFyICQkdiA9IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICQkaSA9IF92bS5faSgkJGEsICQkdilcbiAgICAgICAgICAgICAgICAgIGlmICgkJGVsLmNoZWNrZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgJCRpIDwgMCAmJlxuICAgICAgICAgICAgICAgICAgICAgIF92bS4kc2V0KFxuICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLnJlc3BvbnNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJhdXRvY29tcGxldGVfZW5hYmxlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAkJGEuY29uY2F0KFskJHZdKVxuICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICQkaSA+IC0xICYmXG4gICAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoXG4gICAgICAgICAgICAgICAgICAgICAgICBfdm0ucmVzcG9uc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImF1dG9jb21wbGV0ZV9lbmFibGVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICQkYS5zbGljZSgwLCAkJGkpLmNvbmNhdCgkJGEuc2xpY2UoJCRpICsgMSkpXG4gICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBfdm0uJHNldChfdm0ucmVzcG9uc2UsIFwiYXV0b2NvbXBsZXRlX2VuYWJsZVwiLCAkJGMpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgXVxuICAgICAgKSxcbiAgICAgIF92bS5fdihcIiBcIiksXG4gICAgICBfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX2VuYWJsZVxuICAgICAgICA/IF9jKFxuICAgICAgICAgICAgXCJKZXRGb3JtRWRpdG9yUm93XCIsXG4gICAgICAgICAgICB7IGF0dHJzOiB7IGxhYmVsOiBfdm0uYXV0b2NvbXBsZXRlX3ZpYV9hamF4LmxhYmVsIH0gfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBcIm1vZGVsXCIsXG4gICAgICAgICAgICAgICAgICAgIHJhd05hbWU6IFwidi1tb2RlbFwiLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV92aWFfYWpheCxcbiAgICAgICAgICAgICAgICAgICAgZXhwcmVzc2lvbjogXCJyZXNwb25zZS5hdXRvY29tcGxldGVfdmlhX2FqYXhcIlxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgYXR0cnM6IHsgdHlwZTogXCJjaGVja2JveFwiIH0sXG4gICAgICAgICAgICAgICAgZG9tUHJvcHM6IHtcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ6IEFycmF5LmlzQXJyYXkoX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV92aWFfYWpheClcbiAgICAgICAgICAgICAgICAgICAgPyBfdm0uX2koX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV92aWFfYWpheCwgbnVsbCkgPiAtMVxuICAgICAgICAgICAgICAgICAgICA6IF92bS5yZXNwb25zZS5hdXRvY29tcGxldGVfdmlhX2FqYXhcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG9uOiB7XG4gICAgICAgICAgICAgICAgICBjaGFuZ2U6IGZ1bmN0aW9uKCRldmVudCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgJCRhID0gX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV92aWFfYWpheCxcbiAgICAgICAgICAgICAgICAgICAgICAkJGVsID0gJGV2ZW50LnRhcmdldCxcbiAgICAgICAgICAgICAgICAgICAgICAkJGMgPSAkJGVsLmNoZWNrZWQgPyB0cnVlIDogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoJCRhKSkge1xuICAgICAgICAgICAgICAgICAgICAgIHZhciAkJHYgPSBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgJCRpID0gX3ZtLl9pKCQkYSwgJCR2KVxuICAgICAgICAgICAgICAgICAgICAgIGlmICgkJGVsLmNoZWNrZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICQkaSA8IDAgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLnJlc3BvbnNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYXV0b2NvbXBsZXRlX3ZpYV9hamF4XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJCRhLmNvbmNhdChbJCR2XSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAkJGkgPiAtMSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0uJHNldChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdm0ucmVzcG9uc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJhdXRvY29tcGxldGVfdmlhX2FqYXhcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkJGEuc2xpY2UoMCwgJCRpKS5jb25jYXQoJCRhLnNsaWNlKCQkaSArIDEpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgIF92bS4kc2V0KF92bS5yZXNwb25zZSwgXCJhdXRvY29tcGxldGVfdmlhX2FqYXhcIiwgJCRjKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgXVxuICAgICAgICAgIClcbiAgICAgICAgOiBfdm0uX2UoKSxcbiAgICAgIF92bS5fdihcIiBcIiksXG4gICAgICBfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX2VuYWJsZVxuICAgICAgICA/IF9jKFxuICAgICAgICAgICAgXCJKZXRGb3JtRWRpdG9yUm93XCIsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGF0dHJzOiB7IGxhYmVsOiBfdm0uYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aC5sYWJlbCB9LFxuICAgICAgICAgICAgICBzY29wZWRTbG90czogX3ZtLl91KFxuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAga2V5OiBcImhlbHBDb250cm9sXCIsXG4gICAgICAgICAgICAgICAgICAgIGZuOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgICAgICAgICAgX3ZtLl92KF92bS5fcyhfdm0uYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aC5oZWxwKSlcbiAgICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHByb3h5OiB0cnVlXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICAgIGZhbHNlLFxuICAgICAgICAgICAgICAgIDMxMzI2OTc4ODRcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgX2MoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgICAgICAgZGlyZWN0aXZlczogW1xuICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBcIm1vZGVsXCIsXG4gICAgICAgICAgICAgICAgICAgIHJhd05hbWU6IFwidi1tb2RlbFwiLFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZTogX3ZtLnJlc3BvbnNlLmF1dG9jb21wbGV0ZV9taW5pbXVtSW5wdXRMZW5ndGgsXG4gICAgICAgICAgICAgICAgICAgIGV4cHJlc3Npb246IFwicmVzcG9uc2UuYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aFwiXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICBhdHRyczogeyB0eXBlOiBcIm51bWJlclwiIH0sXG4gICAgICAgICAgICAgICAgZG9tUHJvcHM6IHtcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBfdm0ucmVzcG9uc2UuYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb246IHtcbiAgICAgICAgICAgICAgICAgIGlucHV0OiBmdW5jdGlvbigkZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCRldmVudC50YXJnZXQuY29tcG9zaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgX3ZtLiRzZXQoXG4gICAgICAgICAgICAgICAgICAgICAgX3ZtLnJlc3BvbnNlLFxuICAgICAgICAgICAgICAgICAgICAgIFwiYXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aFwiLFxuICAgICAgICAgICAgICAgICAgICAgICRldmVudC50YXJnZXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIF1cbiAgICAgICAgICApXG4gICAgICAgIDogX3ZtLl9lKClcbiAgICBdLFxuICAgIDFcbiAgKVxufVxudmFyIHN0YXRpY1JlbmRlckZucyA9IFtdXG5yZW5kZXIuX3dpdGhTdHJpcHBlZCA9IHRydWVcblxuZXhwb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSIsIi8qIGdsb2JhbHMgX19WVUVfU1NSX0NPTlRFWFRfXyAqL1xuXG4vLyBJTVBPUlRBTlQ6IERvIE5PVCB1c2UgRVMyMDE1IGZlYXR1cmVzIGluIHRoaXMgZmlsZSAoZXhjZXB0IGZvciBtb2R1bGVzKS5cbi8vIFRoaXMgbW9kdWxlIGlzIGEgcnVudGltZSB1dGlsaXR5IGZvciBjbGVhbmVyIGNvbXBvbmVudCBtb2R1bGUgb3V0cHV0IGFuZCB3aWxsXG4vLyBiZSBpbmNsdWRlZCBpbiB0aGUgZmluYWwgd2VicGFjayB1c2VyIGJ1bmRsZS5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbm9ybWFsaXplQ29tcG9uZW50IChcbiAgc2NyaXB0RXhwb3J0cyxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZ1bmN0aW9uYWxUZW1wbGF0ZSxcbiAgaW5qZWN0U3R5bGVzLFxuICBzY29wZUlkLFxuICBtb2R1bGVJZGVudGlmaWVyLCAvKiBzZXJ2ZXIgb25seSAqL1xuICBzaGFkb3dNb2RlIC8qIHZ1ZS1jbGkgb25seSAqL1xuKSB7XG4gIC8vIFZ1ZS5leHRlbmQgY29uc3RydWN0b3IgZXhwb3J0IGludGVyb3BcbiAgdmFyIG9wdGlvbnMgPSB0eXBlb2Ygc2NyaXB0RXhwb3J0cyA9PT0gJ2Z1bmN0aW9uJ1xuICAgID8gc2NyaXB0RXhwb3J0cy5vcHRpb25zXG4gICAgOiBzY3JpcHRFeHBvcnRzXG5cbiAgLy8gcmVuZGVyIGZ1bmN0aW9uc1xuICBpZiAocmVuZGVyKSB7XG4gICAgb3B0aW9ucy5yZW5kZXIgPSByZW5kZXJcbiAgICBvcHRpb25zLnN0YXRpY1JlbmRlckZucyA9IHN0YXRpY1JlbmRlckZuc1xuICAgIG9wdGlvbnMuX2NvbXBpbGVkID0gdHJ1ZVxuICB9XG5cbiAgLy8gZnVuY3Rpb25hbCB0ZW1wbGF0ZVxuICBpZiAoZnVuY3Rpb25hbFRlbXBsYXRlKSB7XG4gICAgb3B0aW9ucy5mdW5jdGlvbmFsID0gdHJ1ZVxuICB9XG5cbiAgLy8gc2NvcGVkSWRcbiAgaWYgKHNjb3BlSWQpIHtcbiAgICBvcHRpb25zLl9zY29wZUlkID0gJ2RhdGEtdi0nICsgc2NvcGVJZFxuICB9XG5cbiAgdmFyIGhvb2tcbiAgaWYgKG1vZHVsZUlkZW50aWZpZXIpIHsgLy8gc2VydmVyIGJ1aWxkXG4gICAgaG9vayA9IGZ1bmN0aW9uIChjb250ZXh0KSB7XG4gICAgICAvLyAyLjMgaW5qZWN0aW9uXG4gICAgICBjb250ZXh0ID1cbiAgICAgICAgY29udGV4dCB8fCAvLyBjYWNoZWQgY2FsbFxuICAgICAgICAodGhpcy4kdm5vZGUgJiYgdGhpcy4kdm5vZGUuc3NyQ29udGV4dCkgfHwgLy8gc3RhdGVmdWxcbiAgICAgICAgKHRoaXMucGFyZW50ICYmIHRoaXMucGFyZW50LiR2bm9kZSAmJiB0aGlzLnBhcmVudC4kdm5vZGUuc3NyQ29udGV4dCkgLy8gZnVuY3Rpb25hbFxuICAgICAgLy8gMi4yIHdpdGggcnVuSW5OZXdDb250ZXh0OiB0cnVlXG4gICAgICBpZiAoIWNvbnRleHQgJiYgdHlwZW9mIF9fVlVFX1NTUl9DT05URVhUX18gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnRleHQgPSBfX1ZVRV9TU1JfQ09OVEVYVF9fXG4gICAgICB9XG4gICAgICAvLyBpbmplY3QgY29tcG9uZW50IHN0eWxlc1xuICAgICAgaWYgKGluamVjdFN0eWxlcykge1xuICAgICAgICBpbmplY3RTdHlsZXMuY2FsbCh0aGlzLCBjb250ZXh0KVxuICAgICAgfVxuICAgICAgLy8gcmVnaXN0ZXIgY29tcG9uZW50IG1vZHVsZSBpZGVudGlmaWVyIGZvciBhc3luYyBjaHVuayBpbmZlcnJlbmNlXG4gICAgICBpZiAoY29udGV4dCAmJiBjb250ZXh0Ll9yZWdpc3RlcmVkQ29tcG9uZW50cykge1xuICAgICAgICBjb250ZXh0Ll9yZWdpc3RlcmVkQ29tcG9uZW50cy5hZGQobW9kdWxlSWRlbnRpZmllcilcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gdXNlZCBieSBzc3IgaW4gY2FzZSBjb21wb25lbnQgaXMgY2FjaGVkIGFuZCBiZWZvcmVDcmVhdGVcbiAgICAvLyBuZXZlciBnZXRzIGNhbGxlZFxuICAgIG9wdGlvbnMuX3NzclJlZ2lzdGVyID0gaG9va1xuICB9IGVsc2UgaWYgKGluamVjdFN0eWxlcykge1xuICAgIGhvb2sgPSBzaGFkb3dNb2RlXG4gICAgICA/IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaW5qZWN0U3R5bGVzLmNhbGwoXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgICAob3B0aW9ucy5mdW5jdGlvbmFsID8gdGhpcy5wYXJlbnQgOiB0aGlzKS4kcm9vdC4kb3B0aW9ucy5zaGFkb3dSb290XG4gICAgICAgIClcbiAgICAgIH1cbiAgICAgIDogaW5qZWN0U3R5bGVzXG4gIH1cblxuICBpZiAoaG9vaykge1xuICAgIGlmIChvcHRpb25zLmZ1bmN0aW9uYWwpIHtcbiAgICAgIC8vIGZvciB0ZW1wbGF0ZS1vbmx5IGhvdC1yZWxvYWQgYmVjYXVzZSBpbiB0aGF0IGNhc2UgdGhlIHJlbmRlciBmbiBkb2Vzbid0XG4gICAgICAvLyBnbyB0aHJvdWdoIHRoZSBub3JtYWxpemVyXG4gICAgICBvcHRpb25zLl9pbmplY3RTdHlsZXMgPSBob29rXG4gICAgICAvLyByZWdpc3RlciBmb3IgZnVuY3Rpb25hbCBjb21wb25lbnQgaW4gdnVlIGZpbGVcbiAgICAgIHZhciBvcmlnaW5hbFJlbmRlciA9IG9wdGlvbnMucmVuZGVyXG4gICAgICBvcHRpb25zLnJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcldpdGhTdHlsZUluamVjdGlvbiAoaCwgY29udGV4dCkge1xuICAgICAgICBob29rLmNhbGwoY29udGV4dClcbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsUmVuZGVyKGgsIGNvbnRleHQpXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGluamVjdCBjb21wb25lbnQgcmVnaXN0cmF0aW9uIGFzIGJlZm9yZUNyZWF0ZSBob29rXG4gICAgICB2YXIgZXhpc3RpbmcgPSBvcHRpb25zLmJlZm9yZUNyZWF0ZVxuICAgICAgb3B0aW9ucy5iZWZvcmVDcmVhdGUgPSBleGlzdGluZ1xuICAgICAgICA/IFtdLmNvbmNhdChleGlzdGluZywgaG9vaylcbiAgICAgICAgOiBbaG9va11cbiAgICB9XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGV4cG9ydHM6IHNjcmlwdEV4cG9ydHMsXG4gICAgb3B0aW9uczogb3B0aW9uc1xuICB9XG59XG4iLCJpbXBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9IGZyb20gXCIuL01vZGlmaWVyLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD04MDQ4Y2E1YyZcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9Nb2RpZmllci52dWU/dnVlJnR5cGU9c2NyaXB0Jmxhbmc9anMmXCJcbmV4cG9ydCAqIGZyb20gXCIuL01vZGlmaWVyLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZcIlxuXG5cbi8qIG5vcm1hbGl6ZSBjb21wb25lbnQgKi9cbmltcG9ydCBub3JtYWxpemVyIGZyb20gXCIhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL3J1bnRpbWUvY29tcG9uZW50Tm9ybWFsaXplci5qc1wiXG52YXIgY29tcG9uZW50ID0gbm9ybWFsaXplcihcbiAgc2NyaXB0LFxuICByZW5kZXIsXG4gIHN0YXRpY1JlbmRlckZucyxcbiAgZmFsc2UsXG4gIG51bGwsXG4gIG51bGwsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcT3BlblNlcnZlclxcXFxkb21haW5zXFxcXGRldmVsb3AuamV0XFxcXHdwLWNvbnRlbnRcXFxccGx1Z2luc1xcXFxqZXQtZm9ybS1idWlsZGVyLXNlbGVjdC1hdXRvY29tcGxldGVcXFxcYXNzZXRzXFxcXG5vZGVfbW9kdWxlc1xcXFx2dWUtaG90LXJlbG9hZC1hcGlcXFxcZGlzdFxcXFxpbmRleC5qc1wiKVxuICBhcGkuaW5zdGFsbChyZXF1aXJlKCd2dWUnKSlcbiAgaWYgKGFwaS5jb21wYXRpYmxlKSB7XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKVxuICAgIGlmICghYXBpLmlzUmVjb3JkZWQoJzgwNDhjYTVjJykpIHtcbiAgICAgIGFwaS5jcmVhdGVSZWNvcmQoJzgwNDhjYTVjJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfSBlbHNlIHtcbiAgICAgIGFwaS5yZWxvYWQoJzgwNDhjYTVjJywgY29tcG9uZW50Lm9wdGlvbnMpXG4gICAgfVxuICAgIG1vZHVsZS5ob3QuYWNjZXB0KFwiLi9Nb2RpZmllci52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9ODA0OGNhNWMmXCIsIGZ1bmN0aW9uICgpIHtcbiAgICAgIGFwaS5yZXJlbmRlcignODA0OGNhNWMnLCB7XG4gICAgICAgIHJlbmRlcjogcmVuZGVyLFxuICAgICAgICBzdGF0aWNSZW5kZXJGbnM6IHN0YXRpY1JlbmRlckZuc1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG5jb21wb25lbnQub3B0aW9ucy5fX2ZpbGUgPSBcImpldC1lbmdpbmUvTW9kaWZpZXIudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL01vZGlmaWVyLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZcIjsgZXhwb3J0IGRlZmF1bHQgbW9kOyBleHBvcnQgKiBmcm9tIFwiLSEuLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcyEuLi8uLi9ub2RlX21vZHVsZXMvdnVlLWxvYWRlci9saWIvaW5kZXguanM/P3Z1ZS1sb2FkZXItb3B0aW9ucyEuL01vZGlmaWVyLnZ1ZT92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZcIiIsImV4cG9ydCAqIGZyb20gXCItIS4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9sb2FkZXJzL3RlbXBsYXRlTG9hZGVyLmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi4vLi4vbm9kZV9tb2R1bGVzL3Z1ZS1sb2FkZXIvbGliL2luZGV4LmpzPz92dWUtbG9hZGVyLW9wdGlvbnMhLi9Nb2RpZmllci52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9ODA0OGNhNWMmXCIiLCJpbXBvcnQgTW9kaWZpZXIgZnJvbSBcIi4vTW9kaWZpZXIudnVlXCI7XHJcblxyXG5jb25zdCB7IGFkZEZpbHRlciB9ID0gd3AuaG9va3M7XHJcblxyXG5hZGRGaWx0ZXIoICdqZXQuZW5naW5lLnJlZ2lzdGVyLmZpZWxkcycsICdqZXQtZW5naW5lJywgZmllbGRzID0+IHtcclxuXHRmaWVsZHMucHVzaCggTW9kaWZpZXIgKTtcclxuXHJcblx0cmV0dXJuIGZpZWxkcztcclxufSApO1xyXG4iLCJjb25zdCB7IF9fIH0gPSB3cC5pMThuO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG5cdGF1dG9jb21wbGV0ZV9lbmFibGU6ICAgICAgICAgICAgIHtcclxuXHRcdGxhYmVsOiBfXyggJ1VzZSBBdXRvY29tcGxldGUnICksXHJcblx0XHRoZWxwOiAgX18oICdBZGRpbmcgYSB0ZXh0IGJveCB0byBzZWFyY2ggYW1vbmcgb3B0aW9ucycsICdqZXQtZm9ybS1idWlsZGVyLXNlbGVjdC1hdXRvY29tcGxldGUnICksXHJcblx0fSxcclxuXHRhdXRvY29tcGxldGVfdmlhX2FqYXg6ICAgICAgICAgICB7XHJcblx0XHRsYWJlbDogX18oICdMb2FkaW5nIHZpYSBBSkFYJyApLFxyXG5cdH0sXHJcblx0YXV0b2NvbXBsZXRlX21pbmltdW1JbnB1dExlbmd0aDoge1xyXG5cdFx0bGFiZWw6IF9fKCAnTWluaW11bSBpbnB1dCBsZW5ndGgnICksXHJcblx0XHRoZWxwOiAgX18oICdOdW1iZXIgb2YgY2hhcmFjdGVycyByZXF1aXJlZCB0byBwZXJmb3JtIGEgc2VhcmNoJywgJ2pldC1mb3JtLWJ1aWxkZXItc2VsZWN0LWF1dG9jb21wbGV0ZScgKSxcclxuXHR9LFxyXG59Il0sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUF0QkE7Ozs7Ozs7Ozs7OztBQ3BCQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7OztBQ3ZHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBaUJBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDdENBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDa0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUNwRUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7QUMxQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ3JMQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7OztBQ2pHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBaUJBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDdENBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFBO0FBRUE7QUFFQTtBQUNBO0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7O0FDUkE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBREE7QUFHQTtBQUNBO0FBQ0E7QUFGQTtBQVJBOzs7O0EiLCJzb3VyY2VSb290IjoiIn0=