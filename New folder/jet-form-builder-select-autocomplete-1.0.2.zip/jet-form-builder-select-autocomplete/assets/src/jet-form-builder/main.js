import source from '../source';

const { addFilter } = wp.hooks;

addFilter( 'blocks.registerBlockType', 'jet-form-builder', ( props, name ) => {
	if ( name !== 'jet-forms/select-field' ) {
		return props;
	}

	props.attributes.autocomplete_enable = {
		type:    "boolean",
		default: "",
	};
	props.attributes.autocomplete_via_ajax = {
		type:    "boolean",
		default: "",
	};
	props.attributes.autocomplete_minimumInputLength = {
		type:    "number",
		default: "",
	};

	return props;
} );

addFilter( 'jet.fb.register.fields.controls', 'jet-form-builder', controls => {
	controls.custom_settings = controls.custom_settings || {};
	controls.custom_settings.attrs = controls.custom_settings.attrs || [];

	controls.custom_settings.attrs.push(
		{
			...source.autocomplete_enable,
			attrName:  "autocomplete_enable",
			type:      "toggle",
			condition: {
				blockName: [ 'jet-forms/select-field' ],
			},
		},
		{
			...source.autocomplete_via_ajax,
			attrName:  "autocomplete_via_ajax",
			type:      "toggle",
			condition: {
				attr:      'autocomplete_enable',
				blockName: [ 'jet-forms/select-field' ],
			},
		},
		{
			...source.autocomplete_minimumInputLength,
			attrName:  'autocomplete_minimumInputLength',
			type:      'number',
			condition: {
				attr:      'autocomplete_enable',
				blockName: [ 'jet-forms/select-field' ],
			},
		},
	);

	return controls;
} );
