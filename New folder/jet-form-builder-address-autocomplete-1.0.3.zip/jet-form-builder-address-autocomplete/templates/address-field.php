<?php
echo $this->set_up()->get_rendered();