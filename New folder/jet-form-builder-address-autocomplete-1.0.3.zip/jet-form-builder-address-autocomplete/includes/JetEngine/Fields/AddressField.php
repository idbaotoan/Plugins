<?php


namespace Jet_FB_Address_Autocomplete\JetEngine\Fields;


use JetAddressAutocompleteCore\JetEngine\SingleField;
use Jet_Engine\Modules\Forms\Tabs\Tab_Manager;
use Jet_FB_Address_Autocomplete\AddressAutocomplete;

class AddressField extends SingleField {

	/**
	 * @return string
	 */
	public function get_id() {
		return 'address_autocomplete';
	}

	/**
	 * @return string
	 */
	public function get_title() {
		return __( 'Address Autocomplete Field' );
	}

	/**
	 * @return string
	 */
	public function get_field_template( $template, $args, $builder ) {
		AddressAutocomplete::instance()->settings( 'jef-address-tab', Tab_Manager::instance() );
		AddressAutocomplete::instance()->enqueue_scripts( 'jef-address-tab' );
		AddressAutocomplete::instance()->enqueue_styles();

		return ( new AddressRender() )->set_up( $args, $builder )->get_rendered();
	}

}