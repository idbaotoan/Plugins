<?php


namespace Jet_FB_Address_Autocomplete\JetEngine\Fields;


use JetAddressAutocompleteCore\JetEngine\RenderField;

class AddressRender {

	use RenderField;

	public function get_name() {
		return 'address_autocomplete';
	}

	public function args_map() {
		return array(
			'placeholder'          => 'Type address...',
			'address_autocomplete' => array()
		);
	}

	public function attributes_values() {
		return array(
			'data-address-settings' => esc_attr( json_encode( $this->get_arg( 'address_autocomplete' ) ) ),
			'class'                 => array( 'jet-address-autocomplete' ),
			'placeholder'           => $this->get_arg( 'placeholder' ),
			'type'                  => 'text',
			'autocomplete'          => 'false',
		);
	}

	public function render_field( $attrs_string ) {
		return "<input $attrs_string />";
	}

}