<?php


namespace Jet_FB_Address_Autocomplete\JetFormBuilder\Blocks;

use Jet_Form_Builder\Blocks\Render\Base;
use JetAddressAutocompleteCore\JetFormBuilder\RenderBlock;

class AddressBlockRender extends Base {

	use RenderBlock;

	public function get_name() {
		return 'address-field';
	}

	public function args_map() {
		return array(
			'placeholder' => 'Type address...',
			'types'       => array()
		);
	}

	public function attributes_values() {
		$settings = esc_attr( json_encode(
			$this->get_args( array(
				'countries',
				'types'
			) )
		) );

		return array(
			'data-address-settings' => $settings,
			'class'                 => array( 'jet-address-autocomplete' ),
			'placeholder'           => $this->get_arg( 'placeholder' ),
			'type'                  => 'text',
			'autocomplete'          => 'false',
		);
	}

	public function render_field( $attrs_string ) {
		return "<input $attrs_string />";
	}


}