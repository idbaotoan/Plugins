# JetFormBuilder Address Autocomplete
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.3
* Tweak: add license manager

## 1.0.2
* FIX: Correct saving global options

## 1.0.1
* ADD: The ability to disable google maps api js

## 1.0.0
* Initial release
