<?php
/**
 * Open week wrap
 */

if ( 0 === $inc % 7 ) {
	echo '<tr class="jet-calendar-week">';
}