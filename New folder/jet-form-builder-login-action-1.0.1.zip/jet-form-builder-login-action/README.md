# JetFormBuilder Login Action
Premium Addon for JetFormBuilder

# ChangeLog

## 1.0.1
* Tweak: add license manager