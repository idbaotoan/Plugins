<div class="wrap">
	<jet-abaf-calendars-list v-if="isSet"></jet-abaf-calendars-list>
	<div class="cx-vui-panel" v-else>
		<jet-abaf-go-to-setup></jet-abaf-go-to-setup>
	</div>
</div>