# JetFormBuilder Save Progress
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.3
* Tweak: add license manager

## 1.0.2
* ADD: Ability to clear local storage on successful form submission

## 1.0.1
* FIX: Get form id on change value

## 1.0.0
* Initial release