import * as convertKitTab from '@/convertkit-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.fb.register.settings-page.tabs', 'jet-form-builder', tabs => {
	tabs.push( convertKitTab );

	return tabs;
} );