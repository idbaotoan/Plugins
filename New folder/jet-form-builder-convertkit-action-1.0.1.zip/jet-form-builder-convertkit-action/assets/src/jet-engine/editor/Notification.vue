<template>
	<div class="jet-fb-convertkit-notification">
		<div class="jet-form-editor__row">
			<div class="jet-form-editor__row-label">{{ label( 'use_global' ) }}</div>
			<div class="jet-form-editor__row-control">
				<input
					type="checkbox"
					@change="setField( $event.target.checked, 'use_global' )"
					:checked="instance.use_global"
				/>
			</div>
		</div>
		<div class="jet-form-editor__row">
			<div class="jet-form-editor__row-label">{{ label( 'api_key' ) }}</div>
			<div class="jet-form-editor__row-control">
				<div class="jet-form-editor__input-group">
					<input
						type="text"
						@input="setField( $event.target.value, 'api_key' )"
						:disabled="instance.use_global"
						:value="getApiKey()"
					>
					<button type="button"
							class="button button-default button-large jet-form-validate-button"
							:class="{
                            'loading': isLoading,
							'is-valid': true === instance.isValidAPI && ! isLoading,
							'is-invalid': false === instance.isValidAPI && ! isLoading
						}"
							@click="validateAPI"
					>
						<i class="dashicons"></i>
						{{ instance.isValidAPI ? label( 'retry_request' ) : label( 'validate_api_key' ) }}
					</button>
				</div>
				<div class="jet-form-editor__row-notice">{{ help( 'api_key_link_prefix' ) }}
					<a :href="help( 'api_key_link' )" target="_blank">{{ help( 'api_key_link_suffix' ) }}</a>
				</div>
			</div>
		</div>
		<template v-if="instance.isValidAPI">
			<div class="jet-form-editor__row">
				<div class="jet-form-editor__row-label">{{ label( 'tag_id' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__input-group">
						<select @input="setField( $event.target.value, 'tag_id' )" :value="instance.tag_id">
							<option v-for="tagItem in instance.response.tags" :value="tagItem.value">
								{{ tagItem.label }}
							</option>
						</select>
						<button type="button"
								class="button button-default button-large jet-form-load-button"
								@click="getMailerLiteData"
						>
							{{ label( 'update_tag_ids' ) }}
						</button>
					</div>
				</div>
			</div>
			<div class="jet-form-editor__row">
				<div class="jet-form-editor__row-label">{{ label( 'fields_map' ) }}</div>
				<div class="jet-form-editor__row-control">
					<div class="jet-form-editor__row-notice">{{ help( 'fields_map' ) }}</div>
					<div class="jet-form-editor__row-fields">
						<div class="jet-form-editor__row-map"
							 v-for="( fieldData, fieldId ) in instance.response.fields">
                <span>{{ fieldData.label }} <span class="jet-form-editor-required"
												  v-if="fieldData.required">*</span></span>
							<select @input="changeFieldMap( $event.target.value, fieldId )"
									:value="getFieldMap( fieldId )">
								<option value="">--</option>
								<option v-for="field in fields" :value="field">{{ field }}</option>
							</select>
						</div>
					</div>
				</div>
			</div>
		</template>
	</div>
</template>

<script>
import { getLocalizedFullPack } from '@/source'

Vue.config.devtools = true;

const { source, label, help } = getLocalizedFullPack;
const globalKey = JEBookingFormNotifications.globalTab( 'convert-kit-tab' );

export default {
	name: 'convertkit',
	props: {
		value: Object,
		fields: Array,
		jsonSource: Array
	},
	data: function () {
		return {
			instance: {},
			isLoading: false,
			requestProcessing: '',
			response: {},
		};
	},
	created: function () {
		this.instance = this.value || {};
	},

	methods: {
		label: attr => label( attr ),
		help: attr => help( attr ),

		validateAPI: function () {
			const self = this;

			self.$set( self, 'isLoading', true );

			self.requestAPI()
			.always( () => {
				self.$set( self, 'isLoading', false );
			} );

		},
		requestAPI: function () {
			return ( jQuery.ajax( {
				url: ajaxurl,
				type: 'POST',
				data: {
					action: source.action,
					api_key: this.getApiKey(),
				}
			} ).done( response => {
				if ( response.success ) {
					this.setField( true, 'isValidAPI' );
					this.setField( response.data, 'response' );
				}
				else {
					this.setField( false, 'isValidAPI' );
				}
			} ) );
		},
		setField: function ( value, key ) {
			this.$set( this.instance, key, value );
			this.$emit( 'input', this.instance );
		},
		getMailerLiteData: function () {
			const self = this;

			self.requestAPI();
		},
		changeFieldMap: function ( value, key ) {
			if ( ! this.instance.fields_map ) {
				this.$set( this.instance, 'fields_map', {} );
			}
			this.$set( this.instance.fields_map, key, value );
			this.setField( this.instance.fields_map, 'fields_map' );
		},
		getFieldMap: function ( key ) {
			return this.instance.fields_map && this.instance.fields_map[ key ] ? this.instance.fields_map[ key ] : '';
		},
		getApiKey: function () {
			return this.instance.use_global ? globalKey.api_key : this.instance.api_key;
		}
	},

}
</script>