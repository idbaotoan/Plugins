import * as convertKitTab from '@/convertkit-tab';

const {
	addFilter
} = wp.hooks;

addFilter( 'jet.engine.formTabs.register', 'jet-engine', tabs => {
	tabs.push( convertKitTab );

	return tabs;
} );