const { __ } = wp.i18n;

const label = {
	api_key: __( 'API key', 'jet-form-builder' ),
};

const help = {
	apiPref: __( 'How to obtain your ConvertKit API key? More info' ),
	apiLinkLabel: __( 'here' ),
	apiLink: 'https://debounce.io/resources/help-desk/integrations/getting-a-convertkit-api-key/'
};

export { label, help };