import ConvertKitTab from './ConvertKitTab.vue';

const { __ } = wp.i18n;

const title = __( 'ConvertKit API', 'jet-form-builder' );
const component = ConvertKitTab;

export {
	title,
	component
}