<?php

namespace Jet_FB_ConvertKit;

use Jet_FB_ConvertKit\Jet_Form_Builder\Actions\Manager as JFB_Action_Manager;
use Jet_FB_ConvertKit\Jet_Engine\Notifications\Manager as JEF_Action_Manager;
use Jet_FB_ConvertKit\Jet_Form_Builder\Tabs\Manager_Tabs as JFB_Manager_Tabs;
use Jet_FB_ConvertKit\Jet_Engine\Tabs\Manager_Tabs as JEF_Manager_Tabs;

if ( ! defined( 'WPINC' ) ) {
	die();
}

class Plugin {
	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $slug = 'jet-form-builder-convertkit-action';

	public function __construct() {
		$this->register_autoloader();
		$this->init_components();
	}

	public function init_components() {
		JFB_Action_Manager::register();
		JEF_Action_Manager::register();

		JFB_Manager_Tabs::register();
		JEF_Manager_Tabs::register();

		Handler::instance();

		$can_init_license = (
			is_admin()
			&& function_exists( 'jet_form_builder' )
			&& array_key_exists( 'addons_manager', get_object_vars( jet_form_builder() ) )
		);

		if ( $can_init_license ) {
			require $this->plugin_dir( 'includes/class-jfb-license-manager.php' );

			new \JFB_License_Manager();
		}
	}

	/**
	 * Register autoloader.
	 */
	public function register_autoloader() {
		require JET_FB_CONVERTKIT_ACTION_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	public function get_version() {
		return JET_FB_CONVERTKIT_ACTION_VERSION;
	}

	public function plugin_url( $path ) {
		return JET_FB_CONVERTKIT_ACTION_URL . $path;
	}

	public function plugin_dir( $path = '' ) {
		return JET_FB_CONVERTKIT_ACTION_PATH . $path;
	}

	public function get_template_path( $template ) {
		$path = JET_FB_CONVERTKIT_ACTION_PATH . 'templates' . DIRECTORY_SEPARATOR;

		return ( $path . $template . '.php' );
	}

	public function url_assets_js( $path ) {
		return $this->plugin_url( 'assets/js/' . $path . '.js' );
	}

	public function url_assets_css( $path ) {
		return $this->plugin_url( 'assets/css/' . $path . '.css' );
	}


	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Plugin An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

Plugin::instance();