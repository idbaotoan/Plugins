<?php


namespace Jet_FB_ConvertKit\Jet_Engine\Notifications;


use Jet_FB_ConvertKit\Base_Action;
use Jet_FB_ConvertKit\Plugin;
use JetConvertKitCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use Base_Action;

}