<?php

return array(
    'left'   => array( 'title' => 'Left',   'icon' => 'dashicons-editor-alignleft'),
    'center' => array( 'title' => 'Center', 'icon' => 'dashicons-editor-aligncenter'),
    'right'  => array( 'title' => 'Right',  'icon' => 'dashicons-editor-alignright'),
);
