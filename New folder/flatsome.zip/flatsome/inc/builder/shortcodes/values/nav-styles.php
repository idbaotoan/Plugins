<?php

return array(
    'simple' => 'Simple',
    'line' => 'Line',
    'divided' => 'Divided',
    'line-grow' => 'Line Grow',
    'line-bottom' => 'Line Bottom',
    'outline' => 'Outline',
    'tabs' => 'Tabs',
    'bold' => 'Bold',
    'pills' => 'Pills',
);
