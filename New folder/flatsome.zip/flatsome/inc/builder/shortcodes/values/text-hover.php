<?php return array(
    '' => 'None',
    'fade-out' => 'Fade Out',
    'slide' => 'Slide In',
    'zoom' => 'Zoom Out',
    'zoom-in' => 'Zoom In',
    'blur' => 'Blur In',
    'bounce' => 'Bounce',
    'invert' => 'Invert',
);