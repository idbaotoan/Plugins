<?php

return array(
    'none' => 'None',
    'fadeInLeft' => 'Fade In Left',
    'fadeInRight' => 'Fade In Right',
    'fadeInUp' => 'Fade In Up',
    'fadeInDown' => 'Fade In Down',
    'bounceIn' => 'Bounce In',
    'bounceInUp' => 'Bounce In Up',
    'bounceInDown' => 'Bounce In Down',
    'bounceInLeft' => 'Bounce In Left',
    'bounceInRight' => 'Bounce In Right',
    'blurIn' => 'Blur In',
    'flipInX' => 'Flip In X',
    'flipInY' => 'Flip In Y',
);
